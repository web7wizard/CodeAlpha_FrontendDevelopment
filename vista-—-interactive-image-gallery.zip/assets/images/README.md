# Local Images Directory

Store any custom or offline photographs in this folder.

To use local images instead of remote Unsplash URLs:
1. Place your image files (e.g. `sample-nature.jpg`) in this directory.
2. In `js/images.js`, update the image entry:
   ```javascript
   url: "/assets/images/sample-nature.jpg",
   thumbUrl: "/assets/images/sample-nature.jpg",
   ```
3. Ensure the `alt`, `title`, `category`, and camera EXIF metadata reflect your photograph.
