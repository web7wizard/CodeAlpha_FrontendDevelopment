/**
 * VISTA — Digital Photography Collection
 * Structured Image Dataset with Editorial Metadata and Unsplash Attribution
 */

export const IMAGES = [
  {
    id: "vista-01",
    title: "Yosemite Valley Mist",
    category: "Nature",
    caption: "Morning haze lifting above the monolithic granite peaks of El Capitan and Half Dome.",
    description: "Captured during the quiet autumn equinox as morning fog billowed through Yosemite Valley, filtering golden sunlight across pine groves and granite walls.",
    photographer: "Bailey Zindel",
    photographerUrl: "https://unsplash.com/@baileyzindel",
    location: "Yosemite National Park, California, USA",
    year: 2023,
    aspectRatio: "tall",
    camera: {
      lens: "24-70mm f/2.8",
      aperture: "f/8.0",
      shutter: "1/250s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80",
    alt: "Morning mist drifting through the pine trees and mountains of Yosemite Valley"
  },
  {
    id: "vista-02",
    title: "Minimalist Monolith",
    category: "Architecture",
    caption: "Sharp intersecting concrete angles against a cloudless cerulean sky.",
    description: "An architectural study in geometric purity, celebrating clean brutalist forms, crisp shadows, and the dialogue between raw textured materials and negative space.",
    photographer: "Simone Hutsch",
    photographerUrl: "https://unsplash.com/@heysupersimi",
    location: "Berlin, Germany",
    year: 2024,
    aspectRatio: "standard",
    camera: {
      lens: "35mm Prime",
      aperture: "f/8.0",
      shutter: "1/320s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80",
    alt: "Clean angular modern architectural building facade framed against the open sky"
  },
  {
    id: "vista-03",
    title: "The Monarch's Gaze",
    category: "Wildlife",
    caption: "An adult male lion surveys the vast golden savannah grass at twilight.",
    description: "Witnessed on the edge of the Mara Triangle during the golden hour, as gentle wind ruffled the lion's mane while he surveyed approaching storm clouds across the plains.",
    photographer: "Geran de Klerk",
    photographerUrl: "https://unsplash.com/@gerandeklerk",
    location: "Maasai Mara National Reserve, Kenya",
    year: 2023,
    aspectRatio: "wide",
    camera: {
      lens: "400mm f/4.0 Telephoto",
      aperture: "f/4.0",
      shutter: "1/1200s",
      iso: "400"
    },
    url: "https://images.unsplash.com/photo-1546182990-dffeafbe841d?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1546182990-dffeafbe841d?auto=format&fit=crop&w=600&q=80",
    alt: "Majestic male lion resting intently in golden grass at twilight"
  },
  {
    id: "vista-04",
    title: "Serenity in the Cyclades",
    category: "Travel",
    caption: "Whitewashed terraces and cobalt domes perched above the Aegean caldera.",
    description: "Quiet midday in Oia, capturing the intense Mediterranean contrast between sun-drenched lime plaster, traditional bell towers, and the infinite blue of the sea below.",
    photographer: "Sean Oulashin",
    photographerUrl: "https://unsplash.com/@oulashin",
    location: "Santorini, Greece",
    year: 2023,
    aspectRatio: "tall",
    camera: {
      lens: "24mm Prime",
      aperture: "f/6.3",
      shutter: "1/640s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=600&q=80",
    alt: "Idyllic white stone architecture overlooking the blue sea in Santorini"
  },
  {
    id: "vista-05",
    title: "Fluid Chromatics",
    category: "Abstract",
    caption: "Suspended macro currents of pigment and density creating cosmic swirls.",
    description: "A macro studio study examining surface tension and fluid dynamics through organic pigments suspended in density gradients, resembling nebulae and celestial bodies.",
    photographer: "Lucas Benjamin",
    photographerUrl: "https://unsplash.com/@lucasbenjamin",
    location: "Studio Study, Montreal, Canada",
    year: 2024,
    aspectRatio: "standard",
    camera: {
      lens: "90mm f/2.8 Macro",
      aperture: "f/8.0",
      shutter: "1/160s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=600&q=80",
    alt: "Abstract swirling textures of orange, amber, and indigo fluid pigments"
  },
  {
    id: "vista-06",
    title: "Alpine Dawn Mist",
    category: "Nature",
    caption: "Jagged limestone peaks pierced through low-hanging clouds at daybreak.",
    description: "Standing at Tre Cime di Lavaredo before sunrise, observing the dramatic shift from cold violet twilight into warm amber as first light hit the peaks.",
    photographer: "Jerry Zhang",
    photographerUrl: "https://unsplash.com/@zljspace",
    location: "Dolomites, Belluno, Italy",
    year: 2023,
    aspectRatio: "wide",
    camera: {
      lens: "35mm f/1.4",
      aperture: "f/5.6",
      shutter: "1/400s",
      iso: "200"
    },
    url: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=600&q=80",
    alt: "Panoramic jagged mountain spires piercing through rolling layers of dawn fog"
  },
  {
    id: "vista-07",
    title: "Steel Geometry",
    category: "Architecture",
    caption: "Towering glass and steel curtain walls reflecting cloud formations.",
    description: "Looking up into the financial canyon of Frankfurt, where precision structural engineering creates hypnotic grids that mirror fleeting natural elements.",
    photographer: "Christian Perner",
    photographerUrl: "https://unsplash.com/@christianperner",
    location: "Frankfurt am Main, Germany",
    year: 2024,
    aspectRatio: "tall",
    camera: {
      lens: "24mm Tilt-Shift",
      aperture: "f/7.1",
      shutter: "1/200s",
      iso: "125"
    },
    url: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=600&q=80",
    alt: "Low-angle perspective of towering glass skyscraper facades reflecting clouds"
  },
  {
    id: "vista-08",
    title: "Neon Solitude",
    category: "Travel",
    caption: "Rain-slicked alleyways illuminated by vintage kanji neon signs.",
    description: "A contemplative late-night walk through the backstreets of Shinjuku. The gentle rainfall transforms asphalt into a mirror of vivid amber and cyan signage.",
    photographer: "Aleksandar Pasaric",
    photographerUrl: "https://unsplash.com/@apasaric",
    location: "Shinjuku, Tokyo, Japan",
    year: 2023,
    aspectRatio: "tall",
    camera: {
      lens: "35mm f/1.8",
      aperture: "f/1.8",
      shutter: "1/125s",
      iso: "800"
    },
    url: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=600&q=80",
    alt: "Moody rain-slicked Tokyo street at night illuminated by colorful glowing neon signs"
  },
  {
    id: "vista-09",
    title: "Arctic Sovereign",
    category: "Wildlife",
    caption: "A polar bear surveys ice floes along the 80th parallel north.",
    description: "An extraordinary quiet encounter aboard an expedition ship north of Spitsbergen, highlighting the silent power and vulnerability of the Arctic ecosystem.",
    photographer: "Hans-Jurgen Mager",
    photographerUrl: "https://unsplash.com/@hansjurgenmager",
    location: "Svalbard Archipelago, Norway",
    year: 2023,
    aspectRatio: "wide",
    camera: {
      lens: "300mm f/2.8",
      aperture: "f/5.6",
      shutter: "1/1600s",
      iso: "250"
    },
    url: "https://images.unsplash.com/photo-1564349683136-77e08dba1ef7?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1564349683136-77e08dba1ef7?auto=format&fit=crop&w=600&q=80",
    alt: "Polar bear walking calmly across snowy Arctic sea ice beneath grey skies"
  },
  {
    id: "vista-10",
    title: "Prismatic Refraction",
    category: "Abstract",
    caption: "Optical dispersion splitting crystalline beams into iridescent spectrums.",
    description: "Directing concentrated sunlight through optical grade lead-crystal prisms onto raw handmade cotton paper, exploring the physics of pure visible wavelengths.",
    photographer: "Jr Korpa",
    photographerUrl: "https://unsplash.com/@jrkorpa",
    location: "Kyiv, Ukraine",
    year: 2024,
    aspectRatio: "standard",
    camera: {
      lens: "100mm f/2.8 Macro",
      aperture: "f/5.6",
      shutter: "1/250s",
      iso: "200"
    },
    url: "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=600&q=80",
    alt: "Abstract rainbow light dispersion refractions dancing across fine paper texture"
  },
  {
    id: "vista-11",
    title: "Verdant Canyon Falls",
    category: "Nature",
    caption: "Crystalline mountain run-off carving deep channels through mossy basalt.",
    description: "Deep inside the narrow Virgin River narrows, where centuries of glacial waters have sculpted sheer walls lined with hanging gardens and emerald moss.",
    photographer: "Luca Bravo",
    photographerUrl: "https://unsplash.com/@lucabravo",
    location: "Zion National Park, Utah, USA",
    year: 2022,
    aspectRatio: "tall",
    camera: {
      lens: "16-35mm f/4.0",
      aperture: "f/11.0",
      shutter: "1/60s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1426604966848-d7adac402bff?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1426604966848-d7adac402bff?auto=format&fit=crop&w=600&q=80",
    alt: "Majestic steep river canyon with lush green moss and flowing turquoise water"
  },
  {
    id: "vista-12",
    title: "Nordic Spiral Pavilion",
    category: "Architecture",
    caption: "Continuous winding timber ramping ascending into forest canopies.",
    description: "A revolutionary piece of ecological architecture that weaves human presence gently into the forest canopy, balancing structural warmth with Scandinavian minimalism.",
    photographer: "Claudio Schwarz",
    photographerUrl: "https://unsplash.com/@purzlbaum",
    location: "Copenhagen, Denmark",
    year: 2023,
    aspectRatio: "standard",
    camera: {
      lens: "18mm Ultra-Wide",
      aperture: "f/9.0",
      shutter: "1/160s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1506157786151-b8491531f063?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1506157786151-b8491531f063?auto=format&fit=crop&w=600&q=80",
    alt: "Sculptural spiral wooden ramp architecture rising up through a green forest"
  },
  {
    id: "vista-13",
    title: "Ancient Kyoto Pathway",
    category: "Travel",
    caption: "Verdant moss stone stairs leading through whispering Arashiyama bamboo.",
    description: "An early dawn climb toward a secluded mountain hermitage in western Kyoto, surrounded by the rhythmic chime of wind through dense bamboo culms.",
    photographer: "Su San Lee",
    photographerUrl: "https://unsplash.com/@susanlee",
    location: "Kyoto, Japan",
    year: 2023,
    aspectRatio: "tall",
    camera: {
      lens: "50mm f/1.4",
      aperture: "f/2.2",
      shutter: "1/200s",
      iso: "400"
    },
    url: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=600&q=80",
    alt: "Quiet stone steps lined with moss leading into tranquil bamboo woods in Kyoto"
  },
  {
    id: "vista-14",
    title: "Apex Shadow",
    category: "Wildlife",
    caption: "A solitary leopard rests upon the limb of an ancient acacia tree.",
    description: "Patient tracking along the Seronera river valley revealed this master of camouflage resting in dappled shade, perfectly adapted to the East African plains.",
    photographer: "Michael Morse",
    photographerUrl: "https://unsplash.com/@morse",
    location: "Serengeti National Park, Tanzania",
    year: 2023,
    aspectRatio: "wide",
    camera: {
      lens: "500mm f/4.0",
      aperture: "f/5.0",
      shutter: "1/1000s",
      iso: "320"
    },
    url: "https://images.unsplash.com/photo-1534188753412-3e26d0d618d6?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1534188753412-3e26d0d618d6?auto=format&fit=crop&w=600&q=80",
    alt: "Leopard gracefully balanced on an acacia tree branch against a soft backdrop"
  },
  {
    id: "vista-15",
    title: "Mineral Dunes",
    category: "Abstract",
    caption: "Aerial shadows accentuating rhythmic geological ripples in gypsum sand.",
    description: "High altitude aerial photograph capturing the wind-sculpted ripples of white gypsum dunes at dawn, transformed into an undulating minimalist canvas of light and shadow.",
    photographer: "Scott Webb",
    photographerUrl: "https://unsplash.com/@scottwebb",
    location: "Mojave Desert, California, USA",
    year: 2024,
    aspectRatio: "wide",
    camera: {
      lens: "70-200mm f/2.8",
      aperture: "f/8.0",
      shutter: "1/1000s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=600&q=80",
    alt: "Top-down aerial view of sculpted desert sand dunes creating abstract curves"
  },
  {
    id: "vista-16",
    title: "Emerald Solitude",
    category: "Nature",
    caption: "Lush loch reflections encircled by ancient heather-clad Scottish mountains.",
    description: "In the heart of the Isle of Skye, wind died down for fifteen minutes, creating a glass-like mirror that doubled the grandeur of the Cuillin mountain ridge.",
    photographer: "Sébastien Goldberg",
    photographerUrl: "https://unsplash.com/@sebastiengoldberg",
    location: "Isle of Skye, Scottish Highlands",
    year: 2023,
    aspectRatio: "standard",
    camera: {
      lens: "50mm Prime",
      aperture: "f/4.0",
      shutter: "1/500s",
      iso: "160"
    },
    url: "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?auto=format&fit=crop&w=600&q=80",
    alt: "Serene mountain landscape with a calm crystal-clear lake reflection in Scotland"
  },
  {
    id: "vista-17",
    title: "Futuristic Oculus",
    category: "Architecture",
    caption: "Parametric ribbed archways echoing organic skeletal forms.",
    description: "Santiago Calatrava's City of Arts and Sciences in Valencia, demonstrating the intersection of organic structural morphology, clean white concrete, and radiant water basins.",
    photographer: "Scott Webb",
    photographerUrl: "https://unsplash.com/@scottwebb",
    location: "Valencia, Spain",
    year: 2023,
    aspectRatio: "standard",
    camera: {
      lens: "28mm f/2.8",
      aperture: "f/5.6",
      shutter: "1/400s",
      iso: "200"
    },
    url: "https://images.unsplash.com/photo-1511818966892-d7d671e672a2?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1511818966892-d7d671e672a2?auto=format&fit=crop&w=600&q=80",
    alt: "Sculptural modern white architectural arches reflecting in a clear pool"
  },
  {
    id: "vista-18",
    title: "Floating in Halong",
    category: "Travel",
    caption: "Traditional wooden junks navigating limestone pillars cloaked in sea mist.",
    description: "Navigating through the thousand karst islands of Ha Long Bay at dawn, where emerald waters hold quiet fishermen's boats amidst prehistoric geological formations.",
    photographer: "Amine M'siouri",
    photographerUrl: "https://unsplash.com/@aminemsiouri",
    location: "Ha Long Bay, Quang Ninh, Vietnam",
    year: 2023,
    aspectRatio: "wide",
    camera: {
      lens: "28-75mm f/2.8",
      aperture: "f/8.0",
      shutter: "1/500s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=600&q=80",
    alt: "Dramatic karst limestone cliffs rising out of the water in Ha Long Bay Vietnam"
  },
  {
    id: "vista-19",
    title: "Nocturnal Watcher",
    category: "Wildlife",
    caption: "An eagle owl peers from the hollow of an ancient moss-covered oak.",
    description: "Deep in the Bohemian Forest at dusk, this magnificent raptor paused before taking flight, its piercing amber eyes commanding the darkening wilderness.",
    photographer: "Zdeněk Macháček",
    photographerUrl: "https://unsplash.com/@zmachacek",
    location: "Bohemian Forest, Czech Republic",
    year: 2024,
    aspectRatio: "tall",
    camera: {
      lens: "200mm f/2.8",
      aperture: "f/2.8",
      shutter: "1/400s",
      iso: "800"
    },
    url: "https://images.unsplash.com/photo-1535083783855-76ae62b2914e?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1535083783855-76ae62b2914e?auto=format&fit=crop&w=600&q=80",
    alt: "Close-up portrait of a majestic owl with striking amber eyes sitting on a branch"
  },
  {
    id: "vista-20",
    title: "Silica Labyrinth",
    category: "Abstract",
    caption: "Microscopic circuit pathways and copper traces glowing under ultraviolet.",
    description: "An optical macro inquiry into microelectronic wafers, exposing the intricate synthetic topography that underpins the modern computational era.",
    photographer: "Alexandre Debiève",
    photographerUrl: "https://unsplash.com/@alexandre_debieve",
    location: "Paris, France",
    year: 2023,
    aspectRatio: "standard",
    camera: {
      lens: "50mm Macro",
      aperture: "f/11.0",
      shutter: "1/125s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=600&q=80",
    alt: "Abstract microcircuit motherboard pathways and gold contact points up close"
  },
  {
    id: "vista-21",
    title: "Whispers of the Wild",
    category: "Nature",
    caption: "Sunlight cascades through old-growth beech canopies onto mountain moss.",
    description: "Wandering through the primeval forests of the Carpathian mountains where ancient trees shelter diverse ecosystems untouched by industrial forestry.",
    photographer: "David Marcu",
    photographerUrl: "https://unsplash.com/@davidmarcu",
    location: "Carpathian Mountains, Romania",
    year: 2022,
    aspectRatio: "tall",
    camera: {
      lens: "85mm f/1.8",
      aperture: "f/2.8",
      shutter: "1/800s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=600&q=80",
    alt: "Ethereal sunbeams breaking through forest canopy trees onto wild terrain"
  },
  {
    id: "vista-22",
    title: "Brutalist Rhythm",
    category: "Architecture",
    caption: "Cast-concrete balconies and rhythmic repeating structural fins.",
    description: "The Barbican Estate in London, showing the tactile texture of bush-hammered concrete, geometric balconies, and the timeless dignity of mid-century civic design.",
    photographer: "Victor Garcia",
    photographerUrl: "https://unsplash.com/@victorgarcia",
    location: "Barbican Centre, London, UK",
    year: 2024,
    aspectRatio: "standard",
    camera: {
      lens: "50mm Prime",
      aperture: "f/8.0",
      shutter: "1/250s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1487958449943-2429e8be8625?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1487958449943-2429e8be8625?auto=format&fit=crop&w=600&q=80",
    alt: "Geometric concrete building balconies creating a repeating rhythmic facade"
  },
  {
    id: "vista-23",
    title: "Pastel Coastline",
    category: "Travel",
    caption: "Terraced cliffside dwellings cascading toward the sapphire Tyrrhenian Sea.",
    description: "Midsummer afternoon in Positano along the Amalfi Coast, where pastel-hued villas appear carved directly from sheer volcanic limestone cliffs.",
    photographer: "Nick Fewings",
    photographerUrl: "https://unsplash.com/@jannerboy62",
    location: "Positano, Amalfi Coast, Italy",
    year: 2023,
    aspectRatio: "wide",
    camera: {
      lens: "35mm f/2.0",
      aperture: "f/5.6",
      shutter: "1/800s",
      iso: "100"
    },
    url: "https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=600&q=80",
    alt: "Colorful Italian seaside village built vertically into dramatic ocean cliffs"
  },
  {
    id: "vista-24",
    title: "Highland Stag in Fog",
    category: "Wildlife",
    caption: "A red deer monarch standing sentinel amidst rolling mountain heather.",
    description: "An autumn morning in the Cairngorms National Park, catching this red deer stag crowned with twelve points standing alert against the gathering mountain gale.",
    photographer: "Simon Wilkes",
    photographerUrl: "https://unsplash.com/@simonwilkes",
    location: "Cairngorms National Park, Scotland",
    year: 2024,
    aspectRatio: "tall",
    camera: {
      lens: "135mm f/2.0",
      aperture: "f/3.2",
      shutter: "1/500s",
      iso: "500"
    },
    url: "https://images.unsplash.com/photo-1551969014-7d2c4cddf0b6?auto=format&fit=crop&w=1600&q=85",
    thumbUrl: "https://images.unsplash.com/photo-1551969014-7d2c4cddf0b6?auto=format&fit=crop&w=600&q=80",
    alt: "Magnificent red deer stag with large antlers standing in misty Scottish highlands"
  }
];

export const CATEGORIES = [
  "All",
  "Nature",
  "Architecture",
  "Travel",
  "Wildlife",
  "Abstract"
];
