/**
 * VISTA — Main Application Coordinator
 * CodeAlpha Frontend Development Internship — Task 1
 */

import { IMAGES, CATEGORIES } from "./images.js";
import { getFavorites, toggleFavorite, getFavoriteCount } from "./favorites.js";
import { filterManager } from "./filters.js";
import { renderGallery, updateCardFavorite } from "./gallery.js";
import { LightboxViewer } from "./lightbox.js";

class VistaApp {
  constructor() {
    this.images = IMAGES;
    this.currentFilteredImages = [...this.images];
    this.lightbox = null;
    this.searchDebounceTimer = null;

    // Cache key DOM elements
    this.galleryGrid = document.getElementById("gallery-grid");
    this.resultsCountEl = document.getElementById("results-count");
    this.filterTabsContainer = document.getElementById("filter-tabs");
    this.searchInput = document.getElementById("gallery-search-input");
    this.searchClearBtn = document.getElementById("search-clear-btn");
    this.sortSelect = document.getElementById("gallery-sort-select");
    this.navFavBadge = document.getElementById("nav-fav-badge");
    this.mobileFavBadge = document.getElementById("mobile-nav-fav-badge");
    this.mobileMenuToggle = document.getElementById("mobile-menu-toggle");
    this.mobileMenuDrawer = document.getElementById("mobile-menu-drawer");
    this.scrollTopBtn = document.getElementById("scroll-top-btn");
    this.toastContainer = document.getElementById("toast-container");
    this.copyrightYearEl = document.getElementById("copyright-year");

    // Dynamic Hero Stats
    this.statPhotos = document.getElementById("stat-total-photos");
    this.statCategories = document.getElementById("stat-categories-count");
    this.statPhotographers = document.getElementById("stat-photographers-count");
  }

  init() {
    // 1. Initialize Lightbox
    this.lightbox = new LightboxViewer();

    // 2. Set dynamic stats in hero & footer
    this.initStats();

    // 3. Render filter tabs (categories + favorites)
    this.initFilterTabs();

    // 4. Bind listeners
    this.bindEvents();

    // 5. Initial render
    this.updateGallery();
    this.updateFavoriteBadges();

    // 6. Setup scroll listener for Back to Top button
    this.initScrollWatch();
  }

  initStats() {
    if (this.statPhotos) this.statPhotos.textContent = this.images.length.toString();
    if (this.statCategories) this.statCategories.textContent = (CATEGORIES.length - 1).toString(); // excluding 'All'
    
    // Count unique photographers
    const uniqueArtists = new Set(this.images.map(img => img.photographer)).size;
    if (this.statPhotographers) this.statPhotographers.textContent = uniqueArtists.toString();

    // Current Year
    if (this.copyrightYearEl) {
      this.copyrightYearEl.textContent = new Date().getFullYear().toString();
    }
  }

  initFilterTabs() {
    if (!this.filterTabsContainer) return;

    this.filterTabsContainer.innerHTML = "";
    const fragment = document.createDocumentFragment();

    CATEGORIES.forEach(cat => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = `filter-pill ${cat === "All" ? "is-active" : ""}`;
      btn.setAttribute("data-category", cat);
      btn.setAttribute("role", "tab");
      btn.setAttribute("aria-selected", cat === "All" ? "true" : "false");
      btn.textContent = cat;

      btn.addEventListener("click", () => {
        this.setCategory(cat);
      });

      fragment.appendChild(btn);
    });

    // Add dedicated Favorites filter tab
    const favTab = document.createElement("button");
    favTab.type = "button";
    favTab.className = "filter-pill filter-pill-fav";
    favTab.setAttribute("data-category", "Favorites");
    favTab.setAttribute("role", "tab");
    favTab.setAttribute("aria-selected", "false");
    favTab.innerHTML = `
      <svg class="icon-fav-pill" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>
      </svg>
      <span>Favorites</span>
    `;

    favTab.addEventListener("click", () => {
      this.setCategory("Favorites");
    });

    fragment.appendChild(favTab);
    this.filterTabsContainer.appendChild(fragment);
  }

  bindEvents() {
    // 1. Search Input with debounce
    if (this.searchInput) {
      this.searchInput.addEventListener("input", (e) => {
        clearTimeout(this.searchDebounceTimer);
        const query = e.target.value;

        // Toggle clear button
        if (this.searchClearBtn) {
          if (query.length > 0) {
            this.searchClearBtn.classList.remove("is-hidden");
          } else {
            this.searchClearBtn.classList.add("is-hidden");
          }
        }

        this.searchDebounceTimer = setTimeout(() => {
          filterManager.setSearch(query);
        }, 180);
      });
    }

    // 2. Clear Search Button
    if (this.searchClearBtn) {
      this.searchClearBtn.addEventListener("click", () => {
        if (this.searchInput) {
          this.searchInput.value = "";
          this.searchInput.focus();
        }
        this.searchClearBtn.classList.add("is-hidden");
        filterManager.setSearch("");
      });
    }

    // 3. Sort dropdown
    if (this.sortSelect) {
      this.sortSelect.addEventListener("change", (e) => {
        filterManager.setSort(e.target.value);
      });
    }

    // 4. Filter manager subscription
    filterManager.subscribe((state) => {
      this.updateActiveFilterTab(state.category);
      this.updateGallery();
    });

    // 5. Reactive favorites listener
    window.addEventListener("vista:favorite-change", (e) => {
      const { id, isFavorite: isFav, count } = e.detail;
      this.updateFavoriteBadges(count);

      // If active filter is "Favorites", re-filter because items are being added/removed
      const currentState = filterManager.getState();
      if (currentState.category === "Favorites") {
        this.updateGallery();
      } else if (id) {
        updateCardFavorite(id, isFav);
      }
    });

    // 6. Navigation items
    const navFavLink = document.getElementById("nav-fav-link");
    if (navFavLink) {
      navFavLink.addEventListener("click", (e) => {
        e.preventDefault();
        this.setCategory("Favorites");
        this.scrollToGallery();
      });
    }

    const mobileNavFavLink = document.getElementById("mobile-nav-favorites");
    if (mobileNavFavLink) {
      mobileNavFavLink.addEventListener("click", (e) => {
        e.preventDefault();
        this.setCategory("Favorites");
        this.closeMobileMenu();
        this.scrollToGallery();
      });
    }

    // Mobile menu toggle
    if (this.mobileMenuToggle && this.mobileMenuDrawer) {
      this.mobileMenuToggle.addEventListener("click", () => {
        const isOpen = this.mobileMenuDrawer.classList.toggle("is-open");
        this.mobileMenuToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        this.mobileMenuToggle.classList.toggle("is-active", isOpen);
      });

      // Close mobile menu when clicking outside or link
      const mobileLinks = this.mobileMenuDrawer.querySelectorAll("a, button");
      mobileLinks.forEach(link => {
        link.addEventListener("click", () => {
          this.closeMobileMenu();
        });
      });
    }

    // Hero Explore Button
    const heroBtn = document.getElementById("hero-explore-btn");
    if (heroBtn) {
      heroBtn.addEventListener("click", (e) => {
        e.preventDefault();
        this.scrollToGallery();
      });
    }

    // Custom UI events from empty states
    window.addEventListener("vista:reset-filters", () => {
      this.resetAllFilters();
    });

    window.addEventListener("vista:clear-search", () => {
      if (this.searchInput) this.searchInput.value = "";
      if (this.searchClearBtn) this.searchClearBtn.classList.add("is-hidden");
      filterManager.setSearch("");
    });

    window.addEventListener("vista:show-all", () => {
      this.setCategory("All");
    });
  }

  setCategory(category) {
    filterManager.setCategory(category);
    this.updateActiveFilterTab(category);
  }

  updateActiveFilterTab(category) {
    const tabs = this.filterTabsContainer?.querySelectorAll(".filter-pill");
    tabs?.forEach(tab => {
      const tabCat = tab.getAttribute("data-category");
      const isActive = tabCat === category;
      tab.classList.toggle("is-active", isActive);
      tab.setAttribute("aria-selected", isActive ? "true" : "false");
    });
  }

  resetAllFilters() {
    if (this.searchInput) this.searchInput.value = "";
    if (this.searchClearBtn) this.searchClearBtn.classList.add("is-hidden");
    if (this.sortSelect) this.sortSelect.value = "curated";
    filterManager.reset();
  }

  updateGallery() {
    const favorites = getFavorites();
    const filterState = filterManager.getState();
    this.currentFilteredImages = filterManager.filterAndSort(this.images, favorites);

    // Update Result Count text
    this.updateResultsCount(this.currentFilteredImages.length, filterState);

    // Render Gallery cards
    renderGallery(
      this.currentFilteredImages,
      this.galleryGrid,
      (id, cardEl) => this.openLightbox(id, cardEl),
      (id, title) => this.handleFavoriteToggle(id, title),
      filterState
    );
  }

  updateResultsCount(count, state) {
    if (!this.resultsCountEl) return;

    const total = this.images.length;
    let text = `Showing ${count} of ${total} photographs`;

    if (state.category !== "All") {
      text = `Showing ${count} ${state.category} photographs`;
    }

    if (state.searchQuery) {
      text += ` matching "${state.searchQuery}"`;
    }

    this.resultsCountEl.textContent = text;
  }

  openLightbox(imageId, triggerElement) {
    if (!this.lightbox) return;
    this.lightbox.open(imageId, this.currentFilteredImages, triggerElement);
  }

  handleFavoriteToggle(id, title) {
    const res = toggleFavorite(id);
    const photo = this.images.find(img => img.id === id);
    const photoTitle = title || (photo ? photo.title : "Photograph");

    if (res.isFavorite) {
      this.showToast(`Saved "${photoTitle}" to your curation`, "success");
    } else {
      this.showToast(`Removed "${photoTitle}" from favorites`, "info");
    }
  }

  updateFavoriteBadges(count = getFavoriteCount()) {
    const label = count > 0 ? count.toString() : "";
    if (this.navFavBadge) {
      this.navFavBadge.textContent = label;
      this.navFavBadge.classList.toggle("is-visible", count > 0);
    }
    if (this.mobileFavBadge) {
      this.mobileFavBadge.textContent = label;
      this.mobileFavBadge.classList.toggle("is-visible", count > 0);
    }
  }

  showToast(message, type = "info") {
    if (!this.toastContainer) return;

    const toast = document.createElement("div");
    toast.className = `vista-toast toast-${type}`;
    toast.setAttribute("role", "status");
    toast.innerHTML = `
      <span class="toast-dot"></span>
      <span class="toast-text">${message}</span>
    `;

    this.toastContainer.appendChild(toast);

    // Fade in
    requestAnimationFrame(() => {
      toast.classList.add("is-active");
    });

    // Auto dismiss after 3 seconds
    setTimeout(() => {
      toast.classList.remove("is-active");
      setTimeout(() => {
        toast.remove();
      }, 300);
    }, 2800);
  }

  scrollToGallery() {
    const gallerySection = document.getElementById("gallery-section");
    if (gallerySection) {
      gallerySection.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  closeMobileMenu() {
    if (this.mobileMenuDrawer) {
      this.mobileMenuDrawer.classList.remove("is-open");
    }
    if (this.mobileMenuToggle) {
      this.mobileMenuToggle.setAttribute("aria-expanded", "false");
      this.mobileMenuToggle.classList.remove("is-active");
    }
  }

  initScrollWatch() {
    if (!this.scrollTopBtn) return;

    window.addEventListener("scroll", () => {
      if (window.scrollY > 450) {
        this.scrollTopBtn.classList.add("is-visible");
      } else {
        this.scrollTopBtn.classList.remove("is-visible");
      }
    }, { passive: true });

    this.scrollTopBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }
}

// Bootstrap once DOM is parsed
document.addEventListener("DOMContentLoaded", () => {
  const app = new VistaApp();
  app.init();
});
