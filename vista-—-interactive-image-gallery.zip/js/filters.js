/**
 * VISTA — Filter & Search Engine
 * Handles multi-dimensional filtering (category, search, favorites) and sorting
 * with zero mutation of the base dataset.
 */

class FilterManager {
  constructor() {
    this.state = {
      category: "All",
      searchQuery: "",
      sortBy: "curated"
    };
    this.listeners = [];
  }

  getState() {
    return { ...this.state };
  }

  setCategory(category) {
    if (this.state.category === category) return;
    this.state.category = category;
    this.notify();
  }

  setSearch(query) {
    const trimmed = query.trim().toLowerCase();
    if (this.state.searchQuery === trimmed) return;
    this.state.searchQuery = trimmed;
    this.notify();
  }

  setSort(sortBy) {
    if (this.state.sortBy === sortBy) return;
    this.state.sortBy = sortBy;
    this.notify();
  }

  reset() {
    this.state = {
      category: "All",
      searchQuery: "",
      sortBy: "curated"
    };
    this.notify();
  }

  subscribe(callback) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(cb => cb !== callback);
    };
  }

  notify() {
    const state = this.getState();
    this.listeners.forEach(cb => {
      try {
        cb(state);
      } catch (err) {
        console.error("VISTA Filter listener error:", err);
      }
    });
  }

  /**
   * Pure function to filter and sort images
   * @param {Array} images Base image array (immutable)
   * @param {Set<string>} favoritesSet Set of favorited IDs
   * @returns {Array} Filtered and sorted image array
   */
  filterAndSort(images, favoritesSet = new Set()) {
    let result = images.slice();

    // 1. Category Filter
    if (this.state.category === "Favorites") {
      result = result.filter(img => favoritesSet.has(img.id));
    } else if (this.state.category !== "All") {
      const targetCat = this.state.category.toLowerCase();
      result = result.filter(img => img.category.toLowerCase() === targetCat);
    }

    // 2. Search Query Filter
    const q = this.state.searchQuery;
    if (q) {
      result = result.filter(img => {
        const title = (img.title || "").toLowerCase();
        const category = (img.category || "").toLowerCase();
        const desc = (img.description || "").toLowerCase();
        const caption = (img.caption || "").toLowerCase();
        const photographer = (img.photographer || "").toLowerCase();
        const location = (img.location || "").toLowerCase();

        return (
          title.includes(q) ||
          category.includes(q) ||
          desc.includes(q) ||
          caption.includes(q) ||
          photographer.includes(q) ||
          location.includes(q)
        );
      });
    }

    // 3. Sorting
    switch (this.state.sortBy) {
      case "title-asc":
        result.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case "title-desc":
        result.sort((a, b) => b.title.localeCompare(a.title));
        break;
      case "category":
        result.sort((a, b) => a.category.localeCompare(b.category) || a.title.localeCompare(b.title));
        break;
      case "newest":
        result.sort((a, b) => (b.year || 0) - (a.year || 0));
        break;
      case "curated":
      default:
        // Preserves curated order as defined in IMAGES
        break;
    }

    return result;
  }
}

export const filterManager = new FilterManager();
