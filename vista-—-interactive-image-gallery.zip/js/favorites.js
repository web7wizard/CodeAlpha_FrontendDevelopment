/**
 * VISTA — Favorites Manager
 * Safe localStorage persistence, state tracking, and reactive sync events.
 */

const STORAGE_KEY = "vista_favorites_v1";

// In-memory fallback if localStorage is blocked or fails
let memoryFavorites = new Set();

/**
 * Safely load favorites from localStorage
 * @returns {Set<string>} Set of favorited photo IDs
 */
export function getFavorites() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return new Set(memoryFavorites);
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return new Set(parsed);
    }
  } catch (err) {
    console.warn("VISTA: localStorage unavailable or corrupted, using in-memory favorites.", err);
  }
  return new Set(memoryFavorites);
}

/**
 * Save favorites to storage and notify listeners
 * @param {Set<string>} favSet 
 */
function persistFavorites(favSet) {
  memoryFavorites = new Set(favSet);
  try {
    const arr = Array.from(favSet);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
  } catch (err) {
    console.warn("VISTA: Could not write to localStorage", err);
  }
}

/**
 * Check if a photo is favorited
 * @param {string} id 
 * @returns {boolean}
 */
export function isFavorite(id) {
  const current = getFavorites();
  return current.has(id);
}

/**
 * Toggle favorite state for a photo ID
 * @param {string} id 
 * @returns {{ id: string, isFavorite: boolean, count: number }}
 */
export function toggleFavorite(id) {
  const current = getFavorites();
  let status = false;

  if (current.has(id)) {
    current.delete(id);
    status = false;
  } else {
    current.add(id);
    status = true;
  }

  persistFavorites(current);

  const detail = {
    id,
    isFavorite: status,
    count: current.size
  };

  // Dispatch window event so gallery cards, navbar badge, and lightbox stay in sync
  window.dispatchEvent(new CustomEvent("vista:favorite-change", { detail }));

  return detail;
}

/**
 * Returns the total number of favorited items
 * @returns {number}
 */
export function getFavoriteCount() {
  return getFavorites().size;
}

/**
 * Clear all favorites
 */
export function clearAllFavorites() {
  persistFavorites(new Set());
  window.dispatchEvent(new CustomEvent("vista:favorite-change", {
    detail: { id: null, isFavorite: false, count: 0 }
  }));
}
