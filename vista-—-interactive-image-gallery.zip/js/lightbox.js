/**
 * VISTA — Fullscreen Lightbox Viewer
 * Interactive high-res viewer with keyboard shortcuts, touch gestures, EXIF info,
 * filmstrip thumbnail navigation, and accessibility focus management.
 */

import { isFavorite, toggleFavorite } from "./favorites.js";

export class LightboxViewer {
  constructor() {
    this.images = [];
    this.currentIndex = 0;
    this.isOpen = false;
    this.lastFocusedElement = null;

    // Touch gesture tracking
    this.touchStartX = 0;
    this.touchEndX = 0;
    this.touchStartY = 0;
    this.touchEndY = 0;

    this.initDOM();
    this.bindEvents();
  }

  initDOM() {
    // If modal already exists in HTML, use it; otherwise create it
    let modal = document.getElementById("lightbox-modal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "lightbox-modal";
      modal.className = "lightbox-modal";
      modal.setAttribute("role", "dialog");
      modal.setAttribute("aria-modal", "true");
      modal.setAttribute("aria-hidden", "true");
      modal.setAttribute("aria-label", "Image viewer");
      document.body.appendChild(modal);
    }

    modal.innerHTML = `
      <div class="lightbox-backdrop" data-action="close"></div>
      
      <div class="lightbox-container" role="document">
        <!-- Top Toolbar -->
        <header class="lightbox-toolbar">
          <div class="lightbox-meta-badge">
            <span class="lightbox-counter" id="lb-counter">1 / 1</span>
            <span class="lightbox-category" id="lb-category">Nature</span>
          </div>

          <div class="lightbox-actions">
            <button type="button" class="lb-btn lb-fav-btn" id="lb-fav-btn" aria-label="Save to favorites" title="Toggle Favorite (F)">
              <svg class="icon-heart" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>
              </svg>
            </button>

            <a href="#" target="_blank" rel="noopener noreferrer" class="lb-btn lb-link-btn" id="lb-source-link" aria-label="View original on Unsplash" title="View Source">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                <polyline points="15 3 21 3 21 9"/>
                <line x1="10" y1="14" x2="21" y2="3"/>
              </svg>
            </a>

            <button type="button" class="lb-btn lb-close-btn" id="lb-close-btn" data-action="close" aria-label="Close viewer (Escape)" title="Close (Esc)">
              <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <line x1="18" y1="6" x2="6" y2="18"/>
                <line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>
        </header>

        <!-- Main Viewing Stage -->
        <main class="lightbox-stage">
          <button type="button" class="lb-nav-btn lb-prev-btn" id="lb-prev-btn" aria-label="Previous photograph" title="Previous (Left Arrow)">
            <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
          </button>

          <div class="lightbox-media-box" id="lb-media-box">
            <div class="lb-spinner" id="lb-spinner" aria-label="Loading photograph"></div>
            <img src="" alt="" class="lightbox-image" id="lb-image" />
          </div>

          <button type="button" class="lb-nav-btn lb-next-btn" id="lb-next-btn" aria-label="Next photograph" title="Next (Right Arrow)">
            <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <polyline points="9 18 15 12 9 6"/>
            </svg>
          </button>
        </main>

        <!-- Photo Information Drawer -->
        <section class="lightbox-info-pane">
          <div class="lb-info-primary">
            <h2 class="lb-title" id="lb-title">Photograph Title</h2>
            <p class="lb-location" id="lb-location">Location</p>
            <p class="lb-caption" id="lb-caption">Editorial caption</p>
          </div>

          <div class="lb-info-secondary">
            <div class="lb-exif-tags" id="lb-exif-tags">
              <span class="exif-tag" id="exif-lens">24mm</span>
              <span class="exif-tag" id="exif-aperture">f/2.8</span>
              <span class="exif-tag" id="exif-shutter">1/500s</span>
              <span class="exif-tag" id="exif-iso">ISO 100</span>
            </div>
            <div class="lb-author" id="lb-author">
              <span>Photo by <strong id="lb-photographer-name">Artist</strong></span>
            </div>
          </div>
        </section>

        <!-- Thumbnail Filmstrip Strip -->
        <nav class="lightbox-filmstrip-wrapper" aria-label="Photographs in current collection">
          <div class="lightbox-filmstrip" id="lb-filmstrip"></div>
        </nav>
      </div>
    `;

    this.modal = modal;
    this.imageEl = modal.querySelector("#lb-image");
    this.spinnerEl = modal.querySelector("#lb-spinner");
    this.counterEl = modal.querySelector("#lb-counter");
    this.categoryEl = modal.querySelector("#lb-category");
    this.titleEl = modal.querySelector("#lb-title");
    this.locationEl = modal.querySelector("#lb-location");
    this.captionEl = modal.querySelector("#lb-caption");
    this.authorNameEl = modal.querySelector("#lb-photographer-name");
    this.sourceLinkEl = modal.querySelector("#lb-source-link");
    this.favBtn = modal.querySelector("#lb-fav-btn");
    this.closeBtn = modal.querySelector("#lb-close-btn");
    this.prevBtn = modal.querySelector("#lb-prev-btn");
    this.nextBtn = modal.querySelector("#lb-next-btn");
    this.filmstripEl = modal.querySelector("#lb-filmstrip");
    this.exifLens = modal.querySelector("#exif-lens");
    this.exifAperture = modal.querySelector("#exif-aperture");
    this.exifShutter = modal.querySelector("#exif-shutter");
    this.exifIso = modal.querySelector("#exif-iso");
  }

  bindEvents() {
    // Backdrop close
    this.modal.addEventListener("click", (e) => {
      const target = e.target;
      if (target && target.getAttribute("data-action") === "close") {
        this.close();
      }
    });

    this.closeBtn.addEventListener("click", () => this.close());
    this.prevBtn.addEventListener("click", () => this.prev());
    this.nextBtn.addEventListener("click", () => this.next());

    // Favorite toggle
    this.favBtn.addEventListener("click", () => {
      const current = this.getCurrentImage();
      if (current) {
        toggleFavorite(current.id);
        this.updateFavoriteButton(current.id);
      }
    });

    // Keyboard shortcuts
    document.addEventListener("keydown", (e) => {
      if (!this.isOpen) return;

      switch (e.key) {
        case "Escape":
          e.preventDefault();
          this.close();
          break;
        case "ArrowLeft":
          e.preventDefault();
          this.prev();
          break;
        case "ArrowRight":
          e.preventDefault();
          this.next();
          break;
        case "f":
        case "F":
          if (document.activeElement?.tagName !== "INPUT") {
            e.preventDefault();
            const current = this.getCurrentImage();
            if (current) {
              toggleFavorite(current.id);
              this.updateFavoriteButton(current.id);
            }
          }
          break;
        case "Tab":
          this.trapFocus(e);
          break;
      }
    });

    // Touch swipe support for mobile
    const stage = this.modal.querySelector(".lightbox-stage");
    if (stage) {
      stage.addEventListener("touchstart", (e) => {
        this.touchStartX = e.changedTouches[0].screenX;
        this.touchStartY = e.changedTouches[0].screenY;
      }, { passive: true });

      stage.addEventListener("touchend", (e) => {
        this.touchEndX = e.changedTouches[0].screenX;
        this.touchEndY = e.changedTouches[0].screenY;
        this.handleSwipe();
      }, { passive: true });
    }

    // Keep favorite state synced if changed from outside
    window.addEventListener("vista:favorite-change", (e) => {
      if (!this.isOpen) return;
      const current = this.getCurrentImage();
      if (current && e.detail && e.detail.id === current.id) {
        this.updateFavoriteButton(current.id);
      }
    });
  }

  handleSwipe() {
    const diffX = this.touchEndX - this.touchStartX;
    const diffY = this.touchEndY - this.touchStartY;

    // Ensure horizontal gesture is dominant
    if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 45) {
      if (diffX < 0) {
        this.next(); // swiped left -> go next
      } else {
        this.prev(); // swiped right -> go prev
      }
    }
  }

  trapFocus(e) {
    const focusable = this.modal.querySelectorAll(
      'button:not([disabled]), [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    if (focusable.length === 0) return;

    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    if (e.shiftKey) {
      if (document.activeElement === first) {
        e.preventDefault();
        last.focus();
      }
    } else {
      if (document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  }

  /**
   * Opens the lightbox for a specific image ID within the provided images list
   * @param {string} imageId 
   * @param {Array} images Current filtered collection
   * @param {HTMLElement} triggerElement The element that triggered the open (for focus restoration)
   */
  open(imageId, images, triggerElement = null) {
    if (!images || images.length === 0) return;

    this.images = images;
    const index = this.images.findIndex(img => img.id === imageId);
    this.currentIndex = index !== -1 ? index : 0;
    this.lastFocusedElement = triggerElement || document.activeElement;

    // Render filmstrip
    this.renderFilmstrip();

    // Show modal & lock body scroll
    this.modal.classList.add("is-visible");
    this.modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("lightbox-locked");
    this.isOpen = true;

    // Load active image
    this.updateDisplay();

    // Set initial focus to close button
    setTimeout(() => {
      this.closeBtn.focus();
    }, 50);
  }

  close() {
    if (!this.isOpen) return;

    this.modal.classList.remove("is-visible");
    this.modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("lightbox-locked");
    this.isOpen = false;

    // Restore focus to opener
    if (this.lastFocusedElement && typeof this.lastFocusedElement.focus === "function") {
      this.lastFocusedElement.focus();
    }
  }

  getCurrentImage() {
    return this.images[this.currentIndex] || null;
  }

  next() {
    if (this.images.length <= 1) return;
    this.currentIndex = (this.currentIndex + 1) % this.images.length;
    this.updateDisplay();
  }

  prev() {
    if (this.images.length <= 1) return;
    this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
    this.updateDisplay();
  }

  goToIndex(index) {
    if (index >= 0 && index < this.images.length) {
      this.currentIndex = index;
      this.updateDisplay();
    }
  }

  updateDisplay() {
    const img = this.getCurrentImage();
    if (!img) return;

    // Update Counter & Category
    this.counterEl.textContent = `${this.currentIndex + 1} / ${this.images.length}`;
    this.categoryEl.textContent = img.category;

    // Update Text info
    this.titleEl.textContent = img.title;
    this.locationEl.textContent = `${img.location} — ${img.year}`;
    this.captionEl.textContent = img.description || img.caption;
    this.authorNameEl.textContent = img.photographer;

    if (this.sourceLinkEl) {
      this.sourceLinkEl.href = img.photographerUrl || img.url;
    }

    // Update EXIF
    if (img.camera) {
      this.exifLens.textContent = img.camera.lens || "Prime";
      this.exifAperture.textContent = img.camera.aperture || "f/2.8";
      this.exifShutter.textContent = img.camera.shutter || "1/250s";
      this.exifIso.textContent = `ISO ${img.camera.iso || 100}`;
    }

    // Update Favorite Button
    this.updateFavoriteButton(img.id);

    // Update Image Loading with Spinner & Transitions
    this.spinnerEl.classList.remove("is-hidden");
    this.imageEl.classList.remove("is-loaded");

    const highResImg = new Image();
    highResImg.src = img.url;
    highResImg.onload = () => {
      this.imageEl.src = img.url;
      this.imageEl.alt = img.alt || img.title;
      this.spinnerEl.classList.add("is-hidden");
      this.imageEl.classList.add("is-loaded");
    };
    highResImg.onerror = () => {
      // Fallback to thumbnail or placeholder if high-res fails
      this.imageEl.src = img.thumbUrl;
      this.spinnerEl.classList.add("is-hidden");
      this.imageEl.classList.add("is-loaded");
    };

    // Update Active Filmstrip Item
    this.highlightActiveThumbnail();
  }

  updateFavoriteButton(id) {
    const isFav = isFavorite(id);
    if (isFav) {
      this.favBtn.classList.add("is-active");
      this.favBtn.setAttribute("aria-label", "Remove from favorites");
      this.favBtn.setAttribute("title", "Remove from favorites (F)");
    } else {
      this.favBtn.classList.remove("is-active");
      this.favBtn.setAttribute("aria-label", "Save to favorites");
      this.favBtn.setAttribute("title", "Save to favorites (F)");
    }
  }

  renderFilmstrip() {
    this.filmstripEl.innerHTML = "";
    const fragment = document.createDocumentFragment();

    this.images.forEach((img, idx) => {
      const thumbBtn = document.createElement("button");
      thumbBtn.type = "button";
      thumbBtn.className = "filmstrip-thumb";
      thumbBtn.setAttribute("data-index", idx.toString());
      thumbBtn.setAttribute("aria-label", `Jump to ${img.title}`);

      const thumbImg = document.createElement("img");
      thumbImg.src = img.thumbUrl;
      thumbImg.alt = img.title;
      thumbImg.loading = "lazy";

      thumbBtn.appendChild(thumbImg);

      thumbBtn.addEventListener("click", () => {
        this.goToIndex(idx);
      });

      fragment.appendChild(thumbBtn);
    });

    this.filmstripEl.appendChild(fragment);
  }

  highlightActiveThumbnail() {
    const thumbs = this.filmstripEl.querySelectorAll(".filmstrip-thumb");
    thumbs.forEach((thumb, idx) => {
      if (idx === this.currentIndex) {
        thumb.classList.add("is-active");
        thumb.setAttribute("aria-current", "true");
        // Scroll into view gently
        thumb.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
      } else {
        thumb.classList.remove("is-active");
        thumb.removeAttribute("aria-current");
      }
    });
  }
}
