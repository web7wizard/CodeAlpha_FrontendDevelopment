/**
 * VISTA — Gallery Renderer
 * Responsive CSS Grid card rendering, lazy loading, error fallbacks, and micro-interactions.
 */

import { isFavorite } from "./favorites.js";

// SVG icons for clean zero-dependency rendering
const ICONS = {
  heart: `<svg class="icon-heart" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>`,
  expand: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 3 6 6m0-6-7 7m-5 11-6-6m0 6 7-7"/></svg>`,
  imageFallback: `<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>`
};

/**
 * Creates fallback data URL SVG for images that fail to load
 */
function createFallbackImage() {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400" fill="#EAE8E0">
    <rect width="600" height="400" fill="#EAE8E0"/>
    <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="16" fill="#8C887B">Image preview temporarily unavailable</text>
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

/**
 * Render the full gallery grid
 * @param {Array} images Filtered array of image objects
 * @param {HTMLElement} container DOM element to render into
 * @param {Function} onSelect Callback when user opens an image
 * @param {Function} onToggleFav Callback when user clicks favorite
 * @param {Object} filterState Current filter state for contextual empty states
 */
export function renderGallery(images, container, onSelect, onToggleFav, filterState = {}) {
  if (!container) return;

  if (!images || images.length === 0) {
    renderEmptyState(container, filterState);
    return;
  }

  container.innerHTML = "";
  const fragment = document.createDocumentFragment();

  images.forEach((img, index) => {
    const isFav = isFavorite(img.id);
    const card = document.createElement("article");
    card.className = `gallery-card card-aspect-${img.aspectRatio || "standard"}`;
    card.setAttribute("data-id", img.id);
    card.setAttribute("data-index", index.toString());
    card.setAttribute("tabindex", "0");
    card.setAttribute("role", "button");
    card.setAttribute("aria-label", `View photograph: ${img.title} by ${img.photographer}`);

    card.innerHTML = `
      <div class="card-media-wrapper">
        <div class="card-skeleton" aria-hidden="true"></div>
        <img 
          src="${img.thumbUrl}" 
          alt="${img.alt || img.title}" 
          class="card-image" 
          loading="lazy" 
          decoding="async"
        />
        <div class="card-overlay" aria-hidden="true">
          <div class="card-overlay-top">
            <span class="card-category-badge">${img.category}</span>
          </div>
          <div class="card-overlay-bottom">
            <span class="card-view-hint">
              ${ICONS.expand}
              <span>Inspect</span>
            </span>
          </div>
        </div>
        <button 
          type="button" 
          class="card-fav-btn ${isFav ? "is-active" : ""}" 
          data-id="${img.id}" 
          aria-label="${isFav ? "Remove from favorites" : "Save to favorites"}"
          title="${isFav ? "Remove from favorites" : "Save to favorites"}"
        >
          ${ICONS.heart}
        </button>
      </div>
      <div class="card-info">
        <div class="card-info-header">
          <h3 class="card-title">${img.title}</h3>
          <span class="card-year">${img.year || ""}</span>
        </div>
        <p class="card-caption">${img.caption || img.description}</p>
        <div class="card-footer">
          <span class="card-location">${img.location}</span>
          <span class="card-author">Photo by ${img.photographer}</span>
        </div>
      </div>
    `;

    // Handle image loading & error fallback
    const imgEl = card.querySelector(".card-image");
    const skeleton = card.querySelector(".card-skeleton");

    if (imgEl) {
      if (imgEl.complete && imgEl.naturalWidth > 0) {
        skeleton?.classList.add("is-loaded");
        imgEl.classList.add("is-loaded");
      } else {
        imgEl.addEventListener("load", () => {
          skeleton?.classList.add("is-loaded");
          imgEl.classList.add("is-loaded");
        });
      }

      imgEl.addEventListener("error", () => {
        imgEl.src = createFallbackImage();
        skeleton?.classList.add("is-loaded");
        imgEl.classList.add("is-fallback");
      });
    }

    // Favorite click (stop propagation so card doesn't open lightbox)
    const favBtn = card.querySelector(".card-fav-btn");
    favBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (typeof onToggleFav === "function") {
        onToggleFav(img.id, img.title);
      }
    });

    // Card click opens lightbox
    card.addEventListener("click", () => {
      if (typeof onSelect === "function") {
        onSelect(img.id, card);
      }
    });

    // Keyboard support: Enter / Space triggers view
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        if (e.target === favBtn) return; // let button handler run
        e.preventDefault();
        if (typeof onSelect === "function") {
          onSelect(img.id, card);
        }
      }
    });

    fragment.appendChild(card);
  });

  container.appendChild(fragment);
}

/**
 * Updates favorite state on a specific card without touching the rest of DOM
 */
export function updateCardFavorite(id, isFav) {
  const card = document.querySelector(`.gallery-card[data-id="${id}"]`);
  if (!card) return;
  const btn = card.querySelector(".card-fav-btn");
  if (!btn) return;

  if (isFav) {
    btn.classList.add("is-active");
    btn.setAttribute("aria-label", "Remove from favorites");
    btn.setAttribute("title", "Remove from favorites");
  } else {
    btn.classList.remove("is-active");
    btn.setAttribute("aria-label", "Save to favorites");
    btn.setAttribute("title", "Save to favorites");
  }
}

/**
 * Renders an accessible, helpful empty state
 */
function renderEmptyState(container, filterState) {
  const isFavoritesView = filterState.category === "Favorites";
  const hasSearch = Boolean(filterState.searchQuery);

  let title = "No photographs found";
  let description = "Try selecting another category or resetting your search parameters.";
  let actionText = "Reset All Filters";
  let actionEvent = "vista:reset-filters";

  if (isFavoritesView && !hasSearch) {
    title = "Your curation is empty";
    description = "You haven't added any photographs to your favorites yet. Explore the gallery and click the heart icon on any photograph to curate your collection.";
    actionText = "Browse Full Gallery";
    actionEvent = "vista:show-all";
  } else if (hasSearch) {
    title = `No matches for "${filterState.searchQuery}"`;
    description = "Check your spelling or try searching for a different keyword, photographer, or location.";
    actionText = "Clear Search";
    actionEvent = "vista:clear-search";
  }

  container.innerHTML = `
    <div class="gallery-empty-state" role="status" aria-live="polite">
      <div class="empty-icon-box">
        <svg viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"/>
          <path d="m21 21-4.3-4.3"/>
          <path d="M8 11h6"/>
        </svg>
      </div>
      <h3 class="empty-title">${title}</h3>
      <p class="empty-desc">${description}</p>
      <button type="button" class="empty-action-btn" data-action="${actionEvent}">
        ${actionText}
      </button>
    </div>
  `;

  const btn = container.querySelector(".empty-action-btn");
  btn?.addEventListener("click", () => {
    window.dispatchEvent(new CustomEvent(actionEvent));
  });
}
