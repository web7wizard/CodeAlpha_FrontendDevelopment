# VISTA — Advanced Interactive Image Gallery

**CodeAlpha Frontend Development Internship — Task 1**  
**Repository Name:** `CodeAlpha_ImageGallery`  
**Author:** Javeriya Jamadar  
**Design Aesthetic:** Contemporary Editorial Photography Studio

---

## 1. Project Overview

**VISTA** is an interactive, responsive digital photography gallery engineered with zero heavy frameworks, relying purely on the native web foundations of **HTML5, CSS3, and modern Vanilla JavaScript (ES6+ Modules)**.

Built to exceed the requirements for CodeAlpha Frontend Development Internship Task 1, VISTA eschews generic UI templates in favor of a curated editorial studio identity. It pairs an asymmetrical yet disciplined CSS Grid layout with an accessible, keyboard-operable, full-screen lightbox viewer, live multi-field search, multi-category filters, sorting controls, and persistent local storage favorites.

---

## 2. Key Features

- **Responsive Editorial Grid:** Crafted using CSS Grid with deliberate card spans (`tall`, `wide`, `standard`) and fluid container rules that adapt seamlessly from mobile viewports (375px/430px) through tablets (768px) and ultra-wide desktops (1440px+).
- **Fullscreen Lightbox Viewer:**
  - High-resolution photography display with smooth fade/zoom entrance.
  - Previous and Next navigation with boundary wrapping (loops seamlessly).
  - Synchronized thumbnail filmstrip allowing instant jumps to any photograph in the active collection.
  - Camera technical parameters (EXIF): Focal length / lens, aperture, shutter speed, and ISO sensitivity.
  - Detailed editorial descriptions, geographical location, year, and photographer attribution links.
  - Background scroll lock and robust focus trap management (restores focus to the card that opened the modal).
- **Comprehensive Keyboard Shortcuts:**
  - `←` (Left Arrow): Previous photograph in lightbox.
  - `→` (Right Arrow): Next photograph in lightbox.
  - `Escape`: Close lightbox.
  - `F`: Toggle favorite status.
  - `Enter` / `Space`: Open selected gallery card.
  - `Tab` / `Shift+Tab`: Full keyboard focus navigation with high-visibility focus indicators.
- **Touch & Gesture Navigation:** Native touch swipe gestures on mobile devices (swipe left for next, swipe right for previous).
- **Persistent Favorites System:**
  - Add or remove any photograph from personal curation with a single click or keystroke.
  - Saves selections across browser reloads using `localStorage` with fail-safe in-memory fallback.
  - Real-time event bus synchronizes card heart icons, lightbox toggle, and navbar badge count immediately.
  - Filter gallery to view only favorited photographs with an intuitive empty state prompt.
- **Search, Filtering, and Sorting Pipeline:**
  - **Category Tabs:** Filter by *All*, *Nature*, *Architecture*, *Travel*, *Wildlife*, *Abstract*, and *Favorites*.
  - **Live Search:** Instant debounced filtering across photograph titles, categories, captions, descriptions, photographer names, and locations.
  - **Sorting Engine:** Sort by *Curated Order*, *Title (A — Z)*, *Title (Z — A)*, *Category*, or *Recent Year*.
  - **Immutability:** Filtering and sorting operate purely on derived collections, preserving the pristine dataset.
- **Refined UX & Performance:**
  - Native lazy-loading (`loading="lazy"`) and asynchronous image decoding.
  - Shimmer skeleton loaders while high-resolution media streams.
  - Graceful inline SVG fallback if an external network connection or asset fails.
  - Non-intrusive toast notifications confirming favorite actions.
  - Smooth scroll-to-top floating control.
  - Full support for `prefers-reduced-motion`.

---

## 3. Technologies Used

- **HTML5:** Semantic architecture (`<header>`, `<main>`, `<section>`, `<article>`, `<nav>`, `<aside>`, `<footer>`, `<dialog>` / ARIA role specifications).
- **CSS3:** Custom Properties (design tokens), CSS Grid, Flexbox, CSS transforms, backdrop-filter blur, fluid typography clamp, and media queries.
- **Vanilla JavaScript (ES6+):** ES Modules (`import`/`export`), DOM API, CustomEvent bus, `localStorage` persistence, touch event listeners, and debounced input handlers.
- **Zero Third-Party UI Frameworks:** No React, Angular, Vue, jQuery, or bloated CSS frameworks used at runtime. Pure static performance.

---

## 4. Visual Design System

Inspired by modern fine-art publications and architectural monographs:

| Color Role | Hex Code | Purpose |
| :--- | :--- | :--- |
| **Primary Background** | `#F6F5F0` | Warm ivory paper-like background |
| **Main Typography** | `#20211F` | Deep charcoal for high-contrast legibility |
| **Accent Color** | `#D66A43` | Muted terracotta / orange for active states and badges |
| **Accent Hover** | `#BF5630` | Deepened terracotta for interactive focus |
| **Secondary Surface** | `#EAE8E0` | Subtle stone surface for cards and toolbars |
| **Subtle Borders** | `#D9D7CF` | Refined dividing borders |
| **Lightbox Backdrop** | `#111210` | Immersive dark obsidian backdrop for photo inspection |

**Typography:**
- Display Headings: *Newsreader* (Serif display heading)
- Interface & Body: *Plus Jakarta Sans* (Geometric clean sans-serif)

---

## 5. Folder Structure

```
CodeAlpha_ImageGallery/
├── index.html               # Semantic HTML5 entry document
├── README.md                # Project documentation and submission guide
├── css/
│   └── styles.css           # Complete CSS3 styles, grid definitions, and responsive rules
├── js/
│   ├── app.js               # Main coordinator, event bindings, and DOM orchestration
│   ├── gallery.js           # Gallery grid rendering, cards, skeletons, and error handling
│   ├── lightbox.js          # Fullscreen viewer, EXIF data, filmstrip, and touch gestures
│   ├── filters.js           # Search, category filtering, and sorting logic
│   ├── favorites.js         # localStorage persistence, state sync, and custom events
│   └── images.js            # Structured 24-photo dataset with complete metadata
└── assets/
    └── images/              # Local image directory for offline assets or custom photos
        └── README.md
```

---

## 6. How to Run Locally

Because the project utilizes native ES Modules (`<script type="module">`), browsers require it to be served over an HTTP/HTTPS protocol rather than opened directly via `file://`.

### Option A: VS Code Live Server (Recommended)
1. Open the project folder in **Visual Studio Code**.
2. Install the **Live Server** extension by Ritwick Dey.
3. Right-click on `index.html` and select **"Open with Live Server"**.
4. The application will launch at `http://127.0.0.1:5500/`.

### Option B: Python Simple HTTP Server
If Python is installed on your computer:
```bash
# In the project root directory:
python3 -m http.server 8080
```
Open your browser and navigate to `http://localhost:8080`.

### Option C: Node.js (Vite / npx serve)
```bash
# Using npx serve:
npx serve .

# Or using the included dev server script:
npm install
npm run dev
```

---

## 7. How to Add or Replace Photographs

All photograph metadata is organized in `js/images.js`. To add a new photograph, add an entry to the `IMAGES` array:

```javascript
{
  id: "vista-25",
  title: "Your Photograph Title",
  category: "Nature", // Nature | Architecture | Travel | Wildlife | Abstract
  caption: "Short editorial caption displayed on card preview.",
  description: "Comprehensive description revealed in full-screen lightbox viewer.",
  photographer: "Photographer Name",
  photographerUrl: "https://unsplash.com/@username",
  location: "Reykjavik, Iceland",
  year: 2024,
  aspectRatio: "tall", // "tall" | "wide" | "standard"
  camera: {
    lens: "35mm Prime",
    aperture: "f/2.8",
    shutter: "1/500s",
    iso: "100"
  },
  url: "https://images.unsplash.com/your-high-res-photo-url",
  thumbUrl: "https://images.unsplash.com/your-thumbnail-url",
  alt: "Descriptive alt text for accessibility screen readers"
}
```

To use local image files, place your images in `assets/images/` and set:
```javascript
url: "/assets/images/my-photo.jpg",
thumbUrl: "/assets/images/my-photo.jpg",
```

---

## 8. Image Source & Licensing

All photographs featured in the initial dataset are sourced from **Unsplash** under the [Unsplash License](https://unsplash.com/license):
- Free to use for commercial and non-commercial purposes.
- No permission needed (attribution generously provided in every photo card and lightbox dialog).
- Contributing artists include Bailey Zindel, Geran de Klerk, Simone Hutsch, Sean Oulashin, Lucas Benjamin, Jerry Zhang, Christian Perner, Hans-Jurgen Mager, and others.

---

## 9. GitHub Upload Instructions

To publish your project to a new GitHub repository named `CodeAlpha_ImageGallery`:

```bash
# 1. Open your terminal in the project directory
cd CodeAlpha_ImageGallery

# 2. Initialize git repository
git init

# 3. Stage all files
git add .

# 4. Create initial commit
git commit -m "feat: complete VISTA interactive image gallery for CodeAlpha Task 1"

# 5. Rename default branch to main
git branch -M main

# 6. Add your GitHub remote repository (replace YOUR-USERNAME with your actual GitHub username)
git remote add origin https://github.com/YOUR-USERNAME/CodeAlpha_ImageGallery.git

# 7. Push the files to GitHub
git push -u origin main
```

---

## 10. Deployment Instructions

### Deploy to Netlify
1. Log in to [Netlify](https://www.netlify.com/).
2. Select **"Add new site"** &rarr; **"Import an existing project"**.
3. Choose **GitHub** and authorize access to `CodeAlpha_ImageGallery`.
4. Configure build settings:
   - **Build command:** *(leave blank for static HTML/JS)*
   - **Publish directory:** `.` *(or root directory)*
5. Click **"Deploy Site"**. Your gallery will be live with an SSL HTTPS URL instantly.

*Alternatively, drag and drop the project folder directly into the Netlify Drop dashboard.*

### Deploy to GitHub Pages
1. Go to your GitHub repository `CodeAlpha_ImageGallery` settings.
2. Navigate to **Pages** in the left sidebar.
3. Under **Branch**, select `main` and root `/` folder.
4. Click **Save**. Within 1–2 minutes, your gallery will be accessible at `https://YOUR-USERNAME.github.io/CodeAlpha_ImageGallery/`.

---

## 11. Keyboard Shortcuts Reference

| Shortcut Key | Action | Context |
| :--- | :--- | :--- |
| `←` (Left Arrow) | Navigate to previous photograph | Lightbox Viewer |
| `→` (Right Arrow) | Navigate to next photograph | Lightbox Viewer |
| `Escape` | Close lightbox viewer | Lightbox Viewer |
| `F` | Toggle favorite on current photo | Lightbox Viewer |
| `Enter` / `Space` | Open highlighted photograph | Gallery Grid |
| `Tab` / `Shift+Tab` | Traverse interactive controls | Site-wide |

---

## 12. Known Limitations & Notes

- **Internet Connectivity:** When using the default high-resolution Unsplash CDN links, an active internet connection is required to load images. If offline, the graceful fallback SVG mechanism will display placeholder tiles.
- **Local Storage Limitations:** Private browsing modes (Incognito) in certain strict browser environments may restrict `localStorage` writes; in such cases, VISTA transparently switches to an in-memory session store so favorites remain functional during the session.

---

*VISTA — Designed & Engineered for CodeAlpha Frontend Development Internship Task 1.*
