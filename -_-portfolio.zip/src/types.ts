export interface Project {
  id: string;
  title: string;
  fullTitle?: string;
  category: string;
  description: string;
  technologies: string[];
  liveUrl?: string;
  repoUrl?: string;
  profileUrl?: string;
  accentLabel?: string;
}

export interface SkillCategory {
  title: string;
  description: string;
  skills: string[];
}

export interface ExperienceItem {
  id: string;
  role: string;
  organization: string;
  location?: string;
  period?: string;
  description: string;
  highlightTag?: string;
}
