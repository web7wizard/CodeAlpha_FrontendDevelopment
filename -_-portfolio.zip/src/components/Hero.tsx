import { useState } from 'react';
import { ArrowDown, ArrowUpRight, Github, Linkedin, Mail, Sparkles } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData.ts';

export default function Hero() {
  const [imageFailed, setImageFailed] = useState(false);

  const handleScrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative pt-32 pb-20 md:pt-40 md:pb-28 border-b border-[#E3DFD5] overflow-hidden"
    >
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Text & CTAs */}
          <div className="lg:col-span-7 flex flex-col items-start">
            {/* Top Monospace Label */}
            <div className="flex items-center gap-2 mb-6">
              <span className="w-2 h-2 rounded-full bg-[#C8F169] border border-[#171916]/40" />
              <span className="text-xs font-mono-label tracking-widest uppercase text-[#52584E] font-medium">
                Computer Engineering Student
              </span>
            </div>

            {/* Editorial Heading */}
            <h1 className="font-editorial text-4xl sm:text-5xl lg:text-[3.75rem] font-normal tracking-tight text-[#171916] leading-[1.12] mb-6">
              Building thoughtful <br className="hidden sm:inline" />
              <span className="italic font-normal">digital experiences.</span>
            </h1>

            {/* Short Introduction */}
            <p className="text-base sm:text-lg text-[#40453D] leading-relaxed max-w-xl mb-8 font-normal">
              I am a Computer Engineering student at PCCOE Pune interested in frontend development,
              software engineering, artificial intelligence, and cybersecurity. I build clean,
              functional web applications with a focus on code clarity and user experience.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 mb-8">
              <button
                type="button"
                onClick={() => handleScrollTo('projects')}
                className="px-6 py-3 bg-[#171916] text-[#F5F3ED] text-sm font-medium hover:bg-[#2A2E28] transition-colors rounded-sm inline-flex items-center gap-2 shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#171916] focus-visible:ring-offset-2"
              >
                <span>View Projects</span>
                <ArrowDown className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => handleScrollTo('contact')}
                className="px-6 py-3 bg-transparent border border-[#171916] text-[#171916] text-sm font-medium hover:bg-[#EAE6DC] transition-colors rounded-sm inline-flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#171916] focus-visible:ring-offset-2"
              >
                <span>Contact Me</span>
                <Mail className="w-4 h-4" />
              </button>
            </div>

            {/* Small text links for GitHub and LinkedIn */}
            <div className="flex items-center gap-6 pt-2 border-t border-[#E3DFD5]/60 text-xs font-mono-label text-[#52584E]">
              <a
                href={PERSONAL_INFO.github}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 hover:text-[#171916] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#171916]"
              >
                <Github className="w-3.5 h-3.5" />
                <span>GitHub (web7wizard)</span>
                <ArrowUpRight className="w-3 h-3 text-[#7B8277]" />
              </a>

              <span className="text-[#C2BCB0]" aria-hidden="true">·</span>

              <a
                href={PERSONAL_INFO.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 hover:text-[#171916] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#171916]"
              >
                <Linkedin className="w-3.5 h-3.5" />
                <span>LinkedIn</span>
                <ArrowUpRight className="w-3 h-3 text-[#7B8277]" />
              </a>
            </div>
          </div>

          {/* Right Column: Profile Container */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <div className="relative w-full max-w-sm">
              {/* Outer Editorial Card */}
              <div className="bg-[#EBE7DD] p-2 rounded-xl border border-[#DCD6C8] shadow-[0_8px_30px_rgba(23,25,22,0.06)]">
                <div className="relative aspect-4/5 rounded-lg overflow-hidden bg-[#E2DDCF] flex flex-col justify-between p-6">
                  {!imageFailed ? (
                    <img
                      src="/javeriya-photo.jpg"
                      alt={PERSONAL_INFO.name}
                      onError={() => setImageFailed(true)}
                      className="absolute inset-0 w-full h-full object-cover object-center"
                    />
                  ) : null}

                  {/* Fallback Initials-Based Editorial Placeholder */}
                  {imageFailed && (
                    <div className="flex flex-col justify-between h-full w-full select-none">
                      <div className="flex items-center justify-between text-xs font-mono-label text-[#52584E]">
                        <span>PROFILE</span>
                        <span className="inline-flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-[#C8F169] border border-[#171916]/40" />
                          PCCOE PUNE
                        </span>
                      </div>

                      <div className="my-auto py-8 text-center">
                        <div className="w-24 h-24 mx-auto rounded-full bg-[#171916] text-[#F5F3ED] flex items-center justify-center font-editorial text-4xl font-normal shadow-inner mb-4">
                          {PERSONAL_INFO.initials}
                        </div>
                        <h2 className="font-editorial text-2xl text-[#171916] font-medium tracking-tight">
                          {PERSONAL_INFO.name}
                        </h2>
                        <p className="text-xs font-mono-label text-[#52584E] mt-1">
                          Computer Engineering
                        </p>
                      </div>

                      <div className="pt-4 border-t border-[#D5CFBF] text-[11px] font-mono-label text-[#63685E] flex justify-between items-center">
                        <span>PUNE, MAHARASHTRA</span>
                        <span>DEV PORTFOLIO</span>
                      </div>
                    </div>
                  )}

                  {/* Overlay corner accent when image is loaded */}
                  {!imageFailed && (
                    <div className="absolute bottom-3 left-3 right-3 bg-[#171916]/85 backdrop-blur-sm px-4 py-2.5 rounded text-white flex items-center justify-between text-xs">
                      <span className="font-medium">{PERSONAL_INFO.name}</span>
                      <span className="font-mono-label text-[10px] text-[#C8F169]">PCCOE Pune</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Quiet editorial metadata caption underneath */}
              <div className="mt-3 px-2 flex items-center justify-between text-xs font-mono-label text-[#737A6F]">
                <span>Pimpri Chinchwad College of Engineering</span>
                <span className="text-[#171916] font-medium">Pune, India</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
