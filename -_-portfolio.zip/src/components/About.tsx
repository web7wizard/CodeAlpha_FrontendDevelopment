import { GraduationCap, MapPin, Mail, Sparkles, Code2, Globe } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData.ts';

export default function About() {
  return (
    <section id="about" className="py-20 md:py-28 border-b border-[#E3DFD5] scroll-mt-16">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-mono-label text-[#737A6F] uppercase tracking-wider">
              01 / Profile
            </span>
          </div>
          <h2 className="font-editorial text-3xl sm:text-4xl text-[#171916] font-normal tracking-tight">
            About <span className="italic">Me</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Main Narrative */}
          <div className="lg:col-span-7 space-y-5 text-[#383D35] text-base sm:text-lg leading-relaxed">
            <p>
              I am an undergraduate student pursuing Computer Engineering at{' '}
              <strong className="font-semibold text-[#171916]">
                Pimpri Chinchwad College of Engineering (PCCOE)
              </strong>{' '}
              in Pune, Maharashtra, India. My journey in tech centers on developing solid practical
              skills through rigorous academic study and hands-on software development.
            </p>
            <p>
              I enjoy building useful, responsive, and accessible web applications. My interests
              span frontend engineering, software systems, artificial intelligence, data analytics,
              and cybersecurity. Whether designing an interactive simulator or exploring predictive
              data models, I value clarity, structured code, and thoughtful user experiences as I
              continue to grow as a software engineer.
            </p>

            <div className="pt-4 flex flex-wrap items-center gap-3 text-xs font-mono-label text-[#52584E]">
              <span className="inline-flex items-center gap-1.5 bg-[#EAE6DC] px-2.5 py-1 rounded text-[#171916]">
                <MapPin className="w-3.5 h-3.5 text-[#52584E]" />
                Pune, Maharashtra, India
              </span>
              <span className="inline-flex items-center gap-1.5 bg-[#EAE6DC] px-2.5 py-1 rounded text-[#171916]">
                <GraduationCap className="w-3.5 h-3.5 text-[#52584E]" />
                PCCOE Pune
              </span>
            </div>
          </div>

          {/* Compact Information Area */}
          <div className="lg:col-span-5 bg-[#EBE7DD]/80 border border-[#DDD6C8] rounded-xl p-6 sm:p-7">
            <h3 className="text-xs font-mono-label tracking-widest uppercase text-[#52584E] mb-5 pb-3 border-b border-[#DDD6C8] flex items-center justify-between">
              <span>Quick Facts</span>
              <span className="text-[10px] text-[#737A6F]">VERIFIED INFO</span>
            </h3>

            <dl className="space-y-4 text-sm">
              <div>
                <dt className="text-xs font-mono-label text-[#737A6F] mb-1">CURRENT ROLE</dt>
                <dd className="font-medium text-[#171916] leading-snug">
                  Computer Engineering Student & Aspiring Software Engineer
                </dd>
              </div>

              <div className="pt-2 border-t border-[#DDD6C8]/60">
                <dt className="text-xs font-mono-label text-[#737A6F] mb-1">ACADEMIC INSTITUTION</dt>
                <dd className="font-medium text-[#171916] leading-snug">
                  Pimpri Chinchwad College of Engineering (PCCOE)
                </dd>
                <dd className="text-xs text-[#52584E] mt-0.5">Pune, Maharashtra, India</dd>
              </div>

              <div className="pt-2 border-t border-[#DDD6C8]/60">
                <dt className="text-xs font-mono-label text-[#737A6F] mb-1">PRIMARY INTERESTS</dt>
                <dd className="text-xs text-[#171916] leading-relaxed">
                  Software Engineering · Frontend Development · Artificial Intelligence · Data Analytics · Cybersecurity
                </dd>
              </div>

              <div className="pt-2 border-t border-[#DDD6C8]/60">
                <dt className="text-xs font-mono-label text-[#737A6F] mb-1">ACADEMIC EMAIL</dt>
                <dd>
                  <a
                    href={`mailto:${PERSONAL_INFO.email}`}
                    className="text-xs font-mono-label text-[#171916] underline decoration-[#171916]/30 hover:decoration-[#171916] transition-colors break-all"
                  >
                    {PERSONAL_INFO.email}
                  </a>
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </section>
  );
}
