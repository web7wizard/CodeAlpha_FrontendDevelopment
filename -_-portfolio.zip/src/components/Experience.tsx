import { GraduationCap, Briefcase, Code, CheckCircle2 } from 'lucide-react';
import { EXPERIENCES } from '../data/portfolioData.ts';

const EXP_ICONS = {
  pccoe: GraduationCap,
  codealpha: Briefcase,
  projects: Code,
};

export default function Experience() {
  return (
    <section id="experience" className="py-20 md:py-28 border-b border-[#E3DFD5] scroll-mt-16">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-mono-label text-[#737A6F] uppercase tracking-wider">
              04 / Trajectory
            </span>
          </div>
          <h2 className="font-editorial text-3xl sm:text-4xl text-[#171916] font-normal tracking-tight">
            Experience & <span className="italic">Learning Journey</span>
          </h2>
          <p className="text-sm sm:text-base text-[#52584E] mt-3">
            An honest overview of academic background, internship training, and independent
            engineering exploration.
          </p>
        </div>

        {/* Timeline cards */}
        <div className="space-y-6">
          {EXPERIENCES.map((exp, index) => {
            const Icon = EXP_ICONS[exp.id as keyof typeof EXP_ICONS] || Code;
            return (
              <div
                key={exp.id}
                className="bg-[#EBE7DD]/80 border border-[#DDD6C8] rounded-xl p-6 sm:p-8 hover:border-[#171916]/30 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-[#E2DDCF] flex items-center justify-center text-[#171916]">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="font-editorial text-xl sm:text-2xl text-[#171916] font-normal">
                        {exp.role}
                      </h3>
                      <p className="text-sm font-medium text-[#40453D]">
                        {exp.organization}
                        {exp.location && (
                          <span className="text-xs font-normal text-[#737A6F] ml-2">
                            · {exp.location}
                          </span>
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="text-xs font-mono-label text-[#737A6F] sm:text-right pl-12 sm:pl-0">
                    <span className="inline-block bg-[#FAF9F5] px-2.5 py-1 rounded border border-[#DDD6C8] text-[#171916]">
                      {exp.highlightTag}
                    </span>
                    {exp.period && (
                      <span className="block mt-1 text-[#737A6F]">
                        {exp.period}
                      </span>
                    )}
                  </div>
                </div>

                <div className="sm:pl-12">
                  <p className="text-sm text-[#40453D] leading-relaxed max-w-3xl">
                    {exp.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
