import { useState } from 'react';
import { Mail, Github, Linkedin, Copy, Check, ArrowUpRight, MapPin } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData.ts';

export default function Contact() {
  const [copied, setCopied] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(PERSONAL_INFO.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <section id="contact" className="py-20 md:py-28 border-b border-[#E3DFD5] scroll-mt-16">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        <div className="bg-[#171916] text-[#F5F3ED] rounded-2xl p-8 sm:p-12 lg:p-16 relative overflow-hidden shadow-[0_20px_50px_rgba(23,25,22,0.12)]">
          {/* Subtle accent line at top */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-[#C8F169]" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
            {/* Left Column: Heading and Invite */}
            <div className="lg:col-span-7">
              <div className="flex items-center gap-2 mb-4">
                <span className="w-2 h-2 rounded-full bg-[#C8F169]" />
                <span className="text-xs font-mono-label uppercase tracking-widest text-[#A2A99D]">
                  05 / Get In Touch
                </span>
              </div>

              <h2 className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-normal tracking-tight text-white mb-6 leading-tight">
                Have a project <br className="hidden sm:inline" />
                <span className="italic text-[#C8F169]">in mind?</span>
              </h2>

              <p className="text-base text-[#C2C9BC] leading-relaxed max-w-lg mb-8">
                I am always open to discussing new web development projects, collaborative software
                engineering initiatives, or learning opportunities. Feel free to reach out directly.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4">
                <a
                  href={`mailto:${PERSONAL_INFO.email}`}
                  className="px-6 py-3.5 bg-[#C8F169] text-[#171916] text-sm font-semibold rounded hover:bg-[#bde65c] transition-colors inline-flex items-center gap-2 shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
                >
                  <Mail className="w-4 h-4" />
                  <span>Send an Email</span>
                </a>

                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="px-5 py-3.5 bg-[#252A23] border border-[#3A4237] text-[#E3DFD5] text-sm font-medium rounded hover:bg-[#30362E] transition-colors inline-flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
                  aria-label="Copy email address to clipboard"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-[#C8F169]" />
                      <span className="text-[#C8F169]">Email Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Address</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Right Column: Verified Contact Information Card */}
            <div className="lg:col-span-5 bg-[#20241E] border border-[#30382B] rounded-xl p-6 sm:p-7 text-sm">
              <h3 className="text-xs font-mono-label tracking-wider uppercase text-[#889182] pb-3 border-b border-[#30382B] mb-5">
                Contact Directory
              </h3>

              <div className="space-y-4">
                <div>
                  <span className="text-xs font-mono-label text-[#889182] block mb-1">
                    DIRECT EMAIL
                  </span>
                  <a
                    href={`mailto:${PERSONAL_INFO.email}`}
                    className="text-white hover:text-[#C8F169] transition-colors font-mono-label text-xs sm:text-sm break-all"
                  >
                    {PERSONAL_INFO.email}
                  </a>
                </div>

                <div className="pt-3 border-t border-[#30382B]">
                  <span className="text-xs font-mono-label text-[#889182] block mb-1">
                    LOCATION
                  </span>
                  <div className="flex items-center gap-2 text-[#D2D8CC] text-xs">
                    <MapPin className="w-3.5 h-3.5 text-[#C8F169]" />
                    <span>{PERSONAL_INFO.college}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#30382B] flex flex-col gap-2.5">
                  <span className="text-xs font-mono-label text-[#889182]">
                    EXTERNAL PROFILES
                  </span>

                  <div className="flex flex-col gap-2">
                    <a
                      href={PERSONAL_INFO.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-between p-2.5 rounded bg-[#171A15] border border-[#2B3326] text-xs text-[#E3DFD5] hover:text-white hover:border-[#C8F169]/40 transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <Github className="w-4 h-4 text-[#C8F169]" />
                        <span>GitHub (web7wizard)</span>
                      </span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-[#889182]" />
                    </a>

                    <a
                      href={PERSONAL_INFO.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-between p-2.5 rounded bg-[#171A15] border border-[#2B3326] text-xs text-[#E3DFD5] hover:text-white hover:border-[#C8F169]/40 transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <Linkedin className="w-4 h-4 text-[#C8F169]" />
                        <span>LinkedIn Profile</span>
                      </span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-[#889182]" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
