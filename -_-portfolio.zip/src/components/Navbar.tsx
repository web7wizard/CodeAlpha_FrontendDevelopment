import { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData.ts';

interface NavItem {
  name: string;
  href: string;
}

const NAV_ITEMS: NavItem[] = [
  { name: 'Home', href: '#home' },
  { name: 'About', href: '#about' },
  { name: 'Skills', href: '#skills' },
  { name: 'Projects', href: '#projects' },
  { name: 'Experience', href: '#experience' },
  { name: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);

      const sections = NAV_ITEMS.map((item) => item.href.substring(1));
      const scrollPosition = window.scrollY + 140;

      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && el.offsetTop <= scrollPosition) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 ${
        scrolled
          ? 'bg-[#F5F3ED]/95 backdrop-blur-md border-b border-[#E3DFD5] shadow-[0_2px_12px_rgba(23,25,22,0.03)]'
          : 'bg-[#F5F3ED]/80 backdrop-blur-sm border-b border-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto px-6 sm:px-8 h-18 flex items-center justify-between">
        {/* Logo / Wordmark */}
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            handleNavClick('#home');
          }}
          className="group flex items-baseline gap-2 text-[#171916] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#171916] rounded-sm"
        >
          <span className="font-editorial text-2xl tracking-tight font-medium group-hover:text-black transition-colors">
            {PERSONAL_INFO.name}
          </span>
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#C8F169] border border-[#171916]/30 self-center"></span>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-7" aria-label="Main navigation">
          {NAV_ITEMS.map((item) => {
            const isActive = activeSection === item.href.substring(1);
            return (
              <a
                key={item.name}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(item.href);
                }}
                className={`relative py-1 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#171916] rounded-sm ${
                  isActive
                    ? 'text-[#171916] font-medium'
                    : 'text-[#63685E] hover:text-[#171916]'
                }`}
              >
                {item.name}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#171916] rounded-full" />
                )}
              </a>
            );
          })}

          <div className="h-4 w-px bg-[#E3DFD5] mx-1" aria-hidden="true" />

          {/* Quick GitHub link in nav */}
          <a
            href={PERSONAL_INFO.github}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs font-mono-label text-[#52584E] hover:text-[#171916] transition-colors py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#171916]"
          >
            <span>GitHub</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </nav>

        {/* Mobile menu trigger */}
        <button
          type="button"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-[#171916] hover:bg-[#EAE6DC] rounded-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#171916]"
          aria-expanded={mobileMenuOpen}
          aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#F5F3ED] border-b border-[#E3DFD5] px-6 py-5 shadow-lg">
          <nav className="flex flex-col gap-3" aria-label="Mobile navigation">
            {NAV_ITEMS.map((item) => {
              const isActive = activeSection === item.href.substring(1);
              return (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick(item.href);
                  }}
                  className={`py-2 text-base flex items-center justify-between transition-colors ${
                    isActive
                      ? 'text-[#171916] font-semibold pl-2 border-l-2 border-[#171916]'
                      : 'text-[#52584E] hover:text-[#171916]'
                  }`}
                >
                  <span>{item.name}</span>
                  {isActive && <span className="w-2 h-2 rounded-full bg-[#C8F169] border border-[#171916]/40" />}
                </a>
              );
            })}

            <div className="pt-3 mt-2 border-t border-[#E3DFD5] flex items-center justify-between text-xs font-mono-label text-[#63685E]">
              <a
                href={PERSONAL_INFO.github}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 hover:text-[#171916] py-1"
              >
                GitHub <ArrowUpRight className="w-3 h-3" />
              </a>
              <a
                href={PERSONAL_INFO.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 hover:text-[#171916] py-1"
              >
                LinkedIn <ArrowUpRight className="w-3 h-3" />
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
