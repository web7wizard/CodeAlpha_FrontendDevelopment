import { ExternalLink, Github, Terminal, Activity, Wifi, Layers, ArrowUpRight } from 'lucide-react';
import { Project } from '../types.ts';
import { PROJECTS } from '../data/portfolioData.ts';

function ProjectVisualPreview({ project }: { project: Project }) {
  if (project.id === 'threat-0') {
    return (
      <div className="w-full h-44 bg-[#141613] rounded-t-lg p-4 flex flex-col justify-between font-mono-label text-xs text-[#E3DFD5] select-none border-b border-[#242822]">
        <div className="flex items-center justify-between text-[11px] text-[#8C9486]">
          <span className="flex items-center gap-1.5 text-[#C8F169]">
            <Terminal className="w-3.5 h-3.5" />
            THREAT-0 :: SIMULATION
          </span>
          <span className="text-[10px] bg-[#222720] px-2 py-0.5 rounded text-[#A4AC9E]">
            NETLIFY ACTIVE
          </span>
        </div>

        <div className="space-y-1.5 my-auto text-[11px]">
          <div className="flex items-center justify-between py-1 px-2 rounded bg-[#1B1F19] border border-[#2B3227]">
            <span className="text-[#D8DFD2]">[01] Phishing & MITM</span>
            <span className="text-[#C8F169] text-[10px]">ANALYZED</span>
          </div>
          <div className="flex items-center justify-between py-1 px-2 rounded bg-[#1B1F19] border border-[#2B3227]">
            <span className="text-[#D8DFD2]">[02] Ransomware & Malware</span>
            <span className="text-[#C8F169] text-[10px]">SIMULATED</span>
          </div>
        </div>

        <div className="flex items-center justify-between text-[10px] text-[#7A8275] pt-2 border-t border-[#222720]">
          <span>VECTORS: 5 MODULES</span>
          <span className="text-[#D2D8CC]">APPWRITE AUTH</span>
        </div>
      </div>
    );
  }

  if (project.id === 'gitinsight') {
    return (
      <div className="w-full h-44 bg-[#141613] rounded-t-lg p-4 flex flex-col justify-between font-mono-label text-xs text-[#E3DFD5] select-none border-b border-[#242822]">
        <div className="flex items-center justify-between text-[11px] text-[#8C9486]">
          <span className="flex items-center gap-1.5 text-[#C8F169]">
            <Activity className="w-3.5 h-3.5" />
            GIT-INSIGHT :: ANALYTICS
          </span>
          <span className="text-[10px] bg-[#222720] px-2 py-0.5 rounded text-[#A4AC9E]">
            GITHUB INSIGHTS
          </span>
        </div>

        {/* Abstract Activity Bar Chart */}
        <div className="my-auto py-2">
          <div className="flex items-end justify-between gap-1.5 h-16 px-1">
            {[40, 65, 30, 85, 55, 95, 70, 45, 80, 60, 90, 75].map((val, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <div
                  className="w-full rounded-t-xs transition-all duration-300"
                  style={{
                    height: `${val}%`,
                    backgroundColor: i === 5 || i === 10 ? '#C8F169' : '#2D342A',
                  }}
                />
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between text-[10px] text-[#7A8275] pt-2 border-t border-[#222720]">
          <span>COMMIT TELEMETRY</span>
          <span className="text-[#D2D8CC]">VITE + REACT</span>
        </div>
      </div>
    );
  }

  if (project.id === 'wifisense') {
    return (
      <div className="w-full h-44 bg-[#141613] rounded-t-lg p-4 flex flex-col justify-between font-mono-label text-xs text-[#E3DFD5] select-none border-b border-[#242822]">
        <div className="flex items-center justify-between text-[11px] text-[#8C9486]">
          <span className="flex items-center gap-1.5 text-[#C8F169]">
            <Wifi className="w-3.5 h-3.5" />
            WIFISENSE :: ML MODEL
          </span>
          <span className="text-[10px] bg-[#222720] px-2 py-0.5 rounded text-[#A4AC9E]">
            STREAMLIT
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 my-auto text-[11px]">
          <div className="bg-[#1B1F19] border border-[#2B3227] p-2 rounded">
            <span className="text-[10px] text-[#7A8275] block">SIGNAL (RSSI)</span>
            <span className="text-[#C8F169] font-medium">-48 dBm</span>
          </div>
          <div className="bg-[#1B1F19] border border-[#2B3227] p-2 rounded">
            <span className="text-[10px] text-[#7A8275] block">FREQUENCY BAND</span>
            <span className="text-[#D8DFD2] font-medium">5.0 GHz</span>
          </div>
        </div>

        <div className="flex items-center justify-between text-[10px] text-[#7A8275] pt-2 border-t border-[#222720]">
          <span>REGRESSION PIPELINE</span>
          <span className="text-[#D2D8CC]">PANDAS · SCIKIT-LEARN</span>
        </div>
      </div>
    );
  }

  // Default / Nexus
  return (
    <div className="w-full h-44 bg-[#141613] rounded-t-lg p-4 flex flex-col justify-between font-mono-label text-xs text-[#E3DFD5] select-none border-b border-[#242822]">
      <div className="flex items-center justify-between text-[11px] text-[#8C9486]">
        <span className="flex items-center gap-1.5 text-[#C8F169]">
          <Layers className="w-3.5 h-3.5" />
          NEXUS :: ARCHITECTURE
        </span>
        <span className="text-[10px] bg-[#222720] px-2 py-0.5 rounded text-[#A4AC9E]">
          CORE MODULE
        </span>
      </div>

      <div className="my-auto space-y-1.5 text-[11px]">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#C8F169]" />
          <span className="text-[#D8DFD2]">Core System Interface Layer</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#8C9486]" />
          <span className="text-[#A4AC9E]">Component Registry & State Store</span>
        </div>
      </div>

      <div className="flex items-center justify-between text-[10px] text-[#7A8275] pt-2 border-t border-[#222720]">
        <span>MODULAR DESIGN</span>
        <span className="text-[#D2D8CC]">TYPESCRIPT</span>
      </div>
    </div>
  );
}

export default function Projects() {
  return (
    <section id="projects" className="py-20 md:py-28 border-b border-[#E3DFD5] scroll-mt-16">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-mono-label text-[#737A6F] uppercase tracking-wider">
              03 / Engineering
            </span>
          </div>
          <h2 className="font-editorial text-3xl sm:text-4xl text-[#171916] font-normal tracking-tight">
            Selected <span className="italic">Projects</span>
          </h2>
          <p className="text-sm sm:text-base text-[#52584E] mt-3">
            Independent software applications and systems covering cybersecurity simulation, developer
            analytics, and machine learning throughput modeling.
          </p>
        </div>

        {/* 2x2 Responsive Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          {PROJECTS.map((project) => (
            <article
              key={project.id}
              className="bg-[#EBE7DD]/80 border border-[#DDD6C8] rounded-xl flex flex-col justify-between overflow-hidden hover:border-[#171916]/40 transition-colors shadow-[0_4px_20px_rgba(23,25,22,0.02)]"
            >
              {/* CSS Visual Preview */}
              <ProjectVisualPreview project={project} />

              {/* Card Body */}
              <div className="p-6 sm:p-7 flex flex-col flex-1 justify-between">
                <div>
                  {/* Category and subtle tag */}
                  <div className="flex items-center justify-between gap-2 mb-2 text-xs font-mono-label text-[#737A6F]">
                    <span>{project.category}</span>
                    {project.accentLabel && (
                      <span className="text-[#171916] font-medium">
                        {project.accentLabel}
                      </span>
                    )}
                  </div>

                  {/* Project Title */}
                  <h3 className="font-editorial text-2xl sm:text-3xl text-[#171916] font-normal tracking-tight mb-3">
                    {project.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-[#40453D] leading-relaxed mb-5">
                    {project.description}
                  </p>
                </div>

                <div>
                  {/* Tech stack metadata (zero-pill discipline) */}
                  <div className="py-3 border-t border-[#DDD6C8] text-xs font-mono-label text-[#52584E] flex items-center flex-wrap gap-x-2 gap-y-1 mb-5">
                    <span className="text-[#848B7F]">Tech:</span>
                    {project.technologies.map((tech, i) => (
                      <span key={tech} className="inline-flex items-center">
                        <span className="text-[#171916] font-medium">{tech}</span>
                        {i < project.technologies.length - 1 && (
                          <span className="text-[#BDB7A9] ml-2" aria-hidden="true">·</span>
                        )}
                      </span>
                    ))}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap items-center gap-3">
                    {project.liveUrl && (
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2 bg-[#171916] text-[#F5F3ED] text-xs font-medium rounded hover:bg-[#2A2E28] transition-colors inline-flex items-center gap-1.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#171916]"
                      >
                        <span>Live Demo</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}

                    {project.repoUrl && (
                      <a
                        href={project.repoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2 bg-transparent border border-[#171916] text-[#171916] text-xs font-medium rounded hover:bg-[#EAE6DC] transition-colors inline-flex items-center gap-1.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#171916]"
                      >
                        <Github className="w-3.5 h-3.5" />
                        <span>Source Code</span>
                      </a>
                    )}

                    {project.profileUrl && !project.repoUrl && (
                      <a
                        href={project.profileUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2 bg-transparent border border-[#171916] text-[#171916] text-xs font-medium rounded hover:bg-[#EAE6DC] transition-colors inline-flex items-center gap-1.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#171916]"
                      >
                        <Github className="w-3.5 h-3.5" />
                        <span>GitHub Profile</span>
                        <ArrowUpRight className="w-3 h-3 text-[#737A6F]" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
