import { Code, Layout, Wrench, Compass } from 'lucide-react';
import { SKILL_CATEGORIES } from '../data/portfolioData.ts';

const CATEGORY_ICONS = [
  Code,
  Layout,
  Wrench,
  Compass,
];

export default function Skills() {
  return (
    <section id="skills" className="py-20 md:py-28 border-b border-[#E3DFD5] scroll-mt-16">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-mono-label text-[#737A6F] uppercase tracking-wider">
              02 / Capabilities
            </span>
          </div>
          <h2 className="font-editorial text-3xl sm:text-4xl text-[#171916] font-normal tracking-tight">
            Technical <span className="italic">Skills</span> & Interests
          </h2>
          <p className="text-sm sm:text-base text-[#52584E] mt-3">
            Organized proficiencies and technical topics explored through academic engineering
            coursework and hands-on software development.
          </p>
        </div>

        {/* Organized 4-Group Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          {SKILL_CATEGORIES.map((category, idx) => {
            const Icon = CATEGORY_ICONS[idx % CATEGORY_ICONS.length];
            return (
              <div
                key={category.title}
                className="bg-[#EBE7DD]/70 border border-[#DDD6C8] rounded-xl p-6 sm:p-8 flex flex-col justify-between hover:border-[#C2BCB0] transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-[#E2DDCF] flex items-center justify-center text-[#171916]">
                        <Icon className="w-4 h-4" />
                      </div>
                      <h3 className="font-editorial text-xl sm:text-2xl text-[#171916] font-normal">
                        {category.title}
                      </h3>
                    </div>
                    <span className="text-[11px] font-mono-label text-[#737A6F]">
                      {category.skills.length} AREAS
                    </span>
                  </div>

                  <p className="text-xs text-[#52584E] mb-6">
                    {category.description}
                  </p>
                </div>

                {/* Skills list - clean unboxed typographic grid */}
                <div className="pt-4 border-t border-[#DDD6C8]/80">
                  <div className="flex flex-wrap gap-2 sm:gap-2.5">
                    {category.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-3 py-1.5 bg-[#FAF9F5] border border-[#DDD6C8] rounded text-xs font-mono-label text-[#171916] hover:border-[#171916]/40 transition-colors"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Quiet footnote regarding verified proficiency */}
        <div className="mt-8 text-center">
          <p className="text-xs font-mono-label text-[#737A6F]">
            Technologies reflect verified coursework, projects, and active study areas.
          </p>
        </div>
      </div>
    </section>
  );
}
