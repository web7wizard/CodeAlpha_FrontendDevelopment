import { Project, SkillCategory, ExperienceItem } from '../types.ts';

export const PERSONAL_INFO = {
  name: 'Javeriya Jamadar',
  shortName: 'Javeriya',
  initials: 'JJ',
  role: 'Computer Engineering Student | Frontend Developer | Aspiring Software Engineer',
  tagline: 'Building thoughtful digital experiences.',
  bioSnippet:
    'Computer Engineering undergraduate with a focus on frontend development, software engineering, artificial intelligence, and cybersecurity. Passionate about building functional, well-architected web applications.',
  college: 'Pimpri Chinchwad College of Engineering (PCCOE), Pune, Maharashtra, India',
  email: 'javeriya.jamadar26@pccoepune.org',
  location: 'Pune, Maharashtra, India',
  github: 'https://github.com/web7wizard',
  linkedin: 'https://www.linkedin.com/in/javeriya-jamadar/',
  githubUsername: 'web7wizard',
};

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: 'Programming',
    description: 'Foundational languages and algorithmic problem solving',
    skills: ['C', 'C++', 'Java', 'Python', 'JavaScript', 'SQL'],
  },
  {
    title: 'Frontend',
    description: 'Component architecture, user interfaces, and responsive web design',
    skills: ['HTML', 'CSS', 'React', 'Vite', 'TypeScript'],
  },
  {
    title: 'Tools & Platforms',
    description: 'Version control, deployment pipelines, and backend services',
    skills: ['Git', 'GitHub', 'Netlify', 'Appwrite'],
  },
  {
    title: 'Other Interests',
    description: 'Specialized domains and emerging computer science fields',
    skills: ['AI', 'Data Analytics', 'Cybersecurity'],
  },
];

export const PROJECTS: Project[] = [
  {
    id: 'threat-0',
    title: 'Threat-0',
    category: 'Cybersecurity Learning Simulator',
    description:
      'An interactive cybersecurity learning simulator covering topics such as phishing, malware, ransomware, worms, and man-in-the-middle attacks. Designed to help students and developers visualize threat vectors and defense mechanisms through simulated attack scenarios.',
    technologies: ['JavaScript', 'Appwrite', 'Netlify'],
    liveUrl: 'https://threat-0.netlify.app',
    repoUrl: 'https://github.com/web7wizard/Threat_0',
    accentLabel: 'Interactive Simulation',
  },
  {
    id: 'gitinsight',
    title: 'GitInsight',
    category: 'Developer Insights & Repository Analytics',
    description:
      'A GitHub analytics and insights web application designed to evaluate repository metrics, inspect developer activity, and analyze commit patterns through structured data visualization.',
    technologies: ['React', 'Vite', 'GitHub API', 'JavaScript'],
    liveUrl: 'https://git-insight-ai.netlify.app',
    profileUrl: 'https://github.com/web7wizard',
    accentLabel: 'Developer Tool',
  },
  {
    id: 'wifisense',
    title: 'WiFiSense',
    fullTitle: 'WiFiSense: Wi-Fi Performance Analysis & Machine Learning Throughput Modeling',
    category: 'Machine Learning & Wireless Analysis',
    description:
      'A Python and Streamlit application exploring Wi-Fi performance and throughput prediction using inputs such as signal strength, distance, connected devices, channel, band, latency, and packet loss.',
    technologies: ['Python', 'Pandas', 'scikit-learn', 'Streamlit'],
    profileUrl: 'https://github.com/web7wizard',
    accentLabel: 'ML Modeling',
  },
  {
    id: 'nexus',
    title: 'Nexus',
    category: 'Software Engineering & Architecture',
    description:
      'A modular software development project focused on clean system architecture, component modularity, and modern web engineering practices.',
    technologies: ['TypeScript', 'React', 'Web Stack'],
    profileUrl: 'https://github.com/web7wizard',
    accentLabel: 'System Architecture',
  },
];

export const EXPERIENCES: ExperienceItem[] = [
  {
    id: 'pccoe',
    role: 'Computer Engineering Student',
    organization: 'Pimpri Chinchwad College of Engineering (PCCOE)',
    location: 'Pune, Maharashtra, India',
    period: 'Undergraduate Program',
    description:
      'Pursuing Bachelor of Engineering in Computer Engineering. Developing strong foundations in data structures, algorithms, object-oriented programming, database management, and computer networks while building independent software projects.',
    highlightTag: 'Education',
  },
  {
    id: 'codealpha',
    role: 'Web Development Intern',
    organization: 'CodeAlpha',
    period: 'Internship Learning',
    description:
      'Gained practical frontend experience building responsive web pages, working with DOM manipulation, styling architectures, and collaborating on structured development tasks.',
    highlightTag: 'Internship',
  },
  {
    id: 'projects',
    role: 'Independent Project Developer',
    organization: 'Personal & Academic Engineering',
    period: 'Continuous Practice',
    description:
      'Designing and developing end-to-end applications across web engineering, interactive cybersecurity simulations (Threat-0), developer analytics (GitInsight), and machine learning explorations (WiFiSense).',
    highlightTag: 'Practical Engineering',
  },
];
