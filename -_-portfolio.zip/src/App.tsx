/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from './components/Navbar.tsx';
import Hero from './components/Hero.tsx';
import About from './components/About.tsx';
import Skills from './components/Skills.tsx';
import Projects from './components/Projects.tsx';
import Experience from './components/Experience.tsx';
import Contact from './components/Contact.tsx';
import Footer from './components/Footer.tsx';

export default function App() {
  return (
    <div className="min-h-screen bg-[#F5F3ED] text-[#171916] flex flex-col font-sans selection:bg-[#C8F169] selection:text-[#171916]">
      {/* A. Navigation */}
      <Navbar />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* B. Hero Section */}
        <Hero />

        {/* C. About */}
        <About />

        {/* D. Skills */}
        <Skills />

        {/* E. Selected Projects */}
        <Projects />

        {/* F. Experience and Learning */}
        <Experience />

        {/* G. Contact */}
        <Contact />
      </main>

      {/* H. Footer */}
      <Footer />
    </div>
  );
}
