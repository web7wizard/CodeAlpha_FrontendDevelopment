/**
 * SONORA — Playlist Management Module
 * Orchestrates playlist entities, resolution of track IDs, and playlist CRUD.
 */

import { Storage } from './storage.js';
import { DEFAULT_TRACKS } from './tracks.js';

export const Playlists = {
  // Find track object by ID
  getTrackById(id) {
    return DEFAULT_TRACKS.find(t => t.id === id) || null;
  },

  // Map array of IDs to Track objects
  resolveTracks(trackIds) {
    if (!Array.isArray(trackIds)) return [];
    return trackIds
      .map(id => this.getTrackById(id))
      .filter(t => t !== null);
  },

  // Get all user playlists
  getAll() {
    return Storage.getPlaylists();
  },

  getById(playlistId) {
    return this.getAll().find(p => p.id === playlistId) || null;
  },

  create(name, description) {
    return Storage.createPlaylist(name, description);
  },

  rename(playlistId, name, description) {
    return Storage.renamePlaylist(playlistId, name, description);
  },

  delete(playlistId) {
    return Storage.deletePlaylist(playlistId);
  },

  addTrack(playlistId, trackId) {
    return Storage.addTrackToPlaylist(playlistId, trackId);
  },

  removeTrack(playlistId, trackId) {
    return Storage.removeTrackFromPlaylist(playlistId, trackId);
  },

  // Special Virtual Playlists
  getLikedPlaylist() {
    const ids = Storage.getLikedSongs();
    const tracks = this.resolveTracks(ids);
    const totalDuration = tracks.reduce((sum, t) => sum + (t.duration || 0), 0);

    return {
      id: 'system-liked',
      name: 'Liked Songs',
      description: 'Your personal collection of bookmarked favorites across Sonora.',
      isSystem: true,
      artwork: '/assets/images/cover_01.svg',
      trackIds: ids,
      tracks,
      totalDuration
    };
  },

  getRecentlyPlayedPlaylist() {
    const ids = Storage.getRecentlyPlayed();
    const tracks = this.resolveTracks(ids);
    const totalDuration = tracks.reduce((sum, t) => sum + (t.duration || 0), 0);

    return {
      id: 'system-recent',
      name: 'Recently Played',
      description: 'Listening history from your current sessions.',
      isSystem: true,
      artwork: '/assets/images/cover_02.svg',
      trackIds: ids,
      tracks,
      totalDuration
    };
  },

  getFeaturedPlaylist() {
    const tracks = DEFAULT_TRACKS.filter(t => t.featured);
    return {
      id: 'system-featured',
      name: 'Midnight Studio Curations',
      description: 'Handcrafted analog synths, mellow lo-fi beats, and atmospheric soundscapes.',
      isSystem: true,
      artwork: '/assets/images/cover_04.svg',
      trackIds: tracks.map(t => t.id),
      tracks,
      totalDuration: tracks.reduce((sum, t) => sum + (t.duration || 0), 0)
    };
  }
};
