/**
 * SONORA — Application Controller
 * Orchestrates views, player events, search, playlists, modals, and keyboard interactions.
 */

import { DEFAULT_TRACKS, GENRES, formatTime } from './tracks.js';
import { Storage } from './storage.js';
import { SonoraPlayer } from './player.js';
import { Playlists } from './playlists.js';

class SonoraApp {
  constructor() {
    this.player = new SonoraPlayer();
    this.currentView = 'home';
    this.currentPlaylistId = null;
    this.viewHistory = ['home'];
    this.historyIndex = 0;

    // Filter & Sort State
    this.activeGenre = 'All';
    this.currentSort = 'featured';

    // Context Menu State
    this.contextTargetTrack = null;

    // Cached DOM Elements
    this.dom = {
      sidebar: document.getElementById('sidebar'),
      mobileMenuBtn: document.getElementById('mobile-menu-btn'),
      navButtons: document.querySelectorAll('.nav-item-btn'),
      sidebarPlaylistsList: document.getElementById('sidebar-playlists-list'),
      btnAddPlaylist: document.getElementById('btn-add-playlist'),
      btnOpenShortcuts: document.getElementById('btn-open-shortcuts'),
      likedCountBadge: document.getElementById('liked-count-badge'),

      // Top Navbar
      btnNavBack: document.getElementById('btn-nav-back'),
      btnNavForward: document.getElementById('btn-nav-forward'),
      globalSearchInput: document.getElementById('global-search-input'),
      searchClearBtn: document.getElementById('search-clear-btn'),
      btnToggleQueue: document.getElementById('btn-toggle-queue'),
      topbarQueueCount: document.getElementById('topbar-queue-count'),

      // View sections
      views: {
        home: document.getElementById('view-home'),
        discover: document.getElementById('view-discover'),
        library: document.getElementById('view-library'),
        liked: document.getElementById('view-liked'),
        recent: document.getElementById('view-recent'),
        'playlist-detail': document.getElementById('view-playlist-detail'),
        'search-results': document.getElementById('view-search-results')
      },

      // Home View
      homePopularTracks: document.getElementById('home-popular-tracks'),
      homeCuratedCards: document.getElementById('home-curated-cards'),
      btnHeroPlay: document.getElementById('btn-hero-play'),
      btnHeroQueue: document.getElementById('btn-hero-queue'),

      // Discover View
      discoverGenreBar: document.getElementById('discover-genre-bar'),
      discoverSortSelect: document.getElementById('discover-sort-select'),
      discoverCardsGrid: document.getElementById('discover-cards-grid'),
      discoverTracksTable: document.getElementById('discover-tracks-table'),

      // Library View
      libraryTracksTable: document.getElementById('library-tracks-table'),
      btnLibraryPlayAll: document.getElementById('btn-library-play-all'),
      btnLibraryShuffle: document.getElementById('btn-library-shuffle'),

      // Liked View
      likedTracksTable: document.getElementById('liked-tracks-table'),
      likedSummaryText: document.getElementById('liked-summary-text'),
      btnLikedPlayAll: document.getElementById('btn-liked-play-all'),

      // Recent View
      recentTracksTable: document.getElementById('recent-tracks-table'),
      btnClearRecent: document.getElementById('btn-clear-recent'),

      // Playlist Detail View
      playlistDetailArt: document.getElementById('playlist-detail-art'),
      playlistDetailName: document.getElementById('playlist-detail-name'),
      playlistDetailDesc: document.getElementById('playlist-detail-desc'),
      playlistDetailTracks: document.getElementById('playlist-detail-tracks'),
      btnPlayPlaylist: document.getElementById('btn-play-playlist'),
      btnEditPlaylist: document.getElementById('btn-edit-playlist'),
      btnDeletePlaylist: document.getElementById('btn-delete-playlist'),

      // Search Results View
      searchQuerySummary: document.getElementById('search-query-summary'),
      searchTracksTable: document.getElementById('search-tracks-table'),

      // Persistent Player
      playerArtwork: document.getElementById('player-artwork'),
      playerTitle: document.getElementById('player-title'),
      playerArtist: document.getElementById('player-artist'),
      playerLikeBtn: document.getElementById('player-like-btn'),
      btnMasterPlay: document.getElementById('btn-master-play'),
      masterPlayIcon: document.getElementById('master-play-icon'),
      btnPrev: document.getElementById('btn-prev'),
      btnNext: document.getElementById('btn-next'),
      btnShuffle: document.getElementById('btn-shuffle'),
      btnRepeat: document.getElementById('btn-repeat'),
      repeatBadgeOne: document.getElementById('repeat-badge-one'),
      currentTimeDisplay: document.getElementById('current-time-display'),
      totalDurationDisplay: document.getElementById('total-duration-display'),
      progressTrack: document.getElementById('progress-track'),
      progressFill: document.getElementById('progress-fill'),
      progressThumb: document.getElementById('progress-thumb'),
      seekTooltip: document.getElementById('seek-tooltip'),
      playerEq: document.getElementById('player-eq'),
      btnMute: document.getElementById('btn-mute'),
      volumeIcon: document.getElementById('volume-icon'),
      volumeTrack: document.getElementById('volume-track'),
      volumeFill: document.getElementById('volume-fill'),

      // Queue Drawer
      queueDrawer: document.getElementById('queue-drawer'),
      queueContent: document.getElementById('queue-content'),
      btnCloseQueue: document.getElementById('btn-close-queue'),
      btnClearQueue: document.getElementById('btn-clear-queue'),

      // Modals
      playlistModal: document.getElementById('playlist-modal'),
      playlistForm: document.getElementById('playlist-form'),
      playlistModalId: document.getElementById('playlist-modal-id'),
      playlistNameInput: document.getElementById('playlist-name-input'),
      playlistDescInput: document.getElementById('playlist-desc-input'),
      modalPlaylistTitle: document.getElementById('modal-playlist-title'),
      btnClosePlaylistModal: document.getElementById('btn-close-playlist-modal'),
      btnCancelPlaylistModal: document.getElementById('btn-cancel-playlist-modal'),

      shortcutsModal: document.getElementById('shortcuts-modal'),
      btnCloseShortcutsModal: document.getElementById('btn-close-shortcuts-modal'),

      // Context Menu
      trackContextMenu: document.getElementById('track-context-menu'),
      ctxPlayNow: document.getElementById('ctx-play-now'),
      ctxPlayNext: document.getElementById('ctx-play-next'),
      ctxAddQueue: document.getElementById('ctx-add-queue'),
      ctxToggleLike: document.getElementById('ctx-toggle-like'),
      ctxLikeLabel: document.getElementById('ctx-like-label'),
      ctxPlaylistOptions: document.getElementById('ctx-playlist-options'),

      // Toast
      toastContainer: document.getElementById('toast-container')
    };

    this.init();
  }

  init() {
    this._bindPlayerEvents();
    this._bindUIEvents();
    this._bindKeyboardShortcuts();

    // Setup initial queue and track
    const savedQueueIds = Storage.getQueue();
    let initialTracks = [];
    if (savedQueueIds.length > 0) {
      initialTracks = Playlists.resolveTracks(savedQueueIds);
    }
    if (initialTracks.length === 0) {
      initialTracks = [...DEFAULT_TRACKS];
    }

    const lastPlayedId = Storage.getLastPlayedId();
    let startIndex = 0;
    if (lastPlayedId) {
      const idx = initialTracks.findIndex(t => t.id === lastPlayedId);
      if (idx !== -1) startIndex = idx;
    }

    this.player.setQueue(initialTracks, startIndex, false);

    // Initial render
    this.renderSidebarPlaylists();
    this.updateLikedBadge();
    this.renderHomeView();
    this.renderDiscoverView();
    this.renderLibraryView();
    this.updatePlayerUI();
  }

  // Bind audio player callbacks to UI
  _bindPlayerEvents() {
    this.player.on('trackChange', (track) => {
      this.updatePlayerUI();
      this.highlightPlayingRows();
      this.renderQueueDrawer();
      this.updateLikedBadge();
    });

    this.player.on('playState', (isPlaying) => {
      this.updatePlayStateUI(isPlaying);
      this.highlightPlayingRows();
    });

    this.player.on('timeUpdate', ({ currentTime, duration, progress }) => {
      this.dom.currentTimeDisplay.textContent = formatTime(currentTime);
      this.dom.totalDurationDisplay.textContent = formatTime(duration);
      this.dom.progressFill.style.width = `${progress}%`;
      this.dom.progressThumb.style.left = `${progress}%`;
    });

    this.player.on('durationChange', (duration) => {
      this.dom.totalDurationDisplay.textContent = formatTime(duration);
    });

    this.player.on('volumeChange', ({ volume, isMuted }) => {
      this.updateVolumeUI(volume, isMuted);
    });

    this.player.on('queueChange', ({ queue, index }) => {
      this.dom.topbarQueueCount.textContent = queue.length;
      this.renderQueueDrawer();
    });

    this.player.on('repeatModeChange', (mode) => {
      this.updateRepeatUI(mode);
    });

    this.player.on('shuffleChange', (isShuffle) => {
      this.updateShuffleUI(isShuffle);
    });

    this.player.on('error', ({ track, message }) => {
      this.showToast(message || 'Playback error. Switching to next track...', 'error');
    });
  }

  // Bind user interaction events
  _bindUIEvents() {
    // Navigation items
    this.dom.navButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.dataset.view;
        if (view) this.navigateTo(view);
      });
    });

    // History buttons
    this.dom.btnNavBack.addEventListener('click', () => this.navigateBack());
    this.dom.btnNavForward.addEventListener('click', () => this.navigateForward());

    // Mobile menu
    this.dom.mobileMenuBtn.addEventListener('click', () => {
      this.dom.sidebar.classList.toggle('mobile-open');
    });

    // Quick links in Home
    document.querySelectorAll('.section-link[data-view]').forEach(link => {
      link.addEventListener('click', () => {
        this.navigateTo(link.dataset.view);
      });
    });

    // Global Search
    this.dom.globalSearchInput.addEventListener('input', (e) => {
      const query = e.target.value.trim();
      if (query.length > 0) {
        this.dom.searchClearBtn.classList.add('visible');
        this.renderSearchResults(query);
        this.navigateTo('search-results', null, false);
      } else {
        this.dom.searchClearBtn.classList.remove('visible');
        if (this.currentView === 'search-results') {
          this.navigateTo('home');
        }
      }
    });

    this.dom.searchClearBtn.addEventListener('click', () => {
      this.dom.globalSearchInput.value = '';
      this.dom.searchClearBtn.classList.remove('visible');
      this.navigateTo('home');
    });

    // Queue Toggle
    this.dom.btnToggleQueue.addEventListener('click', () => this.toggleQueueDrawer());
    this.dom.btnCloseQueue.addEventListener('click', () => this.toggleQueueDrawer(false));
    this.dom.btnClearQueue.addEventListener('click', () => {
      this.player.clearQueue();
      this.showToast('Queue cleared');
    });

    // Master player controls
    this.dom.btnMasterPlay.addEventListener('click', () => this.player.togglePlay());
    this.dom.btnPrev.addEventListener('click', () => this.player.prevTrack());
    this.dom.btnNext.addEventListener('click', () => this.player.nextTrack());
    this.dom.btnShuffle.addEventListener('click', () => {
      const state = this.player.toggleShuffle();
      this.showToast(state ? 'Shuffle enabled' : 'Shuffle disabled');
    });
    this.dom.btnRepeat.addEventListener('click', () => {
      const mode = this.player.cycleRepeatMode();
      const labels = { off: 'Repeat off', all: 'Repeat all', one: 'Repeat one' };
      this.showToast(labels[mode]);
    });

    // Like in player bar
    this.dom.playerLikeBtn.addEventListener('click', () => {
      if (this.player.currentTrack) {
        const isLiked = Storage.toggleLike(this.player.currentTrack.id);
        this.updatePlayerUI();
        this.updateLikedBadge();
        this.highlightPlayingRows();
        this.showToast(isLiked ? 'Added to Liked Songs' : 'Removed from Liked Songs');
        if (this.currentView === 'liked') this.renderLikedView();
      }
    });

    // Progress Bar Scrubber
    this._setupProgressBar();

    // Volume Track Scrubber
    this._setupVolumeBar();

    // Featured Hero Action Buttons
    this.dom.btnHeroPlay.addEventListener('click', () => {
      const track = DEFAULT_TRACKS[0];
      this.player.setQueue([track, ...DEFAULT_TRACKS.slice(1)], 0, true);
    });

    this.dom.btnHeroQueue.addEventListener('click', () => {
      const track = DEFAULT_TRACKS[0];
      this.player.addToQueue(track);
      this.showToast(`Added "${track.title}" to queue`);
    });

    // Library batch actions
    this.dom.btnLibraryPlayAll.addEventListener('click', () => {
      this.player.setQueue([...DEFAULT_TRACKS], 0, true);
      this.showToast('Playing all 10 tracks');
    });

    this.dom.btnLibraryShuffle.addEventListener('click', () => {
      if (!this.player.isShuffle) this.player.toggleShuffle();
      const randIdx = Math.floor(Math.random() * DEFAULT_TRACKS.length);
      this.player.setQueue([...DEFAULT_TRACKS], randIdx, true);
      this.showToast('Shuffling library');
    });

    // Liked play all
    this.dom.btnLikedPlayAll.addEventListener('click', () => {
      const likedPlaylist = Playlists.getLikedPlaylist();
      if (likedPlaylist.tracks.length > 0) {
        this.player.setQueue(likedPlaylist.tracks, 0, true);
      } else {
        this.showToast('No liked songs to play yet');
      }
    });

    // Clear history
    this.dom.btnClearRecent.addEventListener('click', () => {
      Storage.clearRecentlyPlayed();
      this.renderRecentView();
      this.showToast('Listening history cleared');
    });

    // Playlist CRUD
    this.dom.btnAddPlaylist.addEventListener('click', () => {
      this.openPlaylistModal();
    });

    this.dom.btnClosePlaylistModal.addEventListener('click', () => this.closePlaylistModal());
    this.dom.btnCancelPlaylistModal.addEventListener('click', () => this.closePlaylistModal());

    this.dom.playlistForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const id = this.dom.playlistModalId.value;
      const name = this.dom.playlistNameInput.value.trim();
      const desc = this.dom.playlistDescInput.value.trim();

      if (!name) return;

      if (id) {
        // Edit existing
        Playlists.rename(id, name, desc);
        this.showToast('Playlist updated');
        if (this.currentView === 'playlist-detail' && this.currentPlaylistId === id) {
          this.renderPlaylistDetailView(id);
        }
      } else {
        // Create new
        const newPl = Playlists.create(name, desc);
        this.showToast(`Created playlist "${newPl.name}"`);
        this.navigateTo('playlist-detail', { id: newPl.id });
      }

      this.renderSidebarPlaylists();
      this.closePlaylistModal();
    });

    this.dom.btnPlayPlaylist.addEventListener('click', () => {
      if (this.currentPlaylistId) {
        const pl = Playlists.getById(this.currentPlaylistId);
        if (pl) {
          const tracks = Playlists.resolveTracks(pl.trackIds);
          if (tracks.length > 0) {
            this.player.setQueue(tracks, 0, true);
          } else {
            this.showToast('This playlist is currently empty. Add tracks below!');
          }
        }
      }
    });

    this.dom.btnEditPlaylist.addEventListener('click', () => {
      if (this.currentPlaylistId) {
        const pl = Playlists.getById(this.currentPlaylistId);
        if (pl) {
          this.openPlaylistModal(pl);
        }
      }
    });

    this.dom.btnDeletePlaylist.addEventListener('click', () => {
      if (this.currentPlaylistId) {
        const pl = Playlists.getById(this.currentPlaylistId);
        if (pl && confirm(`Delete playlist "${pl.name}"?`)) {
          Playlists.delete(this.currentPlaylistId);
          this.showToast(`Deleted "${pl.name}"`);
          this.renderSidebarPlaylists();
          this.navigateTo('home');
        }
      }
    });

    // Shortcuts Modal
    this.dom.btnOpenShortcuts.addEventListener('click', () => {
      this.dom.shortcutsModal.classList.add('open');
    });

    this.dom.btnCloseShortcutsModal.addEventListener('click', () => {
      this.dom.shortcutsModal.classList.remove('open');
    });

    // Context menu items
    this.dom.ctxPlayNow.addEventListener('click', () => {
      if (this.contextTargetTrack) {
        this.player.setQueue([this.contextTargetTrack, ...DEFAULT_TRACKS.filter(t => t.id !== this.contextTargetTrack.id)], 0, true);
      }
      this.closeContextMenu();
    });

    this.dom.ctxPlayNext.addEventListener('click', () => {
      if (this.contextTargetTrack) {
        this.player.addToQueue(this.contextTargetTrack, true);
        this.showToast(`"${this.contextTargetTrack.title}" will play next`);
      }
      this.closeContextMenu();
    });

    this.dom.ctxAddQueue.addEventListener('click', () => {
      if (this.contextTargetTrack) {
        this.player.addToQueue(this.contextTargetTrack, false);
        this.showToast(`Added "${this.contextTargetTrack.title}" to queue`);
      }
      this.closeContextMenu();
    });

    this.dom.ctxToggleLike.addEventListener('click', () => {
      if (this.contextTargetTrack) {
        const isLiked = Storage.toggleLike(this.contextTargetTrack.id);
        this.updatePlayerUI();
        this.updateLikedBadge();
        this.highlightPlayingRows();
        this.showToast(isLiked ? 'Added to Liked Songs' : 'Removed from Liked Songs');
        if (this.currentView === 'liked') this.renderLikedView();
      }
      this.closeContextMenu();
    });

    // Close overlays on outside click
    window.addEventListener('click', (e) => {
      if (!this.dom.trackContextMenu.contains(e.target)) {
        this.closeContextMenu();
      }
      if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('open');
      }
    });
  }

  _setupProgressBar() {
    let isDragging = false;

    const calculatePercent = (e) => {
      const rect = this.dom.progressTrack.getBoundingClientRect();
      const pos = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
      return (pos / rect.width) * 100;
    };

    this.dom.progressTrack.addEventListener('mousedown', (e) => {
      isDragging = true;
      const percent = calculatePercent(e);
      this.player.seekPercent(percent);
    });

    window.addEventListener('mousemove', (e) => {
      if (isDragging) {
        const percent = calculatePercent(e);
        this.player.seekPercent(percent);
      }
    });

    window.addEventListener('mouseup', () => {
      isDragging = false;
    });

    // Tooltip preview
    this.dom.progressTrack.addEventListener('mousemove', (e) => {
      const rect = this.dom.progressTrack.getBoundingClientRect();
      const pos = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
      const percent = pos / rect.width;
      const targetTime = percent * (this.player.duration || 0);

      this.dom.seekTooltip.textContent = formatTime(targetTime);
      this.dom.seekTooltip.style.left = `${pos}px`;
    });
  }

  _setupVolumeBar() {
    let isDragging = false;

    const setVolFromEvent = (e) => {
      const rect = this.dom.volumeTrack.getBoundingClientRect();
      const pos = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
      const vol = pos / rect.width;
      this.player.setVolume(vol);
    };

    this.dom.volumeTrack.addEventListener('mousedown', (e) => {
      isDragging = true;
      setVolFromEvent(e);
    });

    window.addEventListener('mousemove', (e) => {
      if (isDragging) {
        setVolFromEvent(e);
      }
    });

    window.addEventListener('mouseup', () => {
      isDragging = false;
    });

    this.dom.btnMute.addEventListener('click', () => {
      this.player.toggleMute();
    });
  }

  _bindKeyboardShortcuts() {
    window.addEventListener('keydown', (e) => {
      // Ignore if user is typing in input or textarea
      const tag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
      if (tag === 'input' || tag === 'textarea' || document.activeElement.isContentEditable) {
        if (e.key === 'Escape') {
          document.activeElement.blur();
        }
        return;
      }

      switch (e.key) {
        case ' ': // Space: Play / Pause
          e.preventDefault();
          this.player.togglePlay();
          break;

        case 'ArrowLeft': // Seek back 5s
          e.preventDefault();
          this.player.seek(this.player.currentTime - 5);
          this.showToast('Seek -5s');
          break;

        case 'ArrowRight': // Seek forward 5s
          e.preventDefault();
          this.player.seek(this.player.currentTime + 5);
          this.showToast('Seek +5s');
          break;

        case 'ArrowUp': // Volume up 5%
          e.preventDefault();
          this.player.setVolume(this.player.volume + 0.05);
          this.showToast(`Volume ${Math.round(this.player.volume * 100)}%`);
          break;

        case 'ArrowDown': // Volume down 5%
          e.preventDefault();
          this.player.setVolume(this.player.volume - 0.05);
          this.showToast(`Volume ${Math.round(this.player.volume * 100)}%`);
          break;

        case 'm':
        case 'M':
          this.player.toggleMute();
          this.showToast(this.player.isMuted ? 'Muted' : 'Unmuted');
          break;

        case 's':
        case 'S':
          const shuffle = this.player.toggleShuffle();
          this.showToast(shuffle ? 'Shuffle enabled' : 'Shuffle disabled');
          break;

        case 'r':
        case 'R':
          const repMode = this.player.cycleRepeatMode();
          this.showToast(`Repeat ${repMode}`);
          break;

        case 'q':
        case 'Q':
          this.toggleQueueDrawer();
          break;

        case '?':
          this.dom.shortcutsModal.classList.toggle('open');
          break;

        case 'Escape':
          this.closeContextMenu();
          this.closePlaylistModal();
          this.dom.shortcutsModal.classList.remove('open');
          this.toggleQueueDrawer(false);
          this.dom.sidebar.classList.remove('mobile-open');
          break;
      }
    });
  }

  // Navigation Logic
  navigateTo(viewName, params = {}, pushHistory = true) {
    if (!this.dom.views[viewName]) return;

    if (pushHistory) {
      this.viewHistory = this.viewHistory.slice(0, this.historyIndex + 1);
      this.viewHistory.push(viewName);
      this.historyIndex = this.viewHistory.length - 1;
    }

    this._updateHistoryButtons();

    this.currentView = viewName;

    // Toggle view section
    Object.entries(this.dom.views).forEach(([name, elem]) => {
      if (elem) elem.classList.toggle('active', name === viewName);
    });

    // Update Sidebar active state
    this.dom.navButtons.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.view === viewName);
    });

    // Update dynamic playlist items active state
    const playlistNavItems = this.dom.sidebarPlaylistsList.querySelectorAll('.nav-item-btn');
    playlistNavItems.forEach(btn => {
      btn.classList.toggle('active', viewName === 'playlist-detail' && btn.dataset.playlistId === this.currentPlaylistId);
    });

    // Close mobile drawer on navigation
    this.dom.sidebar.classList.remove('mobile-open');

    // Specific view triggers
    if (viewName === 'home') this.renderHomeView();
    if (viewName === 'discover') this.renderDiscoverView();
    if (viewName === 'library') this.renderLibraryView();
    if (viewName === 'liked') this.renderLikedView();
    if (viewName === 'recent') this.renderRecentView();
    if (viewName === 'playlist-detail' && params && params.id) {
      this.currentPlaylistId = params.id;
      this.renderPlaylistDetailView(params.id);
    }

    // Scroll to top of viewport
    document.getElementById('main-viewport').scrollTop = 0;
  }

  navigateBack() {
    if (this.historyIndex > 0) {
      this.historyIndex--;
      const prevView = this.viewHistory[this.historyIndex];
      this.navigateTo(prevView, { id: this.currentPlaylistId }, false);
    }
  }

  navigateForward() {
    if (this.historyIndex < this.viewHistory.length - 1) {
      this.historyIndex++;
      const nextView = this.viewHistory[this.historyIndex];
      this.navigateTo(nextView, { id: this.currentPlaylistId }, false);
    }
  }

  _updateHistoryButtons() {
    this.dom.btnNavBack.disabled = this.historyIndex <= 0;
    this.dom.btnNavForward.disabled = this.historyIndex >= this.viewHistory.length - 1;
  }

  // UI Updates for Player State
  updatePlayerUI() {
    const track = this.player.currentTrack;
    if (track) {
      this.dom.playerArtwork.src = track.artwork;
      this.dom.playerArtwork.alt = `${track.title} artwork`;
      this.dom.playerTitle.textContent = track.title;
      this.dom.playerArtist.textContent = `${track.artist} · ${track.album}`;
      this.dom.totalDurationDisplay.textContent = formatTime(track.duration);

      const isLiked = Storage.isLiked(track.id);
      this.dom.playerLikeBtn.classList.toggle('liked', isLiked);
    } else {
      this.dom.playerTitle.textContent = 'Select a track to play';
      this.dom.playerArtist.textContent = 'SONORA Audio Engine';
      this.dom.totalDurationDisplay.textContent = '0:00';
      this.dom.playerLikeBtn.classList.remove('liked');
    }

    this.updatePlayStateUI(this.player.isPlaying);
    this.updateVolumeUI(this.player.volume, this.player.isMuted);
    this.updateRepeatUI(this.player.repeatMode);
    this.updateShuffleUI(this.player.isShuffle);
  }

  updatePlayStateUI(isPlaying) {
    if (isPlaying) {
      this.dom.masterPlayIcon.innerHTML = `
        <rect x="6" y="4" width="4" height="16" rx="1"></rect>
        <rect x="14" y="4" width="4" height="16" rx="1"></rect>
      `;
      this.dom.playerEq.classList.remove('paused');
    } else {
      this.dom.masterPlayIcon.innerHTML = `
        <polygon points="6 3 20 12 6 21 6 3"></polygon>
      `;
      this.dom.playerEq.classList.add('paused');
    }
  }

  updateVolumeUI(vol, isMuted) {
    const effectiveVol = isMuted ? 0 : vol;
    this.dom.volumeFill.style.width = `${effectiveVol * 100}%`;

    if (effectiveVol === 0 || isMuted) {
      this.dom.volumeIcon.innerHTML = `
        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
        <line x1="22" y1="9" x2="16" y2="15"></line>
        <line x1="16" y1="9" x2="22" y2="15"></line>
      `;
    } else if (effectiveVol < 0.5) {
      this.dom.volumeIcon.innerHTML = `
        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
        <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
      `;
    } else {
      this.dom.volumeIcon.innerHTML = `
        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
        <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
        <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
      `;
    }
  }

  updateRepeatUI(mode) {
    this.dom.btnRepeat.classList.toggle('active', mode !== 'off');
    this.dom.repeatBadgeOne.classList.toggle('visible', mode === 'one');
  }

  updateShuffleUI(isShuffle) {
    this.dom.btnShuffle.classList.toggle('active', isShuffle);
  }

  updateLikedBadge() {
    const likes = Storage.getLikedSongs();
    this.dom.likedCountBadge.textContent = likes.length;
  }

  highlightPlayingRows() {
    const currentId = this.player.currentTrack ? this.player.currentTrack.id : null;
    const isPlaying = this.player.isPlaying;

    document.querySelectorAll('.track-row').forEach(row => {
      const rowId = row.dataset.trackId;
      const isThisPlaying = rowId === currentId;

      row.classList.toggle('playing', isThisPlaying);

      const numEl = row.querySelector('.track-col-num');
      if (numEl) {
        if (isThisPlaying && isPlaying) {
          numEl.innerHTML = `
            <div class="eq-bars">
              <span class="eq-bar"></span>
              <span class="eq-bar"></span>
              <span class="eq-bar"></span>
            </div>
          `;
        } else {
          const indexNum = row.dataset.index;
          numEl.innerHTML = `
            <span class="row-index-num">${indexNum}</span>
            <svg class="row-play-icon" width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="6 3 20 12 6 21 6 3"></polygon>
            </svg>
          `;
        }
      }
    });
  }

  // Render Component: Sidebar Playlists
  renderSidebarPlaylists() {
    const playlists = Playlists.getAll();
    this.dom.sidebarPlaylistsList.innerHTML = '';

    playlists.forEach(pl => {
      const li = document.createElement('li');
      const btn = document.createElement('button');
      btn.className = `nav-item-btn ${this.currentView === 'playlist-detail' && this.currentPlaylistId === pl.id ? 'active' : ''}`;
      btn.dataset.playlistId = pl.id;

      btn.innerHTML = `
        <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 15V6"></path>
          <path d="M18.5 18a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"></path>
          <path d="M12 12H3"></path>
          <path d="M16 6H3"></path>
          <path d="M12 18H3"></path>
        </svg>
        <span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${pl.name}</span>
        <span class="badge-count">${pl.trackIds.length}</span>
      `;

      btn.addEventListener('click', () => {
        this.navigateTo('playlist-detail', { id: pl.id });
      });

      li.appendChild(btn);
      this.dom.sidebarPlaylistsList.appendChild(li);
    });
  }

  // Render View: Home
  renderHomeView() {
    // Top 5 popular tracks
    const popular = [...DEFAULT_TRACKS].sort((a, b) => b.plays - a.plays).slice(0, 5);
    this.dom.homePopularTracks.innerHTML = '';
    popular.forEach((track, idx) => {
      this.dom.homePopularTracks.appendChild(this._createTrackRow(track, idx + 1, popular));
    });

    // Curated soundscape cards
    const curated = [
      {
        title: 'Midnight Synths',
        subtitle: 'Propulsive electro & analog sequences',
        artwork: '/assets/images/cover_01.svg',
        trackIds: ['trk-01', 'trk-04', 'trk-06', 'trk-09']
      },
      {
        title: 'Lo-Fi Chill Sanctuary',
        subtitle: 'Warm Rhodes & twilight vinyl beats',
        artwork: '/assets/images/cover_02.svg',
        trackIds: ['trk-02', 'trk-07', 'trk-10']
      },
      {
        title: 'Deep Ambient Drones',
        subtitle: 'Evolving modular soundscapes & space',
        artwork: '/assets/images/cover_03.svg',
        trackIds: ['trk-03', 'trk-08', 'trk-05']
      },
      {
        title: 'Cybernetic High BPM',
        subtitle: 'Club-ready precision electronic groove',
        artwork: '/assets/images/cover_04.svg',
        trackIds: ['trk-04', 'trk-01', 'trk-09']
      }
    ];

    this.dom.homeCuratedCards.innerHTML = '';
    curated.forEach(item => {
      const card = document.createElement('div');
      card.className = 'music-card';
      card.innerHTML = `
        <div class="card-art-container">
          <img src="${item.artwork}" alt="${item.title}" class="card-art-img" />
          <button class="card-play-hover" title="Play ${item.title}">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="6 3 20 12 6 21 6 3"></polygon>
            </svg>
          </button>
        </div>
        <div class="card-title">${item.title}</div>
        <div class="card-subtitle">${item.subtitle}</div>
      `;

      card.addEventListener('click', () => {
        const tracks = Playlists.resolveTracks(item.trackIds);
        this.player.setQueue(tracks, 0, true);
        this.showToast(`Playing ${item.title}`);
      });

      this.dom.homeCuratedCards.appendChild(card);
    });

    this.highlightPlayingRows();
  }

  // Render View: Discover
  renderDiscoverView() {
    // Render genre tabs
    this.dom.discoverGenreBar.innerHTML = '';
    GENRES.forEach(genre => {
      const tab = document.createElement('button');
      tab.className = `filter-tab ${this.activeGenre === genre ? 'active' : ''}`;
      tab.textContent = genre;
      tab.addEventListener('click', () => {
        this.activeGenre = genre;
        this.renderDiscoverView();
      });
      this.dom.discoverGenreBar.appendChild(tab);
    });

    // Handle sort change
    this.dom.discoverSortSelect.onchange = (e) => {
      this.currentSort = e.target.value;
      this.renderDiscoverView();
    };

    // Filter and sort tracks
    let filtered = DEFAULT_TRACKS.filter(t => {
      return this.activeGenre === 'All' || t.genre === this.activeGenre;
    });

    if (this.currentSort === 'title') {
      filtered.sort((a, b) => a.title.localeCompare(b.title));
    } else if (this.currentSort === 'artist') {
      filtered.sort((a, b) => a.artist.localeCompare(b.artist));
    } else if (this.currentSort === 'duration') {
      filtered.sort((a, b) => b.duration - a.duration);
    } else if (this.currentSort === 'plays') {
      filtered.sort((a, b) => b.plays - a.plays);
    }

    // Render cards grid
    this.dom.discoverCardsGrid.innerHTML = '';
    filtered.forEach(track => {
      const card = document.createElement('div');
      card.className = 'music-card';
      card.innerHTML = `
        <div class="card-art-container">
          <img src="${track.artwork}" alt="${track.title}" class="card-art-img" />
          <button class="card-play-hover" title="Play ${track.title}">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="6 3 20 12 6 21 6 3"></polygon>
            </svg>
          </button>
        </div>
        <div class="card-title">${track.title}</div>
        <div class="card-subtitle">${track.artist} · ${track.genre}</div>
      `;

      card.addEventListener('click', () => {
        const idx = filtered.findIndex(t => t.id === track.id);
        this.player.setQueue(filtered, idx, true);
      });

      this.dom.discoverCardsGrid.appendChild(card);
    });

    // Render table
    this.dom.discoverTracksTable.innerHTML = '';
    filtered.forEach((track, idx) => {
      this.dom.discoverTracksTable.appendChild(this._createTrackRow(track, idx + 1, filtered));
    });

    this.highlightPlayingRows();
  }

  // Render View: Library
  renderLibraryView() {
    this.dom.libraryTracksTable.innerHTML = '';
    DEFAULT_TRACKS.forEach((track, idx) => {
      this.dom.libraryTracksTable.appendChild(this._createTrackRow(track, idx + 1, DEFAULT_TRACKS));
    });
    this.highlightPlayingRows();
  }

  // Render View: Liked Songs
  renderLikedView() {
    const liked = Playlists.getLikedPlaylist();
    this.dom.likedSummaryText.textContent = `${liked.tracks.length} saved track${liked.tracks.length === 1 ? '' : 's'} · Total listening time ${formatTime(liked.totalDuration)}`;

    this.dom.likedTracksTable.innerHTML = '';
    if (liked.tracks.length === 0) {
      this.dom.likedTracksTable.innerHTML = `
        <div class="empty-state">
          <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
          </svg>
          <div class="empty-state-title">No liked songs yet</div>
          <div class="empty-state-text">Click the heart icon on any song across the catalog to bookmark it into your collection.</div>
        </div>
      `;
    } else {
      liked.tracks.forEach((track, idx) => {
        this.dom.likedTracksTable.appendChild(this._createTrackRow(track, idx + 1, liked.tracks));
      });
      this.highlightPlayingRows();
    }
  }

  // Render View: Recently Played
  renderRecentView() {
    const recent = Playlists.getRecentlyPlayedPlaylist();
    this.dom.recentTracksTable.innerHTML = '';

    if (recent.tracks.length === 0) {
      this.dom.recentTracksTable.innerHTML = `
        <div class="empty-state">
          <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <polyline points="12 6 12 12 16 14"></polyline>
          </svg>
          <div class="empty-state-title">No listening history</div>
          <div class="empty-state-text">Tracks you play will be recorded here for convenient return access.</div>
        </div>
      `;
    } else {
      recent.tracks.forEach((track, idx) => {
        this.dom.recentTracksTable.appendChild(this._createTrackRow(track, idx + 1, recent.tracks));
      });
      this.highlightPlayingRows();
    }
  }

  // Render View: Playlist Detail
  renderPlaylistDetailView(playlistId) {
    const pl = Playlists.getById(playlistId);
    if (!pl) {
      this.navigateTo('home');
      return;
    }

    const tracks = Playlists.resolveTracks(pl.trackIds);
    const totalDuration = tracks.reduce((sum, t) => sum + (t.duration || 0), 0);

    this.dom.playlistDetailName.textContent = pl.name;
    this.dom.playlistDetailDesc.textContent = pl.description || 'Custom playlist created on Sonora.';
    if (tracks.length > 0) {
      this.dom.playlistDetailArt.src = tracks[0].artwork;
    } else {
      this.dom.playlistDetailArt.src = '/assets/images/cover_03.svg';
    }

    this.dom.playlistDetailTracks.innerHTML = '';
    if (tracks.length === 0) {
      this.dom.playlistDetailTracks.innerHTML = `
        <div class="empty-state">
          <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 18V5l12-2v13"></path>
            <circle cx="6" cy="18" r="3"></circle>
            <circle cx="18" cy="16" r="3"></circle>
          </svg>
          <div class="empty-state-title">This playlist is empty</div>
          <div class="empty-state-text">Browse the library or discover page, click the three dots on any track, and select "Add to Playlist".</div>
        </div>
      `;
    } else {
      tracks.forEach((track, idx) => {
        const row = this._createTrackRow(track, idx + 1, tracks, {
          allowRemoveFromPlaylist: true,
          playlistId: pl.id
        });
        this.dom.playlistDetailTracks.appendChild(row);
      });
      this.highlightPlayingRows();
    }
  }

  // Render View: Search Results
  renderSearchResults(query) {
    const q = query.toLowerCase();
    const results = DEFAULT_TRACKS.filter(t => {
      return (
        t.title.toLowerCase().includes(q) ||
        t.artist.toLowerCase().includes(q) ||
        t.album.toLowerCase().includes(q) ||
        t.genre.toLowerCase().includes(q)
      );
    });

    this.dom.searchQuerySummary.textContent = `Found ${results.length} result${results.length === 1 ? '' : 's'} for "${query}"`;
    this.dom.searchTracksTable.innerHTML = '';

    if (results.length === 0) {
      this.dom.searchTracksTable.innerHTML = `
        <div class="empty-state">
          <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
          <div class="empty-state-title">No matching tracks found</div>
          <div class="empty-state-text">Try searching for keywords like "Synthwave", "Lo-Fi", "Chen", or "Pulse".</div>
        </div>
      `;
    } else {
      results.forEach((track, idx) => {
        this.dom.searchTracksTable.appendChild(this._createTrackRow(track, idx + 1, results));
      });
      this.highlightPlayingRows();
    }
  }

  // Create reusable Track Row element
  _createTrackRow(track, index, contextPlaylist, options = {}) {
    const row = document.createElement('div');
    row.className = `track-row ${this.player.currentTrack && this.player.currentTrack.id === track.id ? 'playing' : ''}`;
    row.dataset.trackId = track.id;
    row.dataset.index = index;

    const isLiked = Storage.isLiked(track.id);

    row.innerHTML = `
      <div class="track-col-num">
        <span class="row-index-num">${index}</span>
        <svg class="row-play-icon" width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
          <polygon points="6 3 20 12 6 21 6 3"></polygon>
        </svg>
      </div>
      <div class="track-col-thumb">
        <img src="${track.artwork}" alt="${track.title}" />
      </div>
      <div class="track-col-main">
        <div class="track-col-title">${track.title}</div>
        <div class="track-col-artist">${track.artist} · <span style="color:var(--text-muted); font-size:11px;">${track.genre}</span></div>
      </div>
      <div class="track-col-album col-album">${track.album}</div>
      <div class="track-col-duration">${formatTime(track.duration)}</div>
      <div class="track-col-actions">
        <button class="btn-row-action btn-row-like ${isLiked ? 'liked' : ''}" title="${isLiked ? 'Unlike' : 'Like'}">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="${isLiked ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
          </svg>
        </button>
        <button class="btn-row-action btn-row-more" title="More options">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="1"></circle>
            <circle cx="19" cy="12" r="1"></circle>
            <circle cx="5" cy="12" r="1"></circle>
          </svg>
        </button>
      </div>
    `;

    // Row click: play track in context
    row.addEventListener('click', (e) => {
      // Ignore if clicking action buttons
      if (e.target.closest('.track-col-actions')) return;

      if (this.player.currentTrack && this.player.currentTrack.id === track.id) {
        this.player.togglePlay();
      } else {
        const startIdx = contextPlaylist.findIndex(t => t.id === track.id);
        this.player.setQueue(contextPlaylist, startIdx !== -1 ? startIdx : 0, true);
      }
    });

    // Row like button
    const likeBtn = row.querySelector('.btn-row-like');
    likeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const likedNow = Storage.toggleLike(track.id);
      likeBtn.classList.toggle('liked', likedNow);
      likeBtn.querySelector('svg').setAttribute('fill', likedNow ? 'currentColor' : 'none');
      this.updateLikedBadge();
      this.updatePlayerUI();
      this.showToast(likedNow ? `Added "${track.title}" to Liked Songs` : `Removed "${track.title}"`);
      if (this.currentView === 'liked') this.renderLikedView();
    });

    // Row more options button
    const moreBtn = row.querySelector('.btn-row-more');
    moreBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      this.openContextMenu(track, e.clientX, e.clientY, options);
    });

    // Context menu on right click
    row.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      this.openContextMenu(track, e.clientX, e.clientY, options);
    });

    return row;
  }

  // Render Queue Drawer
  renderQueueDrawer() {
    this.dom.queueContent.innerHTML = '';

    const current = this.player.currentTrack;
    if (current) {
      const nowPlayingSection = document.createElement('div');
      nowPlayingSection.innerHTML = `
        <div class="queue-section-label">Now Playing</div>
        <div class="queue-item active">
          <div class="queue-item-thumb">
            <img src="${current.artwork}" alt="${current.title}" />
          </div>
          <div class="queue-item-info">
            <div class="queue-item-title">${current.title}</div>
            <div class="queue-item-artist">${current.artist}</div>
          </div>
          <div class="eq-bars ${this.player.isPlaying ? '' : 'paused'}">
            <span class="eq-bar"></span>
            <span class="eq-bar"></span>
            <span class="eq-bar"></span>
          </div>
        </div>
      `;
      this.dom.queueContent.appendChild(nowPlayingSection);
    }

    const upNext = this.player.queue.slice(this.player.queueIndex + 1);
    const nextSection = document.createElement('div');
    nextSection.innerHTML = `<div class="queue-section-label">Next Up (${upNext.length})</div>`;

    if (upNext.length === 0) {
      nextSection.innerHTML += `
        <div style="font-size:12px; color:var(--text-muted); padding:12px 0;">No tracks in up-next queue. Add tracks from any view!</div>
      `;
    } else {
      upNext.forEach((track, i) => {
        const actualIndex = this.player.queueIndex + 1 + i;
        const item = document.createElement('div');
        item.className = 'queue-item';
        item.innerHTML = `
          <div class="queue-item-thumb">
            <img src="${track.artwork}" alt="${track.title}" />
          </div>
          <div class="queue-item-info">
            <div class="queue-item-title">${track.title}</div>
            <div class="queue-item-artist">${track.artist}</div>
          </div>
          <button class="btn-remove-queue" title="Remove from queue">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        `;

        item.querySelector('.btn-remove-queue').addEventListener('click', (e) => {
          e.stopPropagation();
          this.player.removeFromQueue(actualIndex);
        });

        item.addEventListener('click', () => {
          this.player.queueIndex = actualIndex;
          this.player.loadTrack(this.player.queue[actualIndex], true);
        });

        nextSection.appendChild(item);
      });
    }

    this.dom.queueContent.appendChild(nextSection);
  }

  toggleQueueDrawer(forceOpen) {
    const isOpen = this.dom.queueDrawer.classList.contains('open');
    const targetState = forceOpen !== undefined ? forceOpen : !isOpen;
    this.dom.queueDrawer.classList.toggle('open', targetState);
    this.dom.btnToggleQueue.classList.toggle('active', targetState);
  }

  // Context Menu
  openContextMenu(track, x, y, options = {}) {
    this.contextTargetTrack = track;

    const isLiked = Storage.isLiked(track.id);
    this.dom.ctxLikeLabel.textContent = isLiked ? 'Unlike Song' : 'Like Song';

    // Populate user playlists in context menu
    const playlists = Playlists.getAll();
    this.dom.ctxPlaylistOptions.innerHTML = '';

    if (playlists.length === 0) {
      const emptyNote = document.createElement('div');
      emptyNote.style.cssText = 'font-size: 11px; color: var(--text-muted); padding: 4px 12px;';
      emptyNote.textContent = 'No playlists created yet';
      this.dom.ctxPlaylistOptions.appendChild(emptyNote);
    } else {
      playlists.forEach(pl => {
        const item = document.createElement('button');
        item.className = 'context-menu-item';
        item.style.paddingLeft = '18px';
        item.textContent = pl.name;
        item.addEventListener('click', () => {
          Playlists.addTrack(pl.id, track.id);
          this.showToast(`Added "${track.title}" to ${pl.name}`);
          this.renderSidebarPlaylists();
          if (this.currentView === 'playlist-detail' && this.currentPlaylistId === pl.id) {
            this.renderPlaylistDetailView(pl.id);
          }
          this.closeContextMenu();
        });
        this.dom.ctxPlaylistOptions.appendChild(item);
      });
    }

    // Add remove from current playlist option if relevant
    if (options.allowRemoveFromPlaylist && options.playlistId) {
      const removeBtn = document.createElement('button');
      removeBtn.className = 'context-menu-item';
      removeBtn.style.color = 'var(--danger)';
      removeBtn.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="3 6 5 6 21 6"></polyline>
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
        </svg>
        <span>Remove from Playlist</span>
      `;
      removeBtn.addEventListener('click', () => {
        Playlists.removeTrack(options.playlistId, track.id);
        this.showToast(`Removed from playlist`);
        this.renderSidebarPlaylists();
        this.renderPlaylistDetailView(options.playlistId);
        this.closeContextMenu();
      });
      this.dom.ctxPlaylistOptions.appendChild(removeBtn);
    }

    // Prevent offscreen positioning
    const menuWidth = 200;
    const menuHeight = 260;
    const posX = Math.min(x, window.innerWidth - menuWidth - 10);
    const posY = Math.min(y, window.innerHeight - menuHeight - 10);

    this.dom.trackContextMenu.style.left = `${posX}px`;
    this.dom.trackContextMenu.style.top = `${posY}px`;
    this.dom.trackContextMenu.classList.add('open');
  }

  closeContextMenu() {
    this.dom.trackContextMenu.classList.remove('open');
    this.contextTargetTrack = null;
  }

  // Playlist Modal
  openPlaylistModal(existingPlaylist = null) {
    if (existingPlaylist) {
      this.dom.modalPlaylistTitle.textContent = 'Edit Playlist';
      this.dom.playlistModalId.value = existingPlaylist.id;
      this.dom.playlistNameInput.value = existingPlaylist.name;
      this.dom.playlistDescInput.value = existingPlaylist.description || '';
    } else {
      this.dom.modalPlaylistTitle.textContent = 'Create Playlist';
      this.dom.playlistModalId.value = '';
      this.dom.playlistNameInput.value = '';
      this.dom.playlistDescInput.value = '';
    }
    this.dom.playlistModal.classList.add('open');
    setTimeout(() => this.dom.playlistNameInput.focus(), 100);
  }

  closePlaylistModal() {
    this.dom.playlistModal.classList.remove('open');
  }

  // Toast Notification System
  showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let iconHtml = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent-primary)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="20 6 9 17 4 12"></polyline>
      </svg>
    `;

    if (type === 'error') {
      iconHtml = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--danger)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="8" x2="12" y2="12"></line>
          <line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
      `;
    }

    toast.innerHTML = `${iconHtml}<span>${message}</span>`;
    this.dom.toastContainer.appendChild(toast);

    setTimeout(() => {
      if (toast.parentElement) {
        toast.parentElement.removeChild(toast);
      }
    }, 3100);
  }
}

// Initialize on DOMContentLoaded
window.addEventListener('DOMContentLoaded', () => {
  new SonoraApp();
});
