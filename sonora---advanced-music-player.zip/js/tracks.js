/**
 * SONORA — Audio Track Database
 * Contains verified track metadata, local assets, genres, and audio sources.
 */

export const DEFAULT_TRACKS = [
  {
    id: 'trk-01',
    title: 'Midnight Velocity',
    artist: 'Kaelen Vance',
    album: 'Synthwave Odyssey',
    duration: 24, // seconds
    genre: 'Synthwave',
    year: 2026,
    artwork: '/assets/images/cover_01.svg',
    audioSrc: '/assets/audio/track_01.wav',
    remoteFallback: 'https://audioplayer.madza.dev/Madza-Chords_of_Life.mp3',
    plays: 14820,
    featured: true,
    description: 'Propulsive analog basslines, neon arpeggios, and driving nocturnal rhythms.'
  },
  {
    id: 'trk-02',
    title: 'Neon Solitude',
    artist: 'Mira Chen',
    album: 'After Hours Vol. 1',
    duration: 22,
    genre: 'Lo-Fi',
    year: 2026,
    artwork: '/assets/images/cover_02.svg',
    audioSrc: '/assets/audio/track_02.wav',
    remoteFallback: 'https://audioplayer.madza.dev/Madza-Late_Night_Drive.mp3',
    plays: 12450,
    featured: false,
    description: 'Warm electric piano Rhodes chords filtered through tape flutter and vinyl dust.'
  },
  {
    id: 'trk-03',
    title: 'Subterranean Horizon',
    artist: 'Aethel Sound',
    album: 'Geometries of Sound',
    duration: 26,
    genre: 'Ambient',
    year: 2025,
    artwork: '/assets/images/cover_03.svg',
    audioSrc: '/assets/audio/track_03.wav',
    remoteFallback: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    plays: 9380,
    featured: false,
    description: 'Evolving modular drone soundscapes, deep harmonic resonance, and subtle bell chimes.'
  },
  {
    id: 'trk-04',
    title: 'Cybernetic Pulse',
    artist: 'Vector 99',
    album: 'Zero Day Machine',
    duration: 24,
    genre: 'Techno',
    year: 2026,
    artwork: '/assets/images/cover_04.svg',
    audioSrc: '/assets/audio/track_04.wav',
    remoteFallback: 'https://audioplayer.madza.dev/Madza-Persistence.mp3',
    plays: 18910,
    featured: true,
    description: 'Relentless precision techno kick, metallic modular sequences, and industrial grit.'
  },
  {
    id: 'trk-05',
    title: 'Starlight Canopy',
    artist: 'Elora Ray',
    album: 'Constellation Dreams',
    duration: 25,
    genre: 'Chillwave',
    year: 2026,
    artwork: '/assets/images/cover_05.svg',
    audioSrc: '/assets/audio/track_05.wav',
    remoteFallback: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    plays: 11200,
    featured: false,
    description: 'Lush reverb washes, vocal-sampled textures, and twilight downtempo grooves.'
  },
  {
    id: 'trk-06',
    title: 'Analog Dreamer',
    artist: 'The Tape Project',
    album: 'Vintage Circuitry',
    duration: 24,
    genre: 'Synthwave',
    year: 2025,
    artwork: '/assets/images/cover_06.svg',
    audioSrc: '/assets/audio/track_06.wav',
    remoteFallback: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    plays: 8740,
    featured: false,
    description: 'Classic 80s polysynth chord stacks, warm chorus modulation, and nostalgic optimism.'
  },
  {
    id: 'trk-07',
    title: 'Coffee & Rain',
    artist: 'Dusk Collective',
    album: 'Rainy Day Cafe',
    duration: 22,
    genre: 'Lo-Fi',
    year: 2026,
    artwork: '/assets/images/cover_07.svg',
    audioSrc: '/assets/audio/track_07.wav',
    remoteFallback: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    plays: 16400,
    featured: true,
    description: 'Gentle modal jazz progression with sidechained kick and cozy ambient room tone.'
  },
  {
    id: 'trk-08',
    title: 'Astral Wanderer',
    artist: 'Hyperion Deep',
    album: 'Deep Space Broadcast',
    duration: 28,
    genre: 'Ambient',
    year: 2025,
    artwork: '/assets/images/cover_08.svg',
    audioSrc: '/assets/audio/track_08.wav',
    remoteFallback: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    plays: 7650,
    featured: false,
    description: 'Celestial open intervals, drifting pitch-shifted reverb trails, and gravity-free meditation.'
  },
  {
    id: 'trk-09',
    title: 'Prism Velocity',
    artist: 'Solara',
    album: 'Kaleidoscope Waves',
    duration: 24,
    genre: 'Techno',
    year: 2026,
    artwork: '/assets/images/cover_09.svg',
    audioSrc: '/assets/audio/track_09.wav',
    remoteFallback: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',
    plays: 13980,
    featured: false,
    description: 'Bright uplifting chord arpeggiations, pitched sub stabs, and vibrant electronic euphoria.'
  },
  {
    id: 'trk-10',
    title: 'Midnight Reverie',
    artist: 'Rowan Vale',
    album: 'Acoustic Solace',
    duration: 25,
    genre: 'Chillwave',
    year: 2026,
    artwork: '/assets/images/cover_10.svg',
    audioSrc: '/assets/audio/track_10.wav',
    remoteFallback: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',
    plays: 15300,
    featured: true,
    description: 'Hypnotic fingerpicked nylon harmonic textures blended with subtle modern sub bass.'
  }
];

export const GENRES = ['All', 'Synthwave', 'Lo-Fi', 'Ambient', 'Techno', 'Chillwave'];

/**
 * Format raw seconds to MM:SS display string
 */
export function formatTime(seconds) {
  if (isNaN(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}
