/**
 * SONORA — Storage Manager
 * Encapsulates localStorage with error protection, JSON validation, and default states.
 */

const KEYS = {
  LIKED: 'sonora_liked_songs',
  PLAYLISTS: 'sonora_playlists',
  VOLUME: 'sonora_volume',
  MUTED: 'sonora_muted',
  REPEAT: 'sonora_repeat_mode',
  SHUFFLE: 'sonora_shuffle_state',
  RECENT: 'sonora_recently_played',
  QUEUE: 'sonora_current_queue',
  LAST_PLAYED: 'sonora_last_played'
};

function safeGet(key, fallback) {
  try {
    const item = localStorage.getItem(key);
    if (item === null) return fallback;
    return JSON.parse(item);
  } catch (err) {
    console.warn(`[SONORA Storage] Error reading ${key}:`, err);
    return fallback;
  }
}

function safeSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (err) {
    console.warn(`[SONORA Storage] Error writing ${key}:`, err);
    return false;
  }
}

export const Storage = {
  // Liked Songs (Array of track IDs)
  getLikedSongs() {
    const likes = safeGet(KEYS.LIKED, ['trk-01', 'trk-04', 'trk-07']); // default starter favorites
    return Array.isArray(likes) ? likes : [];
  },

  isLiked(trackId) {
    const likes = this.getLikedSongs();
    return likes.includes(trackId);
  },

  toggleLike(trackId) {
    const likes = this.getLikedSongs();
    const index = likes.indexOf(trackId);
    let isNowLiked = false;
    if (index === -1) {
      likes.push(trackId);
      isNowLiked = true;
    } else {
      likes.splice(index, 1);
      isNowLiked = false;
    }
    safeSet(KEYS.LIKED, likes);
    return isNowLiked;
  },

  // Playlists
  getPlaylists() {
    const defaultPlaylists = [
      {
        id: 'pl-synth-noir',
        name: 'Midnight Synths',
        description: 'Nocturnal analog bass and driving electronic arpeggios.',
        createdAt: '2026-03-01T12:00:00Z',
        trackIds: ['trk-01', 'trk-04', 'trk-06', 'trk-09']
      },
      {
        id: 'pl-deep-focus',
        name: 'Deep Focus & Lo-Fi',
        description: 'Mellow Rhodes chords, subtle vinyl static, and tranquil acoustics.',
        createdAt: '2026-03-02T12:00:00Z',
        trackIds: ['trk-02', 'trk-03', 'trk-07', 'trk-10']
      }
    ];

    const stored = safeGet(KEYS.PLAYLISTS, null);
    if (!stored || !Array.isArray(stored)) {
      safeSet(KEYS.PLAYLISTS, defaultPlaylists);
      return defaultPlaylists;
    }
    return stored;
  },

  createPlaylist(name, description = '') {
    const playlists = this.getPlaylists();
    const newPlaylist = {
      id: 'pl-' + Date.now().toString(36) + Math.random().toString(36).substr(2, 4),
      name: name.trim() || 'Untitled Playlist',
      description: description.trim(),
      createdAt: new Date().toISOString(),
      trackIds: []
    };
    playlists.push(newPlaylist);
    safeSet(KEYS.PLAYLISTS, playlists);
    return newPlaylist;
  },

  renamePlaylist(playlistId, newName, newDescription) {
    const playlists = this.getPlaylists();
    const target = playlists.find(p => p.id === playlistId);
    if (target) {
      if (newName !== undefined) target.name = newName.trim();
      if (newDescription !== undefined) target.description = newDescription.trim();
      safeSet(KEYS.PLAYLISTS, playlists);
      return true;
    }
    return false;
  },

  deletePlaylist(playlistId) {
    const playlists = this.getPlaylists().filter(p => p.id !== playlistId);
    safeSet(KEYS.PLAYLISTS, playlists);
    return true;
  },

  addTrackToPlaylist(playlistId, trackId) {
    const playlists = this.getPlaylists();
    const target = playlists.find(p => p.id === playlistId);
    if (target) {
      if (!target.trackIds.includes(trackId)) {
        target.trackIds.push(trackId);
        safeSet(KEYS.PLAYLISTS, playlists);
        return true;
      }
    }
    return false;
  },

  removeTrackFromPlaylist(playlistId, trackId) {
    const playlists = this.getPlaylists();
    const target = playlists.find(p => p.id === playlistId);
    if (target) {
      target.trackIds = target.trackIds.filter(id => id !== trackId);
      safeSet(KEYS.PLAYLISTS, playlists);
      return true;
    }
    return false;
  },

  // Playback settings
  getVolume() {
    const vol = safeGet(KEYS.VOLUME, 0.8);
    return typeof vol === 'number' && vol >= 0 && vol <= 1 ? vol : 0.8;
  },

  setVolume(vol) {
    safeSet(KEYS.VOLUME, Math.max(0, Math.min(1, vol)));
  },

  getMuted() {
    return safeGet(KEYS.MUTED, false) === true;
  },

  setMuted(muted) {
    safeSet(KEYS.MUTED, Boolean(muted));
  },

  getRepeatMode() {
    const mode = safeGet(KEYS.REPEAT, 'off');
    return ['off', 'all', 'one'].includes(mode) ? mode : 'off';
  },

  setRepeatMode(mode) {
    safeSet(KEYS.REPEAT, mode);
  },

  getShuffle() {
    return safeGet(KEYS.SHUFFLE, false) === true;
  },

  setShuffle(shuffle) {
    safeSet(KEYS.SHUFFLE, Boolean(shuffle));
  },

  // Recently Played (limit 20)
  getRecentlyPlayed() {
    const recents = safeGet(KEYS.RECENT, []);
    return Array.isArray(recents) ? recents : [];
  },

  addRecentlyPlayed(trackId) {
    let recents = this.getRecentlyPlayed();
    recents = [trackId, ...recents.filter(id => id !== trackId)].slice(0, 20);
    safeSet(KEYS.RECENT, recents);
    return recents;
  },

  clearRecentlyPlayed() {
    safeSet(KEYS.RECENT, []);
  },

  // Saved Queue
  getQueue() {
    const q = safeGet(KEYS.QUEUE, []);
    return Array.isArray(q) ? q : [];
  },

  setQueue(queueTrackIds) {
    safeSet(KEYS.QUEUE, Array.isArray(queueTrackIds) ? queueTrackIds : []);
  },

  getLastPlayedId() {
    return safeGet(KEYS.LAST_PLAYED, null);
  },

  setLastPlayedId(trackId) {
    safeSet(KEYS.LAST_PLAYED, trackId);
  }
};
