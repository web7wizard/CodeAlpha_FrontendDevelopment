/**
 * SONORA — Audio Player Engine
 * Controls native HTML5 Audio element, tracks playback, queues, shuffle, and MediaSession API.
 */

import { Storage } from './storage.js';

export class SonoraPlayer {
  constructor() {
    this.audio = new Audio();
    this.audio.preload = 'metadata';

    this.currentTrack = null;
    this.isPlaying = false;
    this.isLoading = false;
    this.duration = 0;
    this.currentTime = 0;

    // Load persisted settings
    this.volume = Storage.getVolume();
    this.isMuted = Storage.getMuted();
    this.repeatMode = Storage.getRepeatMode(); // 'off' | 'all' | 'one'
    this.isShuffle = Storage.getShuffle();

    this.audio.volume = this.isMuted ? 0 : this.volume;

    // Queue
    this.queue = [];
    this.queueIndex = -1;
    this.originalOrder = [];

    // Callbacks
    this.listeners = {
      trackChange: [],
      playState: [],
      timeUpdate: [],
      durationChange: [],
      volumeChange: [],
      queueChange: [],
      repeatModeChange: [],
      shuffleChange: [],
      loadingChange: [],
      error: []
    };

    this._bindAudioEvents();
    this._setupMediaSession();
  }

  _bindAudioEvents() {
    this.audio.addEventListener('loadedmetadata', () => {
      this.duration = this.audio.duration || (this.currentTrack ? this.currentTrack.duration : 0);
      this.isLoading = false;
      this._emit('durationChange', this.duration);
      this._emit('loadingChange', false);
      this._updateMediaSessionPosition();
    });

    this.audio.addEventListener('timeupdate', () => {
      this.currentTime = this.audio.currentTime || 0;
      this._emit('timeUpdate', {
        currentTime: this.currentTime,
        duration: this.duration || (this.currentTrack ? this.currentTrack.duration : 0),
        progress: this.duration > 0 ? (this.currentTime / this.duration) * 100 : 0
      });
    });

    this.audio.addEventListener('play', () => {
      this.isPlaying = true;
      this._emit('playState', true);
      this._updateMediaSessionState();
      this._updatePageTitle();
    });

    this.audio.addEventListener('pause', () => {
      this.isPlaying = false;
      this._emit('playState', false);
      this._updateMediaSessionState();
      this._updatePageTitle();
    });

    this.audio.addEventListener('waiting', () => {
      this.isLoading = true;
      this._emit('loadingChange', true);
    });

    this.audio.addEventListener('canplay', () => {
      this.isLoading = false;
      this._emit('loadingChange', false);
    });

    this.audio.addEventListener('ended', () => {
      this._handleTrackEnded();
    });

    this.audio.addEventListener('error', (e) => {
      console.warn('[SONORA Player] Audio error:', e);
      this.isLoading = false;
      this._emit('loadingChange', false);

      // Try fallback to remote fallback source if available
      if (this.currentTrack && this.audio.src !== this.currentTrack.remoteFallback && this.currentTrack.remoteFallback) {
        console.info('[SONORA Player] Attempting remote fallback audio source...');
        this.audio.src = this.currentTrack.remoteFallback;
        this.audio.play().catch(err => {
          this._emit('error', {
            track: this.currentTrack,
            message: 'Unable to stream audio track. Please check network connection.'
          });
        });
      } else {
        this._emit('error', {
          track: this.currentTrack,
          message: 'Audio playback failed for this track.'
        });
      }
    });
  }

  _handleTrackEnded() {
    if (this.repeatMode === 'one') {
      this.audio.currentTime = 0;
      this.audio.play().catch(console.error);
    } else {
      const hasNext = this.hasNextTrack();
      if (hasNext) {
        this.nextTrack();
      } else if (this.repeatMode === 'all') {
        this.queueIndex = 0;
        this.loadTrack(this.queue[0], true);
      } else {
        // End of queue
        this.isPlaying = false;
        this.audio.currentTime = 0;
        this._emit('playState', false);
        this._updatePageTitle();
      }
    }
  }

  _setupMediaSession() {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.setActionHandler('play', () => this.play());
      navigator.mediaSession.setActionHandler('pause', () => this.pause());
      navigator.mediaSession.setActionHandler('previoustrack', () => this.prevTrack());
      navigator.mediaSession.setActionHandler('nexttrack', () => this.nextTrack());
      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (details.seekTime !== undefined) {
          this.seek(details.seekTime);
        }
      });
    }
  }

  _updateMediaSessionMetadata() {
    if ('mediaSession' in navigator && this.currentTrack) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: this.currentTrack.title,
        artist: this.currentTrack.artist,
        album: this.currentTrack.album,
        artwork: [
          { src: this.currentTrack.artwork, sizes: '500x500', type: 'image/svg+xml' }
        ]
      });
    }
  }

  _updateMediaSessionState() {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = this.isPlaying ? 'playing' : 'paused';
    }
  }

  _updateMediaSessionPosition() {
    if ('mediaSession' in navigator && 'setPositionState' in navigator.mediaSession) {
      try {
        if (this.duration > 0) {
          navigator.mediaSession.setPositionState({
            duration: this.duration,
            playbackRate: this.audio.playbackRate,
            position: Math.min(this.currentTime, this.duration)
          });
        }
      } catch (err) {
        // Ignore edge cases
      }
    }
  }

  _updatePageTitle() {
    if (this.isPlaying && this.currentTrack) {
      document.title = `▶ ${this.currentTrack.title} — ${this.currentTrack.artist} | SONORA`;
    } else if (this.currentTrack) {
      document.title = `${this.currentTrack.title} — ${this.currentTrack.artist} | SONORA`;
    } else {
      document.title = 'SONORA — Midnight Studio Audio Player';
    }
  }

  // Event Subscription
  on(event, callback) {
    if (this.listeners[event]) {
      this.listeners[event].push(callback);
    }
  }

  _emit(event, data) {
    if (this.listeners[event]) {
      this.listeners[event].forEach(cb => {
        try {
          cb(data);
        } catch (e) {
          console.error(`Error in ${event} listener:`, e);
        }
      });
    }
  }

  // Queue Operations
  setQueue(tracks, startIndex = 0, autoPlay = true) {
    if (!tracks || tracks.length === 0) return;
    this.originalOrder = [...tracks];

    if (this.isShuffle) {
      const selected = tracks[startIndex];
      const remainder = tracks.filter((_, i) => i !== startIndex);
      // Fisher-Yates shuffle
      for (let i = remainder.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [remainder[i], remainder[j]] = [remainder[j], remainder[i]];
      }
      this.queue = [selected, ...remainder];
      this.queueIndex = 0;
    } else {
      this.queue = [...tracks];
      this.queueIndex = Math.max(0, Math.min(startIndex, tracks.length - 1));
    }

    Storage.setQueue(this.queue.map(t => t.id));
    this._emit('queueChange', { queue: this.queue, index: this.queueIndex });

    this.loadTrack(this.queue[this.queueIndex], autoPlay);
  }

  addToQueue(track, playNext = false) {
    if (!track) return;
    if (playNext && this.queueIndex >= 0) {
      this.queue.splice(this.queueIndex + 1, 0, track);
      this.originalOrder.splice(this.queueIndex + 1, 0, track);
    } else {
      this.queue.push(track);
      this.originalOrder.push(track);
    }

    if (this.queue.length === 1 && !this.currentTrack) {
      this.queueIndex = 0;
      this.loadTrack(track, false);
    }

    Storage.setQueue(this.queue.map(t => t.id));
    this._emit('queueChange', { queue: this.queue, index: this.queueIndex });
  }

  removeFromQueue(index) {
    if (index < 0 || index >= this.queue.length) return;
    const isCurrent = index === this.queueIndex;
    this.queue.splice(index, 1);

    if (index < this.queueIndex) {
      this.queueIndex--;
    } else if (isCurrent) {
      if (this.queue.length === 0) {
        this.currentTrack = null;
        this.queueIndex = -1;
        this.audio.pause();
        this.audio.src = '';
        this.isPlaying = false;
        this._emit('trackChange', null);
        this._emit('playState', false);
      } else {
        const nextIdx = Math.min(this.queueIndex, this.queue.length - 1);
        this.queueIndex = nextIdx;
        this.loadTrack(this.queue[this.queueIndex], this.isPlaying);
      }
    }

    Storage.setQueue(this.queue.map(t => t.id));
    this._emit('queueChange', { queue: this.queue, index: this.queueIndex });
  }

  clearQueue() {
    this.queue = this.currentTrack ? [this.currentTrack] : [];
    this.queueIndex = this.currentTrack ? 0 : -1;
    this.originalOrder = [...this.queue];
    Storage.setQueue(this.queue.map(t => t.id));
    this._emit('queueChange', { queue: this.queue, index: this.queueIndex });
  }

  // Playback Control
  loadTrack(track, autoPlay = true) {
    if (!track) return;
    this.currentTrack = track;
    this.duration = track.duration || 0;
    this.currentTime = 0;
    this.isLoading = true;

    this.audio.src = track.audioSrc;
    this.audio.load();

    Storage.setLastPlayedId(track.id);
    Storage.addRecentlyPlayed(track.id);

    this._updateMediaSessionMetadata();
    this._emit('trackChange', track);
    this._emit('loadingChange', true);

    if (autoPlay) {
      this.play();
    }
  }

  play() {
    if (!this.currentTrack && this.queue.length > 0) {
      this.queueIndex = 0;
      this.loadTrack(this.queue[0], true);
      return;
    }
    if (!this.currentTrack) return;

    const playPromise = this.audio.play();
    if (playPromise !== undefined) {
      playPromise.catch(err => {
        // Autoplay restrictions or file load issue
        console.warn('[SONORA Player] Play error:', err);
        this.isPlaying = false;
        this._emit('playState', false);
      });
    }
  }

  pause() {
    this.audio.pause();
    this.isPlaying = false;
    this._emit('playState', false);
  }

  togglePlay() {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
  }

  seek(seconds) {
    if (!this.audio.duration && !this.duration) return;
    const maxDur = this.audio.duration || this.duration;
    const clamped = Math.max(0, Math.min(seconds, maxDur));
    this.audio.currentTime = clamped;
    this.currentTime = clamped;
    this._updateMediaSessionPosition();
  }

  seekPercent(percent) {
    const dur = this.audio.duration || this.duration;
    if (dur > 0) {
      const target = (percent / 100) * dur;
      this.seek(target);
    }
  }

  hasNextTrack() {
    return this.queueIndex < this.queue.length - 1;
  }

  hasPrevTrack() {
    return this.queueIndex > 0 || this.audio.currentTime > 3;
  }

  nextTrack() {
    if (this.queue.length === 0) return;

    if (this.queueIndex < this.queue.length - 1) {
      this.queueIndex++;
      this.loadTrack(this.queue[this.queueIndex], true);
      this._emit('queueChange', { queue: this.queue, index: this.queueIndex });
    } else if (this.repeatMode === 'all') {
      this.queueIndex = 0;
      this.loadTrack(this.queue[0], true);
      this._emit('queueChange', { queue: this.queue, index: this.queueIndex });
    }
  }

  prevTrack() {
    if (this.audio.currentTime > 3) {
      // If song played for >3s, restart current song
      this.audio.currentTime = 0;
      return;
    }

    if (this.queueIndex > 0) {
      this.queueIndex--;
      this.loadTrack(this.queue[this.queueIndex], true);
      this._emit('queueChange', { queue: this.queue, index: this.queueIndex });
    } else if (this.repeatMode === 'all' && this.queue.length > 0) {
      this.queueIndex = this.queue.length - 1;
      this.loadTrack(this.queue[this.queueIndex], true);
      this._emit('queueChange', { queue: this.queue, index: this.queueIndex });
    } else {
      this.audio.currentTime = 0;
    }
  }

  // Volume & Mute
  setVolume(vol) {
    const clamped = Math.max(0, Math.min(1, vol));
    this.volume = clamped;
    Storage.setVolume(clamped);

    if (clamped > 0 && this.isMuted) {
      this.isMuted = false;
      Storage.setMuted(false);
    }

    this.audio.volume = this.isMuted ? 0 : this.volume;
    this._emit('volumeChange', { volume: this.volume, isMuted: this.isMuted });
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    Storage.setMuted(this.isMuted);
    this.audio.volume = this.isMuted ? 0 : this.volume;
    this._emit('volumeChange', { volume: this.volume, isMuted: this.isMuted });
  }

  // Modes
  cycleRepeatMode() {
    const modes = ['off', 'all', 'one'];
    const nextIdx = (modes.indexOf(this.repeatMode) + 1) % modes.length;
    this.repeatMode = modes[nextIdx];
    Storage.setRepeatMode(this.repeatMode);
    this._emit('repeatModeChange', this.repeatMode);
    return this.repeatMode;
  }

  toggleShuffle() {
    this.isShuffle = !this.isShuffle;
    Storage.setShuffle(this.isShuffle);

    if (this.queue.length > 1) {
      const current = this.currentTrack;
      if (this.isShuffle) {
        const others = this.queue.filter(t => t.id !== (current ? current.id : null));
        for (let i = others.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [others[i], others[j]] = [others[j], others[i]];
        }
        this.queue = current ? [current, ...others] : others;
        this.queueIndex = current ? 0 : -1;
      } else {
        // Restore original order
        this.queue = [...this.originalOrder];
        this.queueIndex = current ? this.queue.findIndex(t => t.id === current.id) : 0;
      }
      this._emit('queueChange', { queue: this.queue, index: this.queueIndex });
    }

    this._emit('shuffleChange', this.isShuffle);
    return this.isShuffle;
  }
}
