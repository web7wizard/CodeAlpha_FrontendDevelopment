const fs = require('fs');
const path = require('path');

const audioDir = path.join(__dirname, '..', 'assets', 'audio');
if (!fs.existsSync(audioDir)) {
  fs.mkdirSync(audioDir, { recursive: true });
}

const SAMPLE_RATE = 44100;

function createWavBuffer(samplesLeft, samplesRight) {
  const numSamples = samplesLeft.length;
  const numChannels = 2;
  const bitsPerSample = 16;
  const blockAlign = numChannels * (bitsPerSample / 8);
  const byteRate = SAMPLE_RATE * blockAlign;
  const dataSize = numSamples * blockAlign;
  const buffer = Buffer.alloc(44 + dataSize);

  // RIFF header
  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write('WAVE', 8);

  // fmt chunk
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16); // subchunk1size
  buffer.writeUInt16LE(1, 20); // PCM
  buffer.writeUInt16LE(numChannels, 22);
  buffer.writeUInt32LE(SAMPLE_RATE, 24);
  buffer.writeUInt32LE(byteRate, 28);
  buffer.writeUInt16LE(blockAlign, 32);
  buffer.writeUInt16LE(bitsPerSample, 34);

  // data chunk
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataSize, 40);

  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    // Clamp to -1.0 .. 1.0
    const l = Math.max(-1, Math.min(1, samplesLeft[i]));
    const r = Math.max(-1, Math.min(1, samplesRight[i]));
    const intL = l < 0 ? l * 32768 : l * 32767;
    const intR = r < 0 ? r * 32768 : r * 32767;
    buffer.writeInt16LE(Math.floor(intL), offset);
    buffer.writeInt16LE(Math.floor(intR), offset + 2);
    offset += 4;
  }

  return buffer;
}

// Track definitions with musical generative synthesis
const tracks = [
  {
    name: 'track_01.wav',
    duration: 24, // seconds
    bpm: 120,
    rootFreq: 164.81, // E3
    scale: [0, 3, 5, 7, 10, 12, 15, 17], // Minor pentatonic / blues
    type: 'synthwave'
  },
  {
    name: 'track_02.wav',
    duration: 22,
    bpm: 86,
    rootFreq: 261.63, // C4
    scale: [0, 4, 7, 11, 14, 16, 19], // Maj9
    type: 'lofi'
  },
  {
    name: 'track_03.wav',
    duration: 26,
    bpm: 72,
    rootFreq: 146.83, // D3
    scale: [0, 2, 5, 7, 9, 12, 14], // Dorian
    type: 'ambient'
  },
  {
    name: 'track_04.wav',
    duration: 24,
    bpm: 124,
    rootFreq: 185.00, // F#3
    scale: [0, 3, 7, 10, 12, 15, 19], // Minor
    type: 'techno'
  },
  {
    name: 'track_05.wav',
    duration: 25,
    bpm: 92,
    rootFreq: 220.00, // A3
    scale: [0, 4, 7, 9, 11, 14, 16], // Major
    type: 'chillwave'
  },
  {
    name: 'track_06.wav',
    duration: 24,
    bpm: 112,
    rootFreq: 246.94, // B3
    scale: [0, 2, 3, 7, 10, 12, 14], // Minor
    type: 'retrowave'
  },
  {
    name: 'track_07.wav',
    duration: 22,
    bpm: 82,
    rootFreq: 196.00, // G3
    scale: [0, 4, 7, 11, 14, 18], // Jazz maj9#11
    type: 'jazzlofi'
  },
  {
    name: 'track_08.wav',
    duration: 28,
    bpm: 68,
    rootFreq: 110.00, // A2
    scale: [0, 7, 12, 14, 19, 24], // Open fifths & octaves
    type: 'deepambient'
  },
  {
    name: 'track_09.wav',
    duration: 24,
    bpm: 116,
    rootFreq: 174.61, // F3
    scale: [0, 4, 7, 9, 12, 16, 19], // Lydian
    type: 'futurebass'
  },
  {
    name: 'track_10.wav',
    duration: 25,
    bpm: 78,
    rootFreq: 146.83, // D3
    scale: [0, 2, 4, 7, 9, 12, 14], // D Major
    type: 'acoustic'
  }
];

function semitoneToFreq(base, semitones) {
  return base * Math.pow(2, semitones / 12);
}

for (const t of tracks) {
  const totalSamples = Math.floor(SAMPLE_RATE * t.duration);
  const left = new Float32Array(totalSamples);
  const right = new Float32Array(totalSamples);
  const beatSec = 60 / t.bpm;
  const sixteenth = beatSec / 4;

  for (let i = 0; i < totalSamples; i++) {
    const time = i / SAMPLE_RATE;
    const beat = time / beatSec;
    const bar = Math.floor(beat / 4);
    const posInBeat = beat % 1;

    let sampleL = 0;
    let sampleR = 0;

    // 1. Kick / Bass Pulse
    if (t.type === 'synthwave' || t.type === 'techno' || t.type === 'futurebass' || t.type === 'retrowave') {
      const kickTime = (time % beatSec);
      if (kickTime < 0.2) {
        const kickPitch = 120 * Math.exp(-kickTime * 35) + 40;
        const kickEnv = Math.exp(-kickTime * 18);
        const kick = Math.sin(2 * Math.PI * kickPitch * kickTime) * kickEnv * 0.45;
        sampleL += kick;
        sampleR += kick;
      }
    } else if (t.type === 'lofi' || t.type === 'jazzlofi') {
      // Gentle lofi boom-bap on beats 0 and 2.5
      const beatInBar = beat % 4;
      const kick1 = beatInBar % 2;
      if (kick1 < 0.22) {
        const kPitch = 85 * Math.exp(-kick1 * 25) + 38;
        const kEnv = Math.exp(-kick1 * 12);
        const kick = Math.sin(2 * Math.PI * kPitch * kick1) * kEnv * 0.35;
        sampleL += kick;
        sampleR += kick;
      }
      // Soft snare / rim on beats 1 and 3
      const snareBeat = (beatInBar - 1) % 2;
      if (snareBeat > 0 && snareBeat < 0.18) {
        const noise = (Math.random() * 2 - 1) * Math.exp(-snareBeat * 24) * 0.15;
        const tone = Math.sin(2 * Math.PI * 180 * snareBeat) * Math.exp(-snareBeat * 30) * 0.12;
        sampleL += (noise + tone) * 0.9;
        sampleR += (noise + tone) * 1.1;
      }
    }

    // 2. Bassline
    const bassNoteIdx = Math.floor(beat / 2) % 4;
    const bassOffsets = [0, -4, -2, -5];
    const bassFreq = semitoneToFreq(t.rootFreq * 0.5, bassOffsets[bassNoteIdx] || 0);
    const bassSub = (Math.sin(2 * Math.PI * bassFreq * time) * 0.25) +
                    (Math.sin(2 * Math.PI * bassFreq * 2 * time) * 0.08);
    sampleL += bassSub * 0.85;
    sampleR += bassSub * 0.85;

    // 3. Arp / Chord Harmony
    const step = Math.floor(time / sixteenth);
    const noteDegree = t.scale[step % t.scale.length];
    const leadFreq = semitoneToFreq(t.rootFreq, noteDegree);

    const stepTime = time % sixteenth;
    const leadEnv = Math.exp(-stepTime * 8);

    // Warm stereo detune
    const osc1 = Math.sin(2 * Math.PI * leadFreq * time);
    const osc2 = Math.sin(2 * Math.PI * (leadFreq * 1.004) * time);
    const leadSample = (osc1 * 0.6 + osc2 * 0.4) * leadEnv * 0.2;

    sampleL += leadSample * 0.9;
    sampleR += leadSample * 0.6;

    // 4. Atmospheric Pad / Lush Chords
    const padChord = [0, 4, 7, 11];
    let padL = 0;
    let padR = 0;
    for (let c = 0; c < padChord.length; c++) {
      const f = semitoneToFreq(t.rootFreq * 1.5, padChord[c]);
      const lfo = 0.5 + 0.5 * Math.sin(2 * Math.PI * 0.2 * time + c);
      padL += Math.sin(2 * Math.PI * f * time) * 0.03 * lfo;
      padR += Math.sin(2 * Math.PI * (f * 1.003) * time) * 0.03 * lfo;
    }
    sampleL += padL;
    sampleR += padR;

    // Fade in at start (1s) and fade out at end (1.5s)
    let masterEnv = 1;
    if (time < 1.0) masterEnv = time / 1.0;
    else if (time > t.duration - 1.5) masterEnv = Math.max(0, (t.duration - time) / 1.5);

    left[i] = sampleL * masterEnv;
    right[i] = sampleR * masterEnv;
  }

  const wavBuf = createWavBuffer(left, right);
  const targetFile = path.join(audioDir, t.name);
  fs.writeFileSync(targetFile, wavBuf);
  console.log(`Generated ${t.name} (${t.duration}s, ${wavBuf.length} bytes)`);
}
