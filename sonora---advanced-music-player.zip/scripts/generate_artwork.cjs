const fs = require('fs');
const path = require('path');

const imgDir = path.join(__dirname, '..', 'assets', 'images');
if (!fs.existsSync(imgDir)) {
  fs.mkdirSync(imgDir, { recursive: true });
}

const covers = [
  {
    file: 'cover_01.svg',
    title: 'MIDNIGHT VELOCITY',
    artist: 'Kaelen Vance',
    bg1: '#101114',
    bg2: '#191B20',
    accent: '#B8F36B',
    accent2: '#4E7A27',
    motif: 'waveform'
  },
  {
    file: 'cover_02.svg',
    title: 'NEON SOLITUDE',
    artist: 'Mira Chen',
    bg1: '#0D0E12',
    bg2: '#181A22',
    accent: '#8EE3F5',
    accent2: '#285868',
    motif: 'concentric'
  },
  {
    file: 'cover_03.svg',
    title: 'SUBTERRANEAN',
    artist: 'Aethel Sound',
    bg1: '#121318',
    bg2: '#1E2028',
    accent: '#F3A66B',
    accent2: '#78431E',
    motif: 'grid'
  },
  {
    file: 'cover_04.svg',
    title: 'CYBERNETIC PULSE',
    artist: 'Vector 99',
    bg1: '#0B0C0E',
    bg2: '#16181E',
    accent: '#B8F36B',
    accent2: '#526E30',
    motif: 'pulse'
  },
  {
    file: 'cover_05.svg',
    title: 'STARLIGHT CANOPY',
    artist: 'Elora Ray',
    bg1: '#13141C',
    bg2: '#212330',
    accent: '#C59BF3',
    accent2: '#54377A',
    motif: 'eclipse'
  },
  {
    file: 'cover_06.svg',
    title: 'ANALOG DREAMER',
    artist: 'The Tape Project',
    bg1: '#141210',
    bg2: '#241E19',
    accent: '#F3DE6B',
    accent2: '#7E6E22',
    motif: 'cassette'
  },
  {
    file: 'cover_07.svg',
    title: 'COFFEE & RAIN',
    artist: 'Dusk Collective',
    bg1: '#0F1215',
    bg2: '#1A2128',
    accent: '#7EE8D3',
    accent2: '#2F6E61',
    motif: 'drops'
  },
  {
    file: 'cover_08.svg',
    title: 'ASTRAL WANDERER',
    artist: 'Hyperion Deep',
    bg1: '#0A0B10',
    bg2: '#151722',
    accent: '#6BAAF3',
    accent2: '#274E7A',
    motif: 'orbit'
  },
  {
    file: 'cover_09.svg',
    title: 'PRISM VELOCITY',
    artist: 'Solara',
    bg1: '#141014',
    bg2: '#251924',
    accent: '#F36BA8',
    accent2: '#7A2850',
    motif: 'prism'
  },
  {
    file: 'cover_10.svg',
    title: 'MIDNIGHT REVERIE',
    artist: 'Rowan Vale',
    bg1: '#101412',
    bg2: '#1A231F',
    accent: '#B8F36B',
    accent2: '#416327',
    motif: 'leaves'
  }
];

function generateSvg(c) {
  let innerArt = '';

  if (c.motif === 'waveform') {
    let bars = '';
    for (let i = 0; i < 24; i++) {
      const h = 40 + Math.sin(i * 0.45) * 80 + Math.cos(i * 0.9) * 30;
      const y = 250 - h / 2;
      const x = 70 + i * 15;
      bars += `<rect x="${x}" y="${y}" width="8" height="${h}" rx="4" fill="${i % 2 === 0 ? c.accent : c.accent2}" opacity="${0.6 + (i % 3) * 0.15}"/>`;
    }
    innerArt = `<g>${bars}</g>`;
  } else if (c.motif === 'concentric') {
    innerArt = `
      <circle cx="250" cy="250" r="160" stroke="${c.accent2}" stroke-width="2" fill="none" opacity="0.4"/>
      <circle cx="250" cy="250" r="120" stroke="${c.accent}" stroke-width="2" fill="none" stroke-dasharray="8 8" opacity="0.6"/>
      <circle cx="250" cy="250" r="80" stroke="${c.accent}" stroke-width="3" fill="none"/>
      <circle cx="250" cy="250" r="40" fill="${c.accent}" opacity="0.8"/>
      <circle cx="250" cy="250" r="12" fill="#101114"/>
    `;
  } else if (c.motif === 'grid') {
    let lines = '';
    for (let i = 0; i <= 8; i++) {
      lines += `<line x1="${80 + i * 42}" y1="120" x2="${80 + i * 42}" y2="380" stroke="${c.accent2}" stroke-width="1.5" opacity="0.4"/>`;
      lines += `<line x1="80" y1="${120 + i * 32.5}" x2="420" y2="${120 + i * 32.5}" stroke="${c.accent2}" stroke-width="1.5" opacity="0.4"/>`;
    }
    innerArt = `
      <g>${lines}</g>
      <polygon points="170,300 250,160 330,300" stroke="${c.accent}" stroke-width="4" fill="${c.accent}" fill-opacity="0.15"/>
      <circle cx="250" cy="210" r="28" fill="${c.accent}"/>
    `;
  } else if (c.motif === 'pulse') {
    innerArt = `
      <path d="M 80 250 L 160 250 L 190 170 L 230 330 L 270 210 L 300 270 L 320 250 L 420 250" fill="none" stroke="${c.accent}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
      <circle cx="230" cy="330" r="7" fill="${c.accent}"/>
      <circle cx="190" cy="170" r="7" fill="${c.accent}"/>
    `;
  } else if (c.motif === 'eclipse') {
    innerArt = `
      <circle cx="250" cy="240" r="110" fill="${c.accent}" opacity="0.9"/>
      <circle cx="275" cy="225" r="105" fill="${c.bg2}"/>
      <circle cx="250" cy="240" r="130" stroke="${c.accent2}" stroke-width="1.5" fill="none" stroke-dasharray="4 6"/>
    `;
  } else if (c.motif === 'cassette') {
    innerArt = `
      <rect x="110" y="170" width="280" height="160" rx="16" fill="${c.bg1}" stroke="${c.accent}" stroke-width="3"/>
      <rect x="145" y="210" width="210" height="80" rx="8" fill="#1e1c18" stroke="${c.accent2}" stroke-width="2"/>
      <circle cx="195" cy="250" r="22" fill="#141210" stroke="${c.accent}" stroke-width="2"/>
      <circle cx="305" cy="250" r="22" fill="#141210" stroke="${c.accent}" stroke-width="2"/>
      <rect x="220" y="240" width="60" height="20" fill="${c.accent2}" rx="4"/>
    `;
  } else if (c.motif === 'drops') {
    innerArt = `
      <circle cx="250" cy="250" r="130" fill="none" stroke="${c.accent2}" stroke-width="2" opacity="0.5"/>
      <circle cx="250" cy="250" r="90" fill="none" stroke="${c.accent}" stroke-width="3" opacity="0.7"/>
      <circle cx="250" cy="250" r="50" fill="none" stroke="${c.accent}" stroke-width="4"/>
      <circle cx="250" cy="250" r="18" fill="${c.accent}"/>
    `;
  } else if (c.motif === 'orbit') {
    innerArt = `
      <ellipse cx="250" cy="250" rx="140" ry="60" fill="none" stroke="${c.accent}" stroke-width="2.5" transform="rotate(-25 250 250)"/>
      <ellipse cx="250" cy="250" rx="140" ry="60" fill="none" stroke="${c.accent2}" stroke-width="2" transform="rotate(35 250 250)"/>
      <circle cx="250" cy="250" r="45" fill="${c.accent}"/>
      <circle cx="150" cy="210" r="10" fill="${c.accent}"/>
      <circle cx="340" cy="290" r="7" fill="${c.accent2}"/>
    `;
  } else if (c.motif === 'prism') {
    innerArt = `
      <polygon points="250,140 370,330 130,330" fill="none" stroke="${c.accent}" stroke-width="4"/>
      <polygon points="250,180 340,315 160,315" fill="${c.accent}" fill-opacity="0.2"/>
      <line x1="80" y1="260" x2="200" y2="245" stroke="#ffffff" stroke-width="3" opacity="0.8"/>
      <line x1="280" y1="250" x2="420" y2="210" stroke="${c.accent}" stroke-width="3"/>
      <line x1="285" y1="260" x2="420" y2="250" stroke="#ff8ec4" stroke-width="2.5"/>
      <line x1="290" y1="270" x2="420" y2="290" stroke="#f3c66b" stroke-width="2.5"/>
    `;
  } else {
    innerArt = `
      <circle cx="250" cy="240" r="95" fill="none" stroke="${c.accent}" stroke-width="3"/>
      <path d="M 250 170 C 290 210, 290 270, 250 310 C 210 270, 210 210, 250 170 Z" fill="${c.accent}" opacity="0.8"/>
      <line x1="250" y1="170" x2="250" y2="310" stroke="#101114" stroke-width="2"/>
    `;
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" width="500" height="500">
  <defs>
    <linearGradient id="bgGrad_${c.motif}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c.bg2}" />
      <stop offset="100%" stop-color="${c.bg1}" />
    </linearGradient>
    <radialGradient id="glow_${c.motif}" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="${c.accent}" stop-opacity="0.25"/>
      <stop offset="100%" stop-color="${c.accent}" stop-opacity="0"/>
    </radialGradient>
  </defs>

  <!-- Background -->
  <rect width="500" height="500" fill="url(#bgGrad_${c.motif})"/>
  <rect width="500" height="500" fill="url(#glow_${c.motif})"/>

  <!-- Subtle border outline -->
  <rect x="16" y="16" width="468" height="468" fill="none" stroke="#2B2D34" stroke-width="1.5" rx="8"/>

  <!-- Top metadata stamp -->
  <text x="36" y="56" fill="${c.accent}" font-family="system-ui, -apple-system, sans-serif" font-size="11" font-weight="700" letter-spacing="3">SONORA STUDIO ARCHIVE</text>
  <text x="464" y="56" text-anchor="end" fill="#9B9DA6" font-family="ui-monospace, monospace" font-size="11">VOL. 04</text>

  <!-- Central Artwork Motif -->
  ${innerArt}

  <!-- Bottom typography container -->
  <rect x="36" y="405" width="428" height="1" fill="#2B2D34"/>
  <text x="36" y="435" fill="#F5F5F2" font-family="system-ui, -apple-system, sans-serif" font-size="18" font-weight="700" letter-spacing="1">${c.title}</text>
  <text x="36" y="458" fill="#9B9DA6" font-family="system-ui, -apple-system, sans-serif" font-size="13" font-weight="500">${c.artist}</text>
  <text x="464" y="445" text-anchor="end" fill="${c.accent}" font-family="ui-monospace, monospace" font-size="12" font-weight="600">HQ STEREO</text>
</svg>`;
}

for (const c of covers) {
  const svg = generateSvg(c);
  fs.writeFileSync(path.join(imgDir, c.file), svg);
  console.log(`Generated ${c.file}`);
}

// Generate featured hero banner
const heroSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 480" width="1200" height="480">
  <defs>
    <linearGradient id="heroBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1B1E26" />
      <stop offset="60%" stop-color="#121318" />
      <stop offset="100%" stop-color="#0E0F12" />
    </linearGradient>
    <radialGradient id="heroGlow" cx="20%" cy="40%" r="60%">
      <stop offset="0%" stop-color="#B8F36B" stop-opacity="0.18"/>
      <stop offset="100%" stop-color="#B8F36B" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="1200" height="480" fill="url(#heroBg)"/>
  <rect width="1200" height="480" fill="url(#heroGlow)"/>

  <!-- Waveform accents -->
  <g opacity="0.35">
    <path d="M 0 320 Q 300 180 600 300 T 1200 240 L 1200 480 L 0 480 Z" fill="#B8F36B" fill-opacity="0.05"/>
    <path d="M 0 360 Q 350 250 700 370 T 1200 320" fill="none" stroke="#B8F36B" stroke-width="2" stroke-dasharray="6 8"/>
  </g>

  <!-- Right side art graphic -->
  <circle cx="980" cy="240" r="160" fill="none" stroke="#2B2D34" stroke-width="2"/>
  <circle cx="980" cy="240" r="120" fill="none" stroke="#B8F36B" stroke-width="3" opacity="0.7"/>
  <circle cx="980" cy="240" r="70" fill="#191B20" stroke="#B8F36B" stroke-width="2"/>
  <circle cx="980" cy="240" r="20" fill="#B8F36B"/>
</svg>`;
fs.writeFileSync(path.join(imgDir, 'featured_hero.svg'), heroSvg);
console.log('Generated featured_hero.svg');
