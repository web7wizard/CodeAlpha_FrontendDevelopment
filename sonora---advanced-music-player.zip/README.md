# SONORA — Advanced Music Player Web Application

[![CodeAlpha Task 4](https://img.shields.io/badge/CodeAlpha-Task%204%20Frontend%20Internship-B8F36B?style=for-the-badge&logo=music&logoColor=101114)](https://github.com/javeriyajamadar/CodeAlpha_MusicPlayer)
[![License: MIT](https://img.shields.io/badge/License-MIT-B8F36B.svg?style=for-the-badge)](LICENSE)
[![Vanilla JS](https://img.shields.io/badge/Vanilla-HTML5%20%7C%20CSS3%20%7C%20ES6+-191B20?style=for-the-badge&logo=javascript)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
[![Netlify Status](https://img.shields.io/badge/Netlify-Ready-success?style=for-the-badge&logo=netlify)](https://www.netlify.com/)

A modern, production-grade browser-based music streaming player built with **HTML5**, **CSS3**, **Vanilla JavaScript (ES6+ Modules)**, and the native **HTML5 Audio API**. Engineered for CodeAlpha Frontend Development Internship Task 4.

Designed with an original **Midnight Studio** aesthetic (deep obsidian canvas `#101114`, elevated surfaces `#191B20`, electric chartreuse accent `#B8F36B`, and crisp typography).

---

## 📸 Screenshots & Showcase

| Desktop Dashboard View | Responsive Mobile Interface |
|:---:|:---:|
| ![SONORA Desktop Interface](assets/images/featured_hero.svg) | ![SONORA Mobile Interface](assets/images/cover_01.svg) |
| *Full sidebar, featured hero, popular tracks table & persistent bottom scrubber.* | *Collapsible hamburger menu, responsive touch player & bottom sheet queue.* |

---

## ✨ Core Features

### 🎧 1. Native HTML5 Audio Engine (`js/player.js`)
- **Real Audio API integration**: Driven by native HTML5 `<audio>` events (`loadedmetadata`, `timeupdate`, `ended`, `play`, `pause`, `waiting`, `canplay`, `error`). Zero simulated timers.
- **Precision Seeking**: Interactive scrub bar with real-time hover timestamp preview tooltips and smooth drag physics.
- **Volume & Mute Control**: Linear volume scaler (0–100%) with dynamic icon state indicators (high volume, low volume, muted) and one-click mute memory.
- **Playback Modes**:
  - **Shuffle Mode**: True Fisher-Yates array shuffling with persistent state.
  - **Repeat Modes**: Cycle seamlessly between Repeat Off, Repeat All, and Repeat One (with indicator badge).
- **Auto-Advance**: Automatically transitions to the next queue item when a song finishes.
- **System MediaSession API**: Full background lock screen and OS hardware media key integration (Play/Pause, Previous/Next track, Seek to time, Position state).
- **Dynamic Browser Tab**: Live updates to document title reflecting the currently playing track: `▶ Track Title — Artist | SONORA`.

### 📚 2. Library & Playlists Architecture (`js/playlists.js`)
- **10 Bundled Master Audio Tracks**: High-fidelity 44.1kHz stereo WAV tracks across Synthwave, Lo-Fi, Ambient, Techno, and Chillwave.
- **Real-Time Instant Search**: Live filter by song title, artist, album, or genre with instant feedback.
- **Genre Exploration**: Interactive segmented filter tabs with dynamic count updates.
- **Custom Playlists CRUD**:
  - Create new playlists with custom titles and descriptions.
  - Add tracks to playlists via contextual action menus.
  - Remove tracks from playlists.
  - Edit playlist metadata or delete playlists with safe confirmation dialogs.
- **Dedicated Collections**:
  - **Liked Songs**: Dedicated view displaying total saved tracks and accumulated listening duration.
  - **Recently Played**: Chronological history tracking session listening activity with one-click clear.

### 🎛 3. Up-Next Queue Management
- **Slide-Over Queue Drawer**: Flyout side panel displaying the currently active track with animated equalizer bars alongside the upcoming queue.
- **Reordering & Removal**: Remove individual tracks from upcoming queue or clear the entire queue with one click.
- **Play Next / Add to Queue**: Right-click or three-dot context menu allows adding any song to play next or append to queue.

### 💾 4. Persistent LocalStorage State (`js/storage.js`)
- Persistent memory across page refreshes for:
  - Liked song bookmarks
  - Custom user playlists and track associations
  - Volume slider level and mute state
  - Repeat mode preference (`off` | `all` | `one`)
  - Shuffle state
  - Recently played history
  - Active queue position and last played song
- Resilient JSON parsing with defensive error boundaries and safe fallback defaults.

### ⌨️ 5. Keyboard Accessibility & Shortcuts
- Clean shortcut system with input-focus isolation (typing in search inputs will never accidentally trigger playback shortcuts):
  - <kbd>Space</kbd>: Play / Pause
  - <kbd>→</kbd>: Seek Forward 5s
  - <kbd>←</kbd>: Seek Backward 5s
  - <kbd>↑</kbd>: Volume Up 5%
  - <kbd>↓</kbd>: Volume Down 5%
  - <kbd>M</kbd>: Mute / Unmute
  - <kbd>S</kbd>: Toggle Shuffle Mode
  - <kbd>R</kbd>: Cycle Repeat Mode
  - <kbd>Q</kbd>: Toggle Queue Drawer
  - <kbd>?</kbd>: Toggle Keyboard Shortcuts Cheat Sheet Modal
  - <kbd>Esc</kbd>: Dismiss all open drawers, modals, and context menus

---

## 📁 Project Structure

```
CodeAlpha_MusicPlayer/
├── index.html              # Semantic HTML5 entry point & accessible layout
├── README.md               # Detailed documentation, guide, & asset licenses
├── package.json            # Development environment configuration
├── css/
│   └── styles.css          # Midnight Studio design system & CSS3 responsive grid
├── js/
│   ├── app.js              # Central UI controller, view router, modals & toasts
│   ├── player.js           # Native HTML5 audio engine & MediaSession integration
│   ├── tracks.js           # 10-track database, metadata, & duration formatters
│   ├── playlists.js        # Playlist management, virtual collections & track resolution
│   └── storage.js          # Resilient LocalStorage persistence & validation
└── assets/
    ├── audio/              # 10 locally bundled 44.1kHz stereo WAV audio tracks
    │   ├── track_01.wav    # Midnight Velocity (Synthwave)
    │   ├── track_02.wav    # Neon Solitude (Lo-Fi)
    │   ├── track_03.wav    # Subterranean Horizon (Ambient)
    │   ├── track_04.wav    # Cybernetic Pulse (Techno)
    │   ├── track_05.wav    # Starlight Canopy (Chillwave)
    │   ├── track_06.wav    # Analog Dreamer (Synthwave)
    │   ├── track_07.wav    # Coffee & Rain (Lo-Fi)
    │   ├── track_08.wav    # Astral Wanderer (Ambient)
    │   ├── track_09.wav    # Prism Velocity (Techno)
    │   └── track_10.wav    # Midnight Reverie (Chillwave)
    ├── images/             # Vector album artwork (Zero-broken-image guarantee)
    │   ├── cover_01.svg to cover_10.svg
    │   └── featured_hero.svg
    └── icons/              # Clean inline-ready SVG icon definitions
        ├── play.svg, pause.svg, shuffle.svg, repeat.svg, etc.
```

---

## 🚀 How to Run Locally

Because SONORA is built with pure standards-compliant HTML5, CSS3, and ES6 JavaScript modules, **no complicated build steps or compilation are required**.

### Option 1: Live Server (VS Code)
1. Clone or download this repository:
   ```bash
   git clone https://github.com/javeriyajamadar/CodeAlpha_MusicPlayer.git
   cd CodeAlpha_MusicPlayer
   ```
2. Open the folder in VS Code.
3. Right-click `index.html` and click **"Open with Live Server"**.
4. The application will launch in your browser at `http://127.0.0.1:5500`.

### Option 2: Python Simple HTTP Server
Run from the project root:
```bash
# Python 3
python -m http.server 3000
```
Open [http://localhost:3000](http://localhost:3000) in your web browser.

### Option 3: Node.js / Vite Dev Server
If you have Node.js installed:
```bash
npm install
npm run dev
```

---

## 🎵 How to Add Your Own Audio Files

To replace or add new tracks to your library:

1. Copy your licensed `.mp3`, `.wav`, or `.ogg` audio files into the `assets/audio/` folder:
   ```
   assets/audio/my_new_song.mp3
   ```
2. Add an album artwork image (SVG, PNG, or JPG) into `assets/images/`:
   ```
   assets/images/my_artwork.jpg
   ```
3. Open `js/tracks.js` and add your track object into the `DEFAULT_TRACKS` array:
   ```javascript
   {
     id: 'trk-11',
     title: 'Golden Horizon',
     artist: 'Aura',
     album: 'Dawn Collective',
     duration: 180, // Duration in seconds
     genre: 'Lo-Fi',
     year: 2026,
     artwork: '/assets/images/my_artwork.jpg',
     audioSrc: '/assets/audio/my_new_song.mp3',
     plays: 2400,
     featured: true,
     description: 'Peaceful acoustic chords and morning warmth.'
   }
   ```
4. Save the file and reload your browser. Your song will instantly appear in the library, search, and playlist selectors!

---

## 🌐 Netlify Deployment Guide

SONORA is fully prepared for 1-click static deployment on Netlify:

### Method A: Netlify Drag & Drop (Easiest)
1. Go to [app.netlify.com](https://app.netlify.com).
2. Log in and navigate to **Sites**.
3. Drag and drop the `CodeAlpha_MusicPlayer` project folder into the deployment box.
4. Netlify will immediately deploy your site with a custom live URL (e.g. `https://sonora-music-player.netlify.app`).

### Method B: Git Continuous Deployment
1. Push your repository to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: SONORA music player"
   git remote add origin https://github.com/javeriyajamadar/CodeAlpha_MusicPlayer.git
   git push -u origin main
   ```
2. On Netlify, select **"Add new site"** → **"Import an existing project"** → **GitHub**.
3. Select your repository `CodeAlpha_MusicPlayer`.
4. Leave the Build Command blank (or `npm run build` if using Vite) and set the Publish directory to `.` or `dist`.
5. Click **Deploy**. Any future commits pushed to GitHub will automatically trigger live redeployments!

---

## 🔍 Known Limitations & Edge-Case Handling

1. **Browser Autoplay Policies**: Modern browsers (Chrome, Safari, Edge, Firefox) prohibit websites from playing audio automatically upon page load until the user interacts with the document (such as clicking the Play button or a track row). SONORA respects this standard and initializes the player in an armed, ready-to-play paused state.
2. **Audio File Accessibility**: All 10 default sample tracks are bundled locally within `assets/audio/`, guaranteeing 100% offline availability without third-party CDN latency, cross-origin request issues, or dead links.
3. **CORS on Remote Streams**: If you configure remote streaming URLs in `js/tracks.js`, ensure the remote server supplies `Access-Control-Allow-Origin: *`. If a remote URL fails, SONORA's error listener automatically falls back or notifies the user with a non-intrusive toast notification.

---

## 📜 Credits & Licensing

- **Code & Architecture**: Built by Javeriya Jamadar for CodeAlpha Frontend Development Internship Task 4.
- **Audio Synthesizer Engine**: Generative PCM stereo compositions produced for offline audio demo demonstration.
- **Icons**: SVG icon designs based on Lucide open-source feather icon standards.
- **Typography**: Google Fonts — *Plus Jakarta Sans* and *IBM Plex Mono* (SIL Open Font License).
- **License**: Released under the [MIT License](LICENSE). Free for educational, portfolio, and personal use.
